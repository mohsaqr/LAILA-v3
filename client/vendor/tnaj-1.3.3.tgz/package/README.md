# tnaj

**Transition Network Analysis for JavaScript/TypeScript**

A zero-dependency, pure TypeScript implementation of Transition Network Analysis (TNA) for modeling sequential data as weighted directed networks. Works in Node.js, Deno, Bun, and browsers.

Ported from the [R TNA package](https://cran.r-project.org/package=TNA) and the [Python tna package](https://github.com/mohsaqr/tnapy), with numerical equivalence to R TNA validated to machine epsilon (~1e-15).

**Live demo:** [https://saqr.me/tna-js/](https://saqr.me/tna-js/) | **Desktop app:** [TNA Desktop](https://saqr.me/tnadesktop/)

---

## Ecosystem position

tnaj is part of a [four-library ecosystem](../ARCHITECTURE.md) for network and sequence analysis. It owns **sequences → transition networks** and everything you do *to* a TNA model (centralities specific to TNA, pruning, communities, bootstrap, permutation, stability, reliability, Markov-order test).

Sibling libraries with different scope:

- **[snajs](../snajs)** — general SNA on plain `number[][]` adjacency matrices. Use for centralities / metrics / community detection on a graph that isn't a TNA model. (~95 centrality measures.)
- **[codynaj](../codyna)** — sequence pattern indices (complexity, turbulence, entropy, dominant spell, …) and pattern discovery. Same `SequenceData` input shape as tnaj, different question.
- **[psychaj](https://github.com/mohsaqr/psychaj)** — psychometric networks from variable matrices (Pearson, partial correlation, GLASSO, mlVAR, graphicalVAR, IsingFit, MGM).

### tnaj centralities ≠ snajs centralities

Both libraries expose `centralities()` and overlapping measure names (`Betweenness`, `Closeness`, `PageRank`, etc.). They answer to **different R references** and produce **different numerical values for the same matrix**:

| | tnaj | snajs |
|---|---|---|
| R reference | `tna` R package | `igraph` / `cograph` |
| Distance convention | `1/weight` (probabilities → costs) | raw weight |
| Direction | always directed | follows `directed` flag |
| Output | `Float64Array` | `number[]` |

If your code uses TNA models, call **tnaj's** `centralities(model)`. If you have a generic graph and want igraph-equivalent values, call **snajs's** `computeCentralities(matrix, labels, directed)`. Neither is "more correct" — they're parity-verified against the toolchain their consumers expect.

See [ARCHITECTURE.md](../ARCHITECTURE.md) for the contract: who owns what, what depends on whom, and how data flows when a workflow crosses paradigms.

---

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Core Concepts](#core-concepts)
- [Prediction Suffix Trees](#prediction-suffix-trees)
- [Guides](#guides)
  - [Clustering Sequences and Building Per-Cluster Models](#clustering-sequences-and-building-per-cluster-models)
  - [Building a Dashboard with Clusters](#building-a-dashboard-with-clusters)
  - [Group Comparison Workflow](#group-comparison-workflow)
- [API Reference](#api-reference)
  - [Model Building](#model-building)
  - [Centralities](#centralities)
  - [Pruning](#pruning)
  - [Community Detection](#community-detection)
  - [Clique Detection](#clique-detection)
  - [Sequence Clustering](#sequence-clustering)
  - [Sequence Comparison](#sequence-comparison)
  - [Group Models](#group-models)
  - [Data Preparation](#data-preparation)
  - [Utility Functions](#utility-functions)
- [Using in a Website](#using-in-a-website)
  - [With a Bundler (Vite, Webpack, etc.)](#with-a-bundler)
  - [From a CDN (ESM)](#from-a-cdn)
  - [Server-Side (Node.js / Bun / Deno)](#server-side)
- [Data Format](#data-format)
- [Types Reference](#types-reference)
- [Citation](#citation)
- [Related Projects](#related-projects)
- [License](#license)

---

## Installation

```bash
# npm
npm install tnaj

# yarn
yarn add tnaj

# pnpm
pnpm add tnaj

# bun
bun add tnaj
```

Or install from GitHub:

```bash
npm install github:mohsaqr/tna-js
```

---

## Quick Start

```typescript
import { tna, centralities, prune, communities } from 'tnaj';

// Your sequential data: each row is a sequence of states
const data = [
  ['A', 'B', 'C', 'A', 'B'],
  ['B', 'C', 'A', 'C', 'B'],
  ['A', 'A', 'B', 'C', 'A'],
  ['C', 'B', 'A', 'B', 'C'],
];

// Build a TNA model (relative transition probabilities)
const model = tna(data);

console.log(model.labels);    // ['A', 'B', 'C']
console.log(model.type);      // 'relative'
console.log(model.inits);     // Float64Array [0.5, 0.25, 0.25]

// Compute centrality measures
const cent = centralities(model);
console.log(cent.measures.OutStrength);   // Float64Array [...]
console.log(cent.measures.Betweenness);   // Float64Array [...]

// Prune weak edges (remove edges below threshold)
const pruned = prune(model, 0.1);

// Detect communities
const comm = communities(model, { methods: 'louvain' });
console.log(comm.assignments.louvain);    // [0, 0, 1]
console.log(comm.counts.louvain);         // 2
```

---

## Core Concepts

**TNA** (Transition Network Analysis) models sequential data as a weighted directed graph. Each unique state in the data becomes a node, and transitions between consecutive states become weighted directed edges.

**Model types:**

| Function | Type | Description |
|----------|------|-------------|
| `tna()` | `relative` | Row-normalized transition probabilities (values sum to 1 per row) |
| `ftna()` | `frequency` | Raw transition counts |
| `ctna()` | `co-occurrence` | Bidirectional co-occurrence counts |
| `atna()` | `attention` | Exponential decay weighted transitions (recent transitions weighted more) |

**What you get:**
- A `TNA` object with a weight matrix, initial state probabilities, and state labels
- 9 centrality measures per node (OutStrength, InStrength, Betweenness, Closeness, etc.)
- Network pruning, community detection, clique detection
- Sequence clustering (PAM, hierarchical) with 4 distance metrics
- Pattern comparison across groups with permutation testing

## Prediction Suffix Trees

`tnaj/transitiontrees` provides a typed, zero-dependency implementation of the
computational API in Saqr et al.'s R
[`transitiontrees`](https://github.com/mohsaqr/transitiontrees) package. It fits
variable-depth prediction suffix trees and exposes the same modeling workflows
using camelCase names.

```typescript
import {
  contextTree,
  treePathways,
  predictNext,
  pruneTree,
  treeModelFit,
} from 'tnaj/transitiontrees';

const sequences = [
  ['read', 'annotate', 'discuss', 'quiz'],
  ['read', 'quiz', 'read', 'annotate'],
  ['discuss', 'read', 'annotate', 'read'],
];

const tree = contextTree(sequences, {
  maxDepth: 3,
  minCount: 1,
  smoothing: { method: 'kneser_ney', discount: 0.75 },
});

console.log(predictNext(tree, ['read', 'annotate']));
console.table(treePathways(tree));
console.log(treeModelFit(pruneTree(tree, { criterion: 'G2' })));
```

The subpath includes:

- five smoothing methods: floor, Laplace, Kneser–Ney, Witten–Bell, and
  Jelinek–Mercer;
- G², KL, AIC, and BIC pruning;
- prediction, simulation, scoring, likelihood, perplexity, and pathway queries;
- pathway mining, sequential gap imputation, dependence diagnostics, and
  subtrees;
- cross-validated tuning, symmetric-KL tree comparison, permutation tests, and
  pathway bootstrap stability;
- long-event reshaping and multi-group behavioral/usage comparisons.

Deterministic results are checked against fixtures generated by R
`transitiontrees` 0.1.2. Seeded stochastic workflows use `tnaj`'s portable RNG,
so they replay identically across JavaScript runtimes but do not reproduce R's
random-number stream. Plot-ready results are returned as ordinary typed data;
rendering remains application-owned.

Runnable browser examples are collected in
[`demo/transitiontrees/index.html`](demo/transitiontrees/index.html), covering
fitting, pruning, prediction, mining, tuning, comparison, bootstrap, and groups.
The visualization API returns dependency-free SVG with a white background by
default; pass `{ theme: 'dark' }` to any plot function for dark output.

## Lag Dynamics

`tnaj/lagdynamics` is a typed, dependency-free implementation of the complete
public API of R `lagdynamics` 0.32. It covers classical LSA plus the two-cell,
bidirectional, parallel-dominance, and nonparallel-dominance engines; grouped
and multi-lag analysis; structural-zero IPF; confirmatory inference; group
comparison; transfer entropy; and browser-native SVG visualization.

```typescript
import {
  lsa, transitions, bootstrapLSA, compareLSA,
  plotTransitions, plotForest,
} from 'tnaj/lagdynamics';

const fit = lsa([
  ['Question', 'Explain', 'Agree', 'Elaborate'],
  ['Question', 'Elaborate', 'Explain', 'Agree'],
  ['Disagree', 'Explain', 'Question', 'Agree'],
]);

console.table(transitions(fit, { significant: true }));
const boot = bootstrapLSA(fit, { iterations: 1000, seed: 42 });
document.body.innerHTML = plotForest(boot);
```

The subpath exports camelCase names and exact R-style aliases. Deterministic
quantities are checked against R fixtures to numerical tolerance, while
bootstrap and permutation equality is tested using replay indices. Plotting
includes heatmaps, lag-transition networks, chord diagrams, polar sunbursts,
uncertainty forests, and group-comparison barrel/heatmap views. See the
[interactive gallery](demo/lagdynamics.html).

## MCML Hierarchical Network Plot

`plotMCML()` renders the cograph-style micro/macro hierarchy using tnaj's
network plot-data conventions. It draws original within-cluster edges,
aggregated shell-to-shell edges, the macro cluster network, and dashed
detail-to-summary links. Pass either an existing Nestimate/cograph-shaped
MCML object or a normal `TNA` with named node clusters.

```typescript
import { tna, plotMCML } from 'tnaj';

const network = tna([
  ['Read', 'Annotate', 'Discuss', 'Quiz'],
  ['Read', 'Quiz', 'Discuss', 'Annotate'],
]);

document.body.innerHTML = plotMCML(network, {
  clusters: {
    Study: ['Read', 'Annotate'],
    Social: ['Discuss', 'Quiz'],
  },
  theme: 'rich',
  summaryPie: 'inits', // use 'self' for cluster retention
});
```

Use `mcmlPlotData()` when an application wants to paint the same typed shells,
nodes, and four edge layers with D3, canvas, React, or another renderer. As in
current cograph, `mode: 'tna'` enables edge labels but does not transform an
existing object's weights.

---

## Guides

### Clustering Sequences and Building Per-Cluster Models

A common workflow is to cluster sequences by similarity, then build a separate TNA model for each cluster to compare behavioral patterns across groups.

```typescript
import {
  tna, clusterSequences, centralities, communities, prune, summary,
  colorPalette, createColorMap,
} from 'tnaj';

// 1. Your sequence data
const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'quiz', 'read', 'annotate', 'discuss'],
  ['discuss', 'read', 'annotate', 'read', 'quiz'],
  ['quiz', 'quiz', 'quiz', 'read', 'quiz'],
  ['quiz', 'read', 'quiz', 'quiz', 'quiz'],
  ['read', 'read', 'annotate', 'discuss', 'quiz'],
];

// 2. Cluster sequences into k groups
const k = 2;
const clusters = clusterSequences(sequences, k, {
  dissimilarity: 'lv',   // Levenshtein distance
  method: 'pam',         // Partitioning Around Medoids
});

console.log(clusters.assignments); // e.g. [1, 1, 1, 2, 2, 1] (1-indexed)
console.log(clusters.silhouette);  // Clustering quality (-1 to 1)
console.log(clusters.sizes);       // e.g. [4, 2]

// 3. Split sequences by cluster
const clusterData: Record<string, (string | null)[][]> = {};
for (let i = 0; i < sequences.length; i++) {
  const label = `Cluster ${clusters.assignments[i]}`;
  if (!clusterData[label]) clusterData[label] = [];
  clusterData[label].push(sequences[i]!);
}

// 4. Build a TNA model per cluster
for (const [name, seqs] of Object.entries(clusterData)) {
  const model = tna(seqs);
  const pruned = prune(model, 0.1);
  const cent = centralities(pruned);
  const comm = communities(pruned, { methods: 'louvain' });
  const s = summary(pruned);

  console.log(`\n--- ${name} (${seqs.length} sequences) ---`);
  console.log(`Edges: ${s.nEdges}, Density: ${Number(s.density).toFixed(3)}`);
  console.log(`Communities: ${comm.counts.louvain}`);
  model.labels.forEach((label, i) => {
    console.log(`  ${label}: OutStrength=${cent.measures.OutStrength[i]!.toFixed(3)}`);
  });
}
```

**Choosing dissimilarity metrics:**

| Metric | Best for | Description |
|--------|----------|-------------|
| `hamming` | Equal-length sequences | Counts positional mismatches |
| `lv` | Variable-length sequences | Edit distance (insert, delete, substitute) |
| `osa` | Sequences with transpositions | Edit distance + transpositions |
| `lcs` | Subsequence similarity | Longest common subsequence distance |

**Choosing clustering methods:**

| Method | Description |
|--------|-------------|
| `pam` | Partitioning Around Medoids — robust, finds representative sequences |
| `hierarchical` | Agglomerative clustering with average linkage |

---

### Building a Dashboard with Clusters

This guide shows how to build a multi-panel dashboard that clusters sequences and displays per-cluster networks and centrality charts using D3.js.

**Setup:**

```bash
npm create vite@latest tna-dashboard -- --template vanilla-ts
cd tna-dashboard
npm install tnaj d3
npm install -D @types/d3
```

**`src/main.ts` — Full dashboard:**

```typescript
import {
  tna, clusterSequences, centralities, prune, communities,
  summary, colorPalette, AVAILABLE_MEASURES,
} from 'tnaj';
import type { TNA, CentralityResult } from 'tnaj';
import * as d3 from 'd3';

// ──────────────────────────────────────────
// 1. Data & Clustering
// ──────────────────────────────────────────

const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'quiz', 'read', 'annotate', 'discuss'],
  ['discuss', 'read', 'annotate', 'read', 'quiz'],
  ['quiz', 'quiz', 'quiz', 'read', 'quiz'],
  ['quiz', 'read', 'quiz', 'quiz', 'quiz'],
  ['read', 'read', 'annotate', 'discuss', 'quiz'],
  ['annotate', 'discuss', 'read', 'quiz', 'annotate'],
  ['quiz', 'quiz', 'read', 'quiz', 'read'],
];

const k = 3;
const clusters = clusterSequences(sequences, k, {
  dissimilarity: 'lv',
  method: 'pam',
});

// Split sequences by cluster and build per-cluster models
const clusterGroups = new Map<string, { model: TNA; cent: CentralityResult; size: number }>();
const clusterSeqs: Record<string, (string | null)[][]> = {};

for (let i = 0; i < sequences.length; i++) {
  const label = `Cluster ${clusters.assignments[i]}`;
  if (!clusterSeqs[label]) clusterSeqs[label] = [];
  clusterSeqs[label].push(sequences[i]!);
}

for (const [name, seqs] of Object.entries(clusterSeqs)) {
  const model = tna(seqs);
  const pruned = prune(model, 0.05);
  const cent = centralities(pruned);
  clusterGroups.set(name, { model: pruned, cent, size: seqs.length });
}

// ──────────────────────────────────────────
// 2. Summary Panel
// ──────────────────────────────────────────

const app = document.getElementById('app')!;

const summaryHtml = `
  <h1>TNA Cluster Dashboard</h1>
  <p>Sequences: ${sequences.length} | Clusters: ${k} |
     Silhouette: ${clusters.silhouette.toFixed(3)}</p>
  <p>Sizes: ${clusters.sizes.join(', ')}</p>
`;
app.innerHTML = summaryHtml;

// ──────────────────────────────────────────
// 3. Per-Cluster Network + Centrality Cards
// ──────────────────────────────────────────

const CARD_COLORS = ['#4e79a7', '#e15759', '#59a14f', '#edc948'];
const grid = document.createElement('div');
grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:16px;margin-top:20px';
app.appendChild(grid);

let idx = 0;
for (const [name, { model, cent, size }] of clusterGroups) {
  const color = CARD_COLORS[idx % CARD_COLORS.length]!;
  const s = summary(model);

  const card = document.createElement('div');
  card.style.cssText = 'border:1px solid #ddd;border-radius:8px;padding:16px;background:#fff';
  card.innerHTML = `
    <h3 style="color:${color};margin:0 0 4px">${name}</h3>
    <p style="font-size:13px;color:#888;margin:0 0 12px">
      ${size} sequences · ${s.nEdges} edges · density ${Number(s.density).toFixed(3)}
    </p>
    <div id="network-${idx}" style="width:100%;height:300px"></div>
    <div id="centrality-${idx}" style="width:100%;height:200px;margin-top:12px"></div>
  `;
  grid.appendChild(card);

  // Render network diagram
  requestAnimationFrame(() => {
    renderForceNetwork(
      document.getElementById(`network-${idx}`)!, model, color,
    );
    renderCentralityBars(
      document.getElementById(`centrality-${idx}`)!, cent, model.labels, color,
    );
  });

  idx++;
}

// ──────────────────────────────────────────
// 4. D3 Force-Directed Network Renderer
// ──────────────────────────────────────────

function renderForceNetwork(container: HTMLElement, model: TNA, accentColor: string) {
  const n = model.labels.length;
  const nodeColors = colorPalette(n);

  // Build nodes and links from weight matrix
  const nodes = model.labels.map((label, i) => ({ id: label, index: i }));
  const links: { source: string; target: string; weight: number }[] = [];

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const w = model.weights.get(i, j);
      if (w > 0 && i !== j) {
        links.push({ source: model.labels[i]!, target: model.labels[j]!, weight: w });
      }
    }
  }

  const maxW = Math.max(...links.map(l => l.weight), 0.01);

  const rect = container.getBoundingClientRect();
  const width = Math.max(rect.width, 300);
  const height = 300;

  const svg = d3.select(container).append('svg')
    .attr('width', width).attr('height', height);

  // Arrowhead marker
  svg.append('defs').append('marker')
    .attr('id', 'arrow').attr('viewBox', '0 -5 10 10')
    .attr('refX', 20).attr('refY', 0)
    .attr('markerWidth', 6).attr('markerHeight', 6)
    .attr('orient', 'auto')
    .append('path').attr('d', 'M0,-5L10,0L0,5').attr('fill', '#999');

  const simulation = d3.forceSimulation(nodes as any)
    .force('link', d3.forceLink(links as any).id((d: any) => d.id).distance(80))
    .force('charge', d3.forceManyBody().strength(-200))
    .force('center', d3.forceCenter(width / 2, height / 2));

  const link = svg.selectAll('.link')
    .data(links).enter().append('line')
    .attr('class', 'link')
    .attr('stroke', '#999').attr('stroke-opacity', 0.6)
    .attr('stroke-width', d => Math.max(1, (d.weight / maxW) * 5))
    .attr('marker-end', 'url(#arrow)');

  const node = svg.selectAll('.node')
    .data(nodes).enter().append('circle')
    .attr('r', 12)
    .attr('fill', (_d, i) => nodeColors[i]!)
    .attr('stroke', '#fff').attr('stroke-width', 2);

  const label = svg.selectAll('.label')
    .data(nodes).enter().append('text')
    .text(d => d.id)
    .attr('font-size', '10px').attr('text-anchor', 'middle').attr('dy', '0.35em');

  simulation.on('tick', () => {
    link
      .attr('x1', (d: any) => d.source.x).attr('y1', (d: any) => d.source.y)
      .attr('x2', (d: any) => d.target.x).attr('y2', (d: any) => d.target.y);
    node.attr('cx', (d: any) => d.x).attr('cy', (d: any) => d.y);
    label.attr('x', (d: any) => d.x).attr('y', (d: any) => d.y);
  });
}

// ──────────────────────────────────────────
// 5. Centrality Bar Chart Renderer
// ──────────────────────────────────────────

function renderCentralityBars(
  container: HTMLElement,
  cent: CentralityResult,
  labels: string[],
  accentColor: string,
) {
  const measure = 'OutStrength';
  const values = cent.measures[measure];
  const data = labels.map((label, i) => ({ label, value: values[i]! }))
    .sort((a, b) => b.value - a.value);

  const rect = container.getBoundingClientRect();
  const width = Math.max(rect.width, 300);
  const height = 200;
  const margin = { top: 20, right: 20, bottom: 30, left: 80 };
  const innerW = width - margin.left - margin.right;
  const innerH = height - margin.top - margin.bottom;

  const svg = d3.select(container).append('svg').attr('width', width).attr('height', height);
  const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

  g.append('text').attr('x', innerW / 2).attr('y', -6)
    .attr('text-anchor', 'middle').attr('font-size', '11px').attr('fill', '#666')
    .text(measure);

  const y = d3.scaleBand().domain(data.map(d => d.label)).range([0, innerH]).padding(0.2);
  const x = d3.scaleLinear().domain([0, d3.max(data, d => d.value)! * 1.15]).range([0, innerW]);

  g.selectAll('rect').data(data).enter().append('rect')
    .attr('y', d => y(d.label)!).attr('width', d => x(d.value))
    .attr('height', y.bandwidth()).attr('fill', accentColor).attr('rx', 3);

  g.selectAll('.val').data(data).enter().append('text')
    .attr('x', d => x(d.value) + 4).attr('y', d => y(d.label)! + y.bandwidth() / 2)
    .attr('dy', '0.35em').attr('font-size', '10px').attr('fill', '#666')
    .text(d => d.value.toFixed(3));

  g.append('g').call(d3.axisLeft(y).tickSize(0).tickPadding(6));
  g.append('g').attr('transform', `translate(0,${innerH})`).call(d3.axisBottom(x).ticks(4));
}
```

**`index.html`:**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TNA Cluster Dashboard</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; padding: 24px; background: #f5f5f5; }
    #app { max-width: 1200px; margin: 0 auto; }
    h1 { margin: 0 0 8px; }
  </style>
</head>
<body>
  <div id="app"></div>
  <script type="module" src="/src/main.ts"></script>
</body>
</html>
```

Run with `npm run dev` — you'll see a dashboard with per-cluster network visualizations and centrality bar charts.

**Extending the dashboard:**

```typescript
// Add community detection per cluster
import { communities } from 'tnaj';

for (const [name, { model }] of clusterGroups) {
  const comm = communities(model, { methods: ['louvain', 'walktrap'] });
  console.log(`${name}: ${comm.counts.louvain} communities (Louvain)`);

  // Color nodes by community
  const communityColors = ['#4e79a7', '#e15759', '#59a14f', '#edc948'];
  model.labels.forEach((label, i) => {
    const commId = comm.assignments.louvain![i]!;
    console.log(`  ${label} → Community ${commId} (${communityColors[commId]})`);
  });
}

// Add clique detection
import { cliques } from 'tnaj';

for (const [name, { model }] of clusterGroups) {
  const cl = cliques(model, { threshold: 0.05 });
  console.log(`${name}: ${cl.labels.length} cliques found`);
  cl.labels.forEach((labels, i) => {
    console.log(`  Clique ${i + 1}: ${labels.join(' → ')}`);
  });
}

// Compare patterns across clusters with permutation testing
import { groupTna, compareSequences } from 'tnaj';

// Build group model: flat sequences + parallel cluster labels
const clusterLabels = sequences.map((_s, i) => `Cluster ${clusters.assignments[i]}`);
const gModel = groupTna(sequences, clusterLabels);
const comparison = compareSequences(gModel, {
  sub: [1, 2],      // Compare single states and bigrams
  test: true,        // Run permutation test
  iter: 999,
  seed: 42,
});

for (const row of comparison) {
  if (row.pValue !== undefined && row.pValue < 0.05) {
    console.log(`Significant: ${row.pattern} (p=${row.pValue.toFixed(3)}, ES=${row.effectSize?.toFixed(3)})`);
  }
}
```

---

### Group Comparison Workflow

When your data already has group labels (e.g., experimental vs. control, high vs. low performers), use group models directly:

```typescript
import {
  groupTna, centralities, communities, prune, compareSequences,
  groupNames, groupEntries,
} from 'tnaj';

// All sequences in a flat array
const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'discuss', 'annotate', 'quiz', 'discuss'],
  ['annotate', 'read', 'discuss', 'quiz', 'annotate'],
  ['quiz', 'quiz', 'read', 'quiz', 'quiz'],
  ['read', 'quiz', 'quiz', 'read', 'quiz'],
  ['quiz', 'read', 'quiz', 'quiz', 'read'],
];

// Parallel array of group labels (one per sequence)
const groups = [
  'High Performers', 'High Performers', 'High Performers',
  'Low Performers', 'Low Performers', 'Low Performers',
];

// Build group models in one call
const gModel = groupTna(sequences, groups);

// Centralities across all groups (combined result with group labels)
const cent = centralities(gModel);
console.log(cent.groups);   // ['High Performers', 'High Performers', ..., 'Low Performers', ...]
console.log(cent.labels);   // State labels repeated per group

// Per-group analysis
for (const [name, model] of groupEntries(gModel)) {
  const pruned = prune(model, 0.1);
  const comm = communities(pruned, { methods: 'louvain' });
  console.log(`${name}: ${comm.counts.louvain} communities`);
}

// Statistical comparison: which patterns differ between groups?
const comparison = compareSequences(gModel, {
  sub: [1, 2, 3],   // Unigrams, bigrams, trigrams
  test: true,
  iter: 999,
  adjust: 'bonferroni',
  seed: 42,
});

// Show significant differences
const significant = comparison.filter(r => r.pValue !== undefined && r.pValue < 0.05);
for (const row of significant) {
  console.log(`${row.pattern}: p=${row.pValue!.toFixed(3)}, ES=${row.effectSize?.toFixed(3)}`);
  console.log(`  Proportions:`, row.proportions);
}
```

---

## API Reference

### Model Building

#### `tna(data, options?)`

Build a relative transition probability model.

```typescript
import { tna } from 'tnaj';

const data = [
  ['read', 'write', 'discuss', 'read'],
  ['write', 'discuss', 'read', 'write'],
];

const model = tna(data);
```

**Parameters:**
- `data` — `SequenceData | TNAData | number[][]` — Input data (see [Data Format](#data-format))
- `options.scaling` — `string | string[] | null` — Scaling to apply: `'minmax'`, `'max'`, `'rank'`, or array of these
- `options.labels` — `string[]` — Override auto-detected state labels
- `options.beginState` — `string` — Add artificial begin state
- `options.endState` — `string` — Add artificial end state

**Returns:** `TNA` object

#### `ftna(data, options?)`

Build a frequency (raw count) model. Same parameters as `tna()`.

```typescript
import { ftna } from 'tnaj';

const model = ftna(data);
// model.weights contains raw transition counts
```

#### `ctna(data, options?)`

Build a co-occurrence model. Same parameters as `tna()`.

```typescript
import { ctna } from 'tnaj';

const model = ctna(data);
// model.weights contains bidirectional co-occurrence counts
```

#### `atna(data, options?)`

Build an attention-weighted model with exponential decay.

```typescript
import { atna } from 'tnaj';

const model = atna(data, { beta: 0.1 });
// Recent transitions receive higher weights
```

**Additional parameter:**
- `options.beta` — `number` — Decay parameter (default: `0.1`). Higher values = stronger recency weighting.

#### `buildModel(data, options?)`

Generic model builder. Use this for advanced model types.

```typescript
import { buildModel } from 'tnaj';

// Build from a pre-computed weight matrix
const model = buildModel([
  [0, 0.3, 0.7],
  [0.5, 0, 0.5],
  [0.6, 0.4, 0],
], {
  type: 'matrix',
  labels: ['A', 'B', 'C'],
});
```

**All model types:** `'relative'`, `'frequency'`, `'co-occurrence'`, `'reverse'`, `'n-gram'`, `'gap'`, `'window'`, `'attention'`, `'matrix'`

#### `summary(model)`

Get a summary of model properties.

```typescript
import { tna, summary } from 'tnaj';

const s = summary(tna(data));
// {
//   nStates: 3,
//   type: 'relative',
//   nEdges: 6,
//   density: 0.667,
//   meanWeight: 0.333,
//   maxWeight: 0.5,
//   hasSelfLoops: false,
// }
```

---

### Centralities

#### `centralities(model, options?)`

Compute 9 centrality measures for each state in the network.

```typescript
import { tna, centralities, AVAILABLE_MEASURES } from 'tnaj';

const model = tna(data);
const cent = centralities(model);

// Access individual measures
cent.measures.OutStrength;      // Float64Array — weighted out-degree
cent.measures.InStrength;       // Float64Array — weighted in-degree
cent.measures.Betweenness;      // Float64Array — shortest-path betweenness
cent.measures.BetweennessRSP;   // Float64Array — randomized shortest-path betweenness
cent.measures.ClosenessIn;      // Float64Array — in-closeness
cent.measures.ClosenessOut;     // Float64Array — out-closeness
cent.measures.Closeness;        // Float64Array — undirected closeness
cent.measures.Diffusion;        // Float64Array — diffusion centrality
cent.measures.Clustering;       // Float64Array — weighted clustering coefficient

// Labels are aligned with measure arrays
cent.labels; // ['A', 'B', 'C']

// List all available measures
console.log(AVAILABLE_MEASURES);
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `options.loops` — `boolean` — Include self-loops (default: `true`)
- `options.normalize` — `boolean` — Normalize measures (default: `false`)
- `options.measures` — `CentralityMeasure[]` — Subset of measures to compute

**Returns:** `CentralityResult`

#### `betweennessNetwork(model)`

Replace edge weights with edge betweenness centrality values.

```typescript
import { tna, betweennessNetwork } from 'tnaj';

const bModel = betweennessNetwork(tna(data));
// bModel.weights now contains edge betweenness values
```

---

### Pruning

#### `prune(model, threshold?)`

Remove edges below a weight threshold.

```typescript
import { tna, prune } from 'tnaj';

const model = tna(data);
const pruned = prune(model, 0.1);
// All edges with weight < 0.1 are set to 0
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `threshold` — `number` — Weight threshold (default: `0.1`)

**Returns:** `TNA` (or `Record<string, TNA>` for GroupTNA)

---

### Community Detection

#### `communities(model, options?)`

Detect communities (clusters of densely connected nodes).

```typescript
import { tna, communities, AVAILABLE_METHODS } from 'tnaj';

const model = tna(data);

// Single method
const comm = communities(model, { methods: 'louvain' });
console.log(comm.assignments.louvain);  // [0, 1, 0] — community per node
console.log(comm.counts.louvain);       // 2 — number of communities

// Multiple methods at once
const commAll = communities(model, {
  methods: ['louvain', 'fast_greedy', 'walktrap'],
});

// Available methods
console.log(AVAILABLE_METHODS);
// ['fast_greedy', 'louvain', 'label_prop', 'leading_eigen', 'edge_betweenness', 'walktrap']
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `options.methods` — `CommunityMethod | CommunityMethod[]` — Detection method(s)

**Returns:** `CommunityResult`

---

### Clique Detection

#### `cliques(model, options?)`

Find fully connected subgraphs (cliques) above a weight threshold.

```typescript
import { tna, cliques } from 'tnaj';

const model = tna(data);
const cl = cliques(model, { threshold: 0.05 });
console.log(cl.labels);   // [['A', 'B'], ['B', 'C']] — labels per clique
console.log(cl.size);     // 2 — minimum clique size
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `options.threshold` — `number` — Minimum edge weight (default: `0.05`)

**Returns:** `CliqueResult`

---

### Sequence Clustering

#### `clusterSequences(data, k, options?)`

Cluster sequences based on pairwise distances.

```typescript
import { clusterSequences } from 'tnaj';

const data = [
  ['A', 'B', 'C'],
  ['A', 'B', 'C'],
  ['C', 'B', 'A'],
  ['C', 'B', 'A'],
];

const result = clusterSequences(data, 2, {
  dissimilarity: 'hamming',
  method: 'pam',
});

console.log(result.assignments);  // [1, 1, 2, 2]
console.log(result.silhouette);   // 0.75 — clustering quality (-1 to 1)
console.log(result.sizes);        // [2, 2]
```

**Parameters:**
- `data` — `SequenceData | TNAData`
- `k` — `number` — Number of clusters (must be >= 2)
- `options.dissimilarity` — `'hamming' | 'lv' | 'osa' | 'lcs'` — Distance metric (default: `'hamming'`)
  - `'hamming'` — Positional mismatches
  - `'lv'` — Levenshtein (edit distance: insert, delete, substitute)
  - `'osa'` — Optimal string alignment (edit distance + transpositions)
  - `'lcs'` — Longest common subsequence distance
- `options.method` — `'pam' | string` — Clustering algorithm (default: `'pam'`)
  - `'pam'` — Partitioning Around Medoids (like k-medoids)
  - Any other string — Hierarchical clustering (average linkage)
- `options.weighted` — `boolean` — Position-weighted Hamming (default: `false`)
- `options.lambda` — `number` — Exponential decay for weighted Hamming (default: `1`)

**Returns:** `ClusterResult`

---

### Sequence Comparison

#### `compareSequences(groupModel, options?)`

Compare subsequence patterns between groups (e.g., high vs. low performers).

```typescript
import { groupTna, compareSequences } from 'tnaj';

const sequences = [['A', 'B', 'C'], ['A', 'C', 'B'], ['C', 'B', 'A'], ['C', 'A', 'B']];
const groups = ['high', 'high', 'low', 'low'];
const gModel = groupTna(sequences, groups);

const result = compareSequences(gModel, {
  sub: [1, 2],
  minFreq: 0,
});

// Each row: { pattern, frequencies, proportions, effectSize?, pValue? }
for (const row of result) {
  console.log(row.pattern, row.frequencies, row.proportions);
}

// With permutation testing for statistical significance
const tested = compareSequences(gModel, {
  sub: [1, 2, 3],
  test: true,
  iter: 999,
  adjust: 'bonferroni',
  seed: 42,
});

for (const row of tested) {
  if (row.pValue !== undefined && row.pValue < 0.05) {
    console.log(`${row.pattern}: p=${row.pValue.toFixed(3)}, ES=${row.effectSize?.toFixed(3)}`);
  }
}
```

**Parameters:**
- `groupModel` — `GroupTNA` — Group model built with `groupTna()`, `groupFtna()`, etc.
- `options.sub` — `number[]` — Subsequence lengths to compare (default: `[1, 2, 3]`)
- `options.minFreq` — `number` — Minimum frequency threshold (default: `0`)
- `options.test` — `boolean` — Run permutation test (default: `false`)
- `options.iter` — `number` — Number of permutation iterations (default: `999`)
- `options.adjust` — `string` — P-value adjustment method: `'bonferroni'`, `'holm'`, `'fdr'`, `'BH'`, `'none'` (default: `'bonferroni'`)
- `options.seed` — `number` — Random seed for reproducibility

**Returns:** `CompareRow[]`

---

### Group Models

Build and analyze TNA models for multiple groups simultaneously.

```typescript
import { groupTna, centralities, communities, prune, groupNames, groupEntries } from 'tnaj';

// All sequences in a flat array, with a parallel array of group labels
const sequences = [
  ['A', 'B', 'C'],    // high
  ['A', 'C', 'B'],    // high
  ['C', 'B', 'A'],    // low
  ['C', 'A', 'B'],    // low
];
const groups = ['high', 'high', 'low', 'low'];

// Build group models
const gModel = groupTna(sequences, groups);

// List group names
console.log(groupNames(gModel)); // ['high', 'low']

// Iterate over groups
for (const [name, model] of groupEntries(gModel)) {
  console.log(name, model.labels);
}

// All analysis functions accept GroupTNA directly
const cent = centralities(gModel);       // Combined centralities with group labels
const pruned = prune(gModel, 0.1);       // { high: TNA, low: TNA }
const comm = communities(gModel);        // { high: CommunityResult, low: CommunityResult }
```

#### Group builder functions

| Function | Signature | Description |
|----------|-----------|-------------|
| `groupTna(data, groups)` | `(SequenceData, string[])` | Relative transition probabilities per group |
| `groupFtna(data, groups)` | `(SequenceData, string[])` | Frequency counts per group |
| `groupCtna(data, groups)` | `(SequenceData, string[])` | Co-occurrence per group |
| `groupAtna(data, groups)` | `(SequenceData, string[])` | Attention-weighted per group |
| `createGroupTNA(models)` | `(Record<string, TNA>)` | Create from pre-built TNA objects |

---

### Data Preparation

#### `prepareData(data, options?)`

Prepare raw sequence data into a `TNAData` container with summary statistics.

```typescript
import { prepareData } from 'tnaj';

const raw = [
  ['read', 'write', 'discuss'],
  ['write', 'read', null, 'discuss'],
];

const prepared = prepareData(raw);
console.log(prepared.labels);           // ['discuss', 'read', 'write']
console.log(prepared.statistics);
// {
//   nSessions: 2,
//   nUniqueActions: 3,
//   uniqueActions: ['discuss', 'read', 'write'],
//   maxSequenceLength: 4,
//   meanSequenceLength: 3.5,
// }
```

#### `createSeqdata(data, options?)`

Lower-level function to clean sequence data and detect labels.

```typescript
import { createSeqdata } from 'tnaj';

const { data, labels } = createSeqdata(rawData, {
  beginState: 'START',
  endState: 'END',
});
```

#### `importOnehot(data, window, step?)`

Import windowed one-hot encoded data for TNA analysis.

```typescript
import { importOnehot } from 'tnaj';

const onehot = importOnehot(rawData, 5, 1);
```

---

### Utility Functions

#### Matrix operations

```typescript
import { Matrix, rowNormalize, minmaxScale, maxScale, rankScale } from 'tnaj';

// Create matrices
const m = Matrix.zeros(3, 3);
const m2 = Matrix.from2D([[1, 2], [3, 4]]);

// Access
m.get(0, 1);
m.set(0, 1, 0.5);
m.rows;  // number of rows
m.cols;  // number of columns

// Operations
const norm = rowNormalize(m2);     // Row-normalize
const mm = minmaxScale(m2);        // Min-max scale
const mx = maxScale(m2);           // Max scale
const rk = rankScale(m2);          // Rank scale
```

#### Color utilities

```typescript
import {
  colorPalette, DEFAULT_COLORS, createColorMap,
  hexToRgb, rgbToHex, lightenColor, darkenColor,
} from 'tnaj';

const colors = colorPalette(5);                       // Get 5 distinct colors
const map = createColorMap(['A', 'B', 'C']);           // { A: '#...', B: '#...', C: '#...' }
const [r, g, b] = hexToRgb('#4e79a7');                // [78, 121, 167]
const lighter = lightenColor('#4e79a7', 0.3);         // Lighten by 30%
```

#### Statistical utilities

```typescript
import { arrayMean, arrayStd, pearsonCorr, arrayQuantile } from 'tnaj';

const arr = new Float64Array([1, 2, 3, 4, 5]);
arrayMean(arr);              // 3
arrayStd(arr);               // ~1.58 (sample std, ddof=1)
arrayQuantile(arr, 0.5);     // 3 (median)

const a = new Float64Array([1, 2, 3]);
const b = new Float64Array([2, 4, 6]);
pearsonCorr(a, b);           // 1.0
```

#### Seeded RNG

```typescript
import { SeededRNG } from 'tnaj';

const rng = new SeededRNG(42);
rng.random();     // Deterministic float in [0, 1)
rng.randint(10);  // Deterministic integer in [0, 10)
```

---

## Using in a Website

### With a Bundler

The recommended approach for production websites. Works with Vite, Webpack, Rollup, esbuild, Parcel, etc.

**1. Install:**

```bash
npm install tnaj
```

**2. Import and use in your code:**

```typescript
// app.ts or app.js
import { tna, centralities, prune, communities, summary } from 'tnaj';

const data = [
  ['login', 'browse', 'search', 'purchase'],
  ['login', 'search', 'browse', 'logout'],
  ['login', 'browse', 'browse', 'purchase'],
];

const model = tna(data);
const cent = centralities(model);

// Render results in the DOM
const el = document.getElementById('results')!;
el.innerHTML = model.labels.map((label, i) => {
  return `<div>${label}: OutStrength=${cent.measures.OutStrength[i]!.toFixed(3)}</div>`;
}).join('');
```

**3. Vite example config:**

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
export default defineConfig({
  // tnaj is a standard ESM/CJS package — no special config needed
});
```

**4. Webpack example config:**

```javascript
// webpack.config.js
module.exports = {
  resolve: {
    extensions: ['.ts', '.js'],
  },
  module: {
    rules: [
      { test: /\.ts$/, use: 'ts-loader', exclude: /node_modules/ },
    ],
  },
};
```

### From a CDN

For quick prototyping or simple pages without a build step. Use [esm.sh](https://esm.sh), [jsDelivr](https://www.jsdelivr.com/), or [unpkg](https://unpkg.com/).

```html
<!DOCTYPE html>
<html>
<head>
  <title>TNA Demo</title>
</head>
<body>
  <div id="output"></div>

  <script type="module">
    // Import from CDN
    import { tna, centralities, prune, summary } from 'https://esm.sh/tnaj';

    const data = [
      ['A', 'B', 'C', 'A'],
      ['B', 'C', 'A', 'B'],
      ['A', 'A', 'B', 'C'],
    ];

    const model = tna(data);
    const cent = centralities(model);
    const s = summary(model);

    document.getElementById('output').innerHTML = `
      <h2>TNA Model (${s.type})</h2>
      <p>States: ${model.labels.join(', ')}</p>
      <p>Edges: ${s.nEdges}, Density: ${Number(s.density).toFixed(3)}</p>
      <h3>OutStrength</h3>
      <ul>
        ${model.labels.map((l, i) =>
          `<li>${l}: ${cent.measures.OutStrength[i].toFixed(4)}</li>`
        ).join('')}
      </ul>
    `;
  </script>
</body>
</html>
```

### Server-Side

**Node.js (ESM):**

```typescript
import { tna, centralities } from 'tnaj';

const data = [['A', 'B', 'C'], ['B', 'C', 'A']];
const model = tna(data);
const cent = centralities(model);
console.log(cent.measures.OutStrength);
```

**Node.js (CommonJS):**

```javascript
const { tna, centralities } = require('tnaj');

const data = [['A', 'B', 'C'], ['B', 'C', 'A']];
const model = tna(data);
const cent = centralities(model);
console.log(cent.measures.OutStrength);
```

**Deno:**

```typescript
import { tna, centralities } from 'npm:tnaj';

const data = [['A', 'B', 'C'], ['B', 'C', 'A']];
const model = tna(data);
console.log(centralities(model));
```

**Bun:**

```typescript
import { tna, centralities } from 'tnaj';
// Same API as Node.js ESM
```

---

## Data Format

### Sequence Data (primary input)

A 2D array where each row is a sequence of state labels (strings). Sequences can have different lengths. Use `null` for missing values.

```typescript
const data: SequenceData = [
  ['read', 'write', 'discuss', 'read'],
  ['write', 'discuss', null, 'read'],    // null = missing
  ['read', 'read', 'write'],             // shorter sequence is fine
];
```

### Direct Weight Matrix

A square 2D number array where `matrix[i][j]` is the weight from state `i` to state `j`.

```typescript
const matrix = [
  [0.0, 0.3, 0.7],
  [0.5, 0.0, 0.5],
  [0.6, 0.4, 0.0],
];

const model = tna(matrix, { labels: ['A', 'B', 'C'] });
```

### Grouped Data

A flat sequence array with a parallel array of group labels.

```typescript
const sequences = [
  ['A', 'B', 'C'],  // experimental
  ['A', 'C', 'B'],  // experimental
  ['C', 'B', 'A'],  // control
  ['C', 'A', 'B'],  // control
];
const groups = ['experimental', 'experimental', 'control', 'control'];

const gModel = groupTna(sequences, groups);
```

Or create from pre-built TNA models:

```typescript
import { tna, createGroupTNA } from 'tnaj';

const models = {
  experimental: tna([['A', 'B', 'C'], ['A', 'C', 'B']]),
  control: tna([['C', 'B', 'A'], ['C', 'A', 'B']]),
};
const gModel = createGroupTNA(models);
```

---

## Types Reference

```typescript
/** A sequence: array of string states (null = missing). */
type Sequence = (string | null)[];

/** Sequence dataset: array of sequences. */
type SequenceData = Sequence[];

/** TNA model object. */
interface TNA {
  weights: Matrix;          // n_states x n_states adjacency matrix
  inits: Float64Array;      // Initial state probabilities
  labels: string[];         // State labels
  data: SequenceData | null;
  type: ModelType;
  scaling: string[];
}

/** Group of TNA models. */
interface GroupTNA {
  models: Record<string, TNA>;
}

/** Centrality result. */
interface CentralityResult {
  labels: string[];
  measures: Record<CentralityMeasure, Float64Array>;
  groups?: string[];       // Present for GroupTNA input
}

/** Centrality measures. */
type CentralityMeasure =
  | 'OutStrength' | 'InStrength'
  | 'ClosenessIn' | 'ClosenessOut' | 'Closeness'
  | 'Betweenness' | 'BetweennessRSP'
  | 'Diffusion' | 'Clustering';

/** Community detection result. */
interface CommunityResult {
  counts: Record<string, number>;       // method → number of communities
  assignments: Record<string, number[]>; // method → community per node
  labels: string[];
}

/** Community detection methods. */
type CommunityMethod =
  | 'fast_greedy' | 'louvain' | 'label_prop'
  | 'leading_eigen' | 'edge_betweenness' | 'walktrap';

/** Clique detection result. */
interface CliqueResult {
  weights: Matrix[];    // Weight sub-matrices per clique
  indices: number[][];  // Node indices per clique
  labels: string[][];   // Node labels per clique
  size: number;
  threshold: number;
}

/** Cluster result. */
interface ClusterResult {
  data: SequenceData;
  k: number;
  assignments: number[];    // 1-indexed cluster labels
  silhouette: number;       // Silhouette score (-1 to 1)
  sizes: number[];
  method: string;
  distance: Matrix;
  dissimilarity: string;
}

/** Sequence comparison result row. */
interface CompareRow {
  pattern: string;
  frequencies: Record<string, number>;
  proportions: Record<string, number>;
  effectSize?: number;
  pValue?: number;
}
```

---

## Full Example: Analyzing Student Learning Behavior

```typescript
import {
  tna, ftna, centralities, prune, communities, clusterSequences,
  summary, AVAILABLE_MEASURES,
} from 'tnaj';

// Student learning activity sequences
const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'quiz', 'read', 'annotate', 'discuss'],
  ['discuss', 'read', 'annotate', 'read', 'quiz'],
  ['quiz', 'read', 'discuss', 'annotate', 'quiz'],
  ['read', 'read', 'annotate', 'discuss', 'quiz'],
];

// 1. Build model
const model = tna(sequences);
const s = summary(model);
console.log(`States: ${s.nStates}, Edges: ${s.nEdges}, Density: ${s.density}`);

// 2. Centralities — find most important states
const cent = centralities(model);
model.labels.forEach((label, i) => {
  console.log(`${label}: OutStrength=${cent.measures.OutStrength[i]!.toFixed(3)}, ` +
    `Betweenness=${cent.measures.Betweenness[i]!.toFixed(3)}`);
});

// 3. Prune weak connections
const pruned = prune(model, 0.15);
const ps = summary(pruned);
console.log(`After pruning: ${ps.nEdges} edges remain`);

// 4. Communities — find clusters of related activities
const comm = communities(model, { methods: 'louvain' });
model.labels.forEach((label, i) => {
  console.log(`${label} → Community ${comm.assignments.louvain![i]}`);
});

// 5. Cluster students by behavior similarity
const clusters = clusterSequences(sequences, 2, {
  dissimilarity: 'lv',
  method: 'pam',
});
console.log(`Silhouette: ${clusters.silhouette.toFixed(3)}`);
console.log(`Assignments: ${clusters.assignments}`);
```

---

## Citation

If you use TNA in your research, please cite:

> Saqr, M., Lopez-Pernas, S., Tormanen, T., Kaliisa, R., Misiejuk, K., & Tikka, S. (2025). Transition Network Analysis: A Novel Framework for Modeling, Visualizing, and Identifying the Temporal Patterns of Learners and Learning Processes. In *Proceedings of the 15th International Learning Analytics and Knowledge Conference (LAK '25)*, 351-361. https://doi.org/10.1145/3706468.3706513

```bibtex
@inproceedings{saqr2025tna,
  title     = {Transition Network Analysis: A Novel Framework for Modeling,
               Visualizing, and Identifying the Temporal Patterns of Learners
               and Learning Processes},
  author    = {Saqr, Mohammed and L{\'o}pez-Pernas, Sonsoles and
               T{\"o}rm{\"a}nen, Tiina and Kaliisa, Rogers and
               Misiejuk, Kamila and Tikka, Santtu},
  booktitle = {Proceedings of the 15th International Learning Analytics
               and Knowledge Conference (LAK '25)},
  pages     = {351--361},
  year      = {2025},
  publisher = {Association for Computing Machinery},
  doi       = {10.1145/3706468.3706513},
}
```

**Key references:**

- Saqr, M., Lopez-Pernas, S., Tormanen, T., Kaliisa, R., Misiejuk, K., & Tikka, S. (2025). Transition Network Analysis: A Novel Framework for Modeling, Visualizing, and Identifying the Temporal Patterns of Learners and Learning Processes. In *Proceedings of LAK '25*, 351-361. https://doi.org/10.1145/3706468.3706513

- Tikka, S., Lopez-Pernas, S., & Saqr, M. (2025). tna: An R Package for Transition Network Analysis. *Applied Psychological Measurement*. https://doi.org/10.1177/01466216251348840

- Saqr, M., Lopez-Pernas, S., & Tikka, S. (2025). Mapping relational dynamics with transition network analysis: A primer and tutorial. In *Advanced Learning Analytics Methods: AI, Precision and Complexity*. Springer.

- Saqr, M., Lopez-Pernas, S., & Tikka, S. (2025). Capturing the breadth and dynamics of the temporal process with frequency transition network analysis. In *Advanced Learning Analytics Methods: AI, Precision and Complexity*. Springer.

- Lopez-Pernas, S., Tikka, S., & Saqr, M. (2025). Mining patterns and clusters with transition network analysis: A heterogeneity approach. In *Advanced Learning Analytics Methods: AI, Precision and Complexity*. Springer.

---

## Related Projects

| Project | Language | Links |
|---------|----------|-------|
| **tna** | R | [CRAN](https://cran.r-project.org/package=TNA) · [GitHub](https://github.com/sonsoleslp/tna) |
| **tna** | Python | [PyPI](https://pypi.org/project/tna/) · [GitHub](https://github.com/mohsaqr/tnapy) |
| **tnaj** | TypeScript/JS | [npm](https://www.npmjs.com/package/tnaj) · [GitHub](https://github.com/mohsaqr/tna-js) |
| **TNA Desktop** | Web app | [Launch](https://saqr.me/tnadesktop/) · [GitHub](https://github.com/mohsaqr/tna-desktop) |

---

## License

MIT
