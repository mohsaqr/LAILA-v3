# ladyna API documentation

Complete reference for every module, function, and capability of **ladyna**
(v1.8.x). Every signature and example in these pages is verified against the
built library; the availability matrix is machine-generated from it.

## Start here

- **[Entry points & bundle variants](entry-points.md)** — which subpath
  exposes what (`ladyna` vs `ladyna/light` vs `ladyna/full` vs module subpaths),
  and why LSA plots or `seqindic` may be "missing" from a variant.
- **[Plot catalogue](plots.md)** — generated table of all 59 painters: what each
  one draws, what it takes, and the exact name to import from each subpath
  (five LSA painters are **renamed at root**). Regenerate with
  `node tools/generate-plots-index.mjs`.
- **[Export availability matrix](exports.md)** — generated table: 586 runtime
  exports × 12 subpaths. The authoritative answer to "is X exposed from Y?"
  Regenerate with `node tools/generate-export-matrix.mjs` after changing any
  entry point.

## Modules

| Page | Subpath | R reference | Covers |
|---|---|---|---|
| [core.md](core.md) | `ladyna/core` | `tna` 1.2.3 | Model factories (`tna`/`ftna`/`ctna`/`atna`), `Matrix`, data preparation, groups, `SeededRNG`, colors, drawing geometry, `plotNetwork` |
| [analysis.md](analysis.md) | `ladyna/analysis` | `tna` 1.2.3 (+ Nestimate interfaces for the Bayesian verbs) | Centralities, bootstrap, permutation, stability, reliability, pruning, communities, cliques, clustering, comparison, simulation, Markov-order, DFG, certainty/bayesCompare/entropyBayes |
| [motifs.md](motifs.md) | `ladyna/analysis` | `cograph` 2.4.5 | Complete 16-type directed triad census, named weighted subnetworks, null-model inference + 4 SVG views |
| [hon.md](hon.md) | `ladyna/analysis` | `Nestimate` 0.8.5 | MOGEN, HON/HON+, HYPA, HONEM, path dependence, pathways, MCML build/aggregate, MMM |
| [sequences.md](sequences.md) | `ladyna/sequences` | `TraMineR` 2.2.13 | `seqindic` + all 28 indicators, precarity family, row primitives |
| [stats.md](stats.md) | `ladyna/stats` | base R / `p.adjust` | Correlations (Spearman, Kendall, distance, RV), p-value adjustment |
| [htna.md](htna.md) | `ladyna/htna` | `htna` | HTNA models, meta-paths, `plotHTNA`, `plotMCML` |
| [transitiontrees.md](transitiontrees.md) | `ladyna/transitiontrees` | `transitiontrees` 0.1.2 | Suffix trees: fit, smooth, prune, predict, mine, tune, compare, bootstrap + 12 painters |
| [lagdynamics.md](lagdynamics.md) | `ladyna/lagdynamics` | `lagdynamics` 0.32 | LSA engines, grouped/multi-lag, IPF, inference, transfer entropy + 7 painters |
| [processmining.md](processmining.md) | `ladyna/processmining` | bupaR conventions | Event logs, analytics, process maps, conformance, discovery, replay + painters |
| [association.md](association.md) | `ladyna/association` | `arules` 1.7.11 | Apriori/Eclat/FP-growth/WARM, significance, rule clustering + 15 painters and an interactive explorer |
| [topology.md](topology.md) | `ladyna/analysis` (also on `light`) | `Nestimate` 0.8.5 | Simplicial complexes, Q-analysis, Betti numbers, persistent homology + landscapes, hypergraphs |

## Visualization at a glance

**[plots.md](plots.md) is the full catalogue** — 59 painters under 64 camelCase
names (5 renamed at root) plus 9 snake_case aliases, 73 exported names in all.
Every painter returns a **self-contained SVG string**
(`el.innerHTML = plotX(...)`) — no D3, no runtime dependencies. The generic
network view for any TNA model is `plotNetwork(model)` ([core.md](core.md)).
Per-family painters are documented in full on their module pages; the in-repo
agent skill `.claude/skills/ladyna-viz/` carries the same catalogue in
decision-table form.
Live galleries: `npm run demo` (`demo/motifs.html`, `demo/association.html`, `demo/processmining.html`, `demo/mcml.html`,
`demo/lagdynamics.html`, `demo/transitiontrees/`).

Every demo page has a stable `#technical-reference` section generated from its
source at build time. It lists the public import statement, exact function calls
used on that page, output contract, source modules, package version, canonical
API link, and copyable per-function permalinks. Navigation-only and precomputed
validation pages are identified explicitly instead of being assigned fictional
runtime calls.

## Conventions

- **Numerical parity**: each module answers to the R package listed above
  (tolerances 1e-10 to 1e-15; see `*-r-groundtruth.test.ts`). "Differs from
  a *different* R package" is not a defect.
- **Seeds**: every stochastic verb takes a `seed` and replays identically
  across JS runtimes (but does not reproduce R's random stream).
- **GroupTNA dispatch**: verbs that accept `TNA | GroupTNA` return a
  `Record<groupName, result>` for groups.
- **snake_case aliases**: most verbs also export an R-style alias
  (`plot_process_map`, `event_log`, …), listed per page.
