# ladyna export availability matrix

**Generated** by `tools/generate-export-matrix.mjs` from the built library —
do not edit by hand. Answers "is X exposed from Y?" for every runtime
export. ✓ = importable from that subpath. 586 exports across
12 subpaths. (Types are documented per module in docs/api/.)

`ladyna/wasm` and `ladyna/wasm/web` mirror `ladyna/light` plus the 10 WASM
kernel names; `ladyna/full/web` mirrors `ladyna/full` (web WASM loader).

| export | root | core | analysis | sequences | stats | htna | transitiontrees | lagdynamics | processmining | association | light | full |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `ACCENT_PALETTE` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `activity_stats` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `activityStats` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `aggregateCases` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `aggregateMCMLWeights` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `analyseCovariate` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `anova` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `applyCanvasLock` | ✓ |  |  |  |  |  |  |  | ✓ |  |  | ✓ |
| `applyIntervalWindowing` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `applyScaling` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `applyWindowing` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `apriori` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `arrayMean` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `arrayQuantile` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `arrayStd` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `as_htna` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `as_tna` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `asEventLog` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `asHTNA` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `asMetric` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `associatePatterns` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `associationForceLayout` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationGraphData` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationMatrixData` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationMeasures` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationNetworkData` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationRuleDistance` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationRuleKey` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationRuleSimilarity` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `associationScatterData` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `asTNA` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `atna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `attachProcessMapDrag` | ✓ |  |  |  |  |  |  |  | ✓ |  |  | ✓ |
| `AVAILABLE_MEASURES` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `AVAILABLE_METHODS` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `barTextColor` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `bayes_compare_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `bayesCompare` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `bayesCompareLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `bettiNumbers` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `betweennessNetwork` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `bipartiteGroups` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `bootstrap_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `bootstrapHtna` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `bootstrapLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `bootstrapPathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `bootstrapTna` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `bootstrapWtna` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `bottleneckDistance` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `build_mcml` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildDFG` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildDFGFromSequences` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildHon` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildHonem` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildHypa` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildHypergraph` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `buildMCML` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildModel` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildMogen` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildSimplicial` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildSimplicialKgrams` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `buildSimplicialPathway` |  |  | ✓ |  |  |  |  |  |  |  |  |  |
| `buildWtnaMatrix` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `case_metrics` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `casedropReliability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `caseMetrics` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `centralities` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `centralityStability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `certainty` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `certainty_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `certaintyLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `chainStructure` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `check_conformance` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `chisqTest` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `chiSqUpperTail` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `classifyTriad` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `cliqueExpansion` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `cliques` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `cluster_summary` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `clusterAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `clusterCovariates` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `clusterData` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `clusterFromDistance` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `clusterMmm` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `clusterQuality` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `clusterSequences` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `clusterSummary` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `colorPalette` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `commonPathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `communities` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `compare_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `compareGroups` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `compareLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `compareModels` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `comparePruning` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `compareSequences` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `compareSmoothing` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `compareTrees` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `compareWeightMatrices` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `computeDendrogram` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `computeTransitions` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `computeTransitions3D` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `computeWeightsFrom3D` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `computeWeightsFromMatrix` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `computeWithinWindow` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `computeWtnaTransitions` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `confidenceBoost` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `conformance` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `contextTree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `contextTreeGroups` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `convert` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `countPatternInSequence` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `createColorMap` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `createGroupTNA` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `createSeqdata` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `createTNA` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `ctna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `darkenColor` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `DEFAULT_COLORS` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `degreeDistribution` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `describeGroups` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `describeNumeric` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ |  |
| `designMatrix` | ✓ | ✓ |  |  |  |  |  |  |  |  |  | ✓ |
| `detectCommunities` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `differenceNetworkData` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `diffNetworks` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `discoverPatterns` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `dissassoc` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `disscenter` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `dissvar` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `distanceCorr` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `divergentPathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `dragPosition` | ✓ |  |  |  |  |  |  |  | ✓ |  |  | ✓ |
| `dunnTest` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `dwell_times` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `dwellTimes` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `eclat` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `EDGE_COLOR_NEGATIVE` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `EDGE_COLOR_POSITIVE` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `edgeCaseDropStability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `edgeKey` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `edgeMetricValue` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `effectSizes` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `eigenDominantLeft` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `END_SENTINEL` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `END_SENTINEL_ALT` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `endActivities` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `entropyBayes` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `entropyProfile` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `estimateCS` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `estimateCsWtna` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `estimateEdgeStability` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `estimateNetworkStability` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `eulerCharacteristic` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `evaluateAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `event_log` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `eventLog` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `extract_motif_subnetwork` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `extract_triads` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `extractLast` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `extractMetaPaths` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `extractMotifSubnetwork` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `extractTrajectories` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `extractTriads` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `extractTuples` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `factorLevels` |  |  |  |  |  |  | ✓ |  |  |  |  |  |
| `filterAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `findRepresentatives` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `fisherExact2x2` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `fisherExactRule` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `fitLinear` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `fitLogistic` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `fitMultinom` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `formatAssociationRule` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `formatDuration` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `formatDurationAuto` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `formatItemset` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `formatMetricValue` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `formatPaths` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `formatPatternLabel` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `fpGrowth` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `frequency` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `ftna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `g2Statistic` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `gamesHowell` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `generateAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `generateTreeSequences` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `get_lsa_engine` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `getLSAEngine` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `goodness` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `goodnessOf` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `goodnessScores` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `groupApply` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `groupAtna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `groupCtna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `groupEntries` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `groupFtna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `groupNames` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `groupPathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `groupTna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `hedgesG` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `heuristic_miner` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `heuristicMiner` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `hexToRgb` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `honPathways` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `htna` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `HTNA_COLOR_PALETTE` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `HTNA_SHAPE_PALETTE` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `htnaFromLong` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `htnaPlotData` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `hypaPathways` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `hyperConfidence` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `hypergraphCentrality` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `hypergraphMeasures` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `hyperLift` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `importOnehot` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `imputeSequences` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `inductive_miner` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `inductiveMiner` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `initial` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `initTnaw` |  |  |  |  |  |  |  |  |  |  |  | ✓ |
| `initWasm` |  |  |  |  |  |  |  |  |  |  |  | ✓ |
| `injectSentinels` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `interestMeasure` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `invertMatrix` |  |  | ✓ |  |  |  |  |  |  |  |  |  |
| `isEventLog` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `isGroupTNA` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `isHtna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `isNumericColumn` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `isObserved` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `isPerformance` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `isSentinelSequence` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `isTnawReady` |  |  |  |  |  |  |  |  |  |  |  | ✓ |
| `isWasmEnabled` |  |  |  |  |  |  |  |  |  |  |  | ✓ |
| `itemFrequencies` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `itemsetKey` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `jsd` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `kendallTau` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `kgramCounts` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `KgramExplosionError` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `kruskal` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `lag_profile` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lagProfile` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `layerDof` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `layeredLayout` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `layout` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `leveneBF` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `liftIncrease` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `lightenColor` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `list_lsa_engines` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `listLSAEngines` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `logLikelihood` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `lsa` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_bidirectional` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_classical` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_data` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_ipf` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_lags` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_nonparallel_dominance` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_parallel_dominance` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_to_tna` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_transitions` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsa_two_cell` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaBidirectional` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaClassical` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaData` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaDataFromMatrix` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaDataFromSequences` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaInitial` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `lsaIPF` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaLags` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaNodes` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `lsaNonparallelDominance` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaParallelDominance` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaTests` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `lsaToTNA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaTransitionProbabilities` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `lsaTransitionRows` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `lsaTransitions` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `lsaTwoCell` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `marginalDistribution` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `markovOrderTest` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `markovStability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `matchAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `matchContext` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `Matrix` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `maxScale` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `MCML_COLOR_PALETTE` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `mcml_plot_data` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `mcmlLayerModel` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `mcmlPlotData` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `meanTimeInState` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `metricLabel` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `mineAssociations` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `mineContexts` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `mineSequences` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `minmaxScale` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `mmm` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `mmmAssign` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `modalSequence` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `modelReliability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `mogenPathways` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `mogenTransitions` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `motif_census` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `motifCensus` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `motifs` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `mountAssociationExplorer` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `multinomSE` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `NETWORK_LAYOUTS` | ✓ | ✓ |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `networkArrowPolygon` | ✓ | ✓ |  |  |  |  |  |  |  |  |  |  |
| `networkDensity` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `networkEdgeGeometry` | ✓ | ✓ |  |  |  |  |  |  |  |  |  |  |
| `networkLayout` | ✓ | ✓ |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `networkMetrics` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `networkPlotData` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `networkReliability` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `networkSelfLoopGeometry` | ✓ | ✓ |  |  |  |  |  |  |  |  |  |  |
| `nodeContexts` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `nodeMetricValue` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `nodes` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `normalizeTransactions` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `nTreeNodes` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `nTreeNodesGroup` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `oneHotToTransactions` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `pAdjust` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `pairwiseChisq` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `pairwiseWelch` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `parentContext` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `parseTimeValue` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `parseTranslate` | ✓ |  |  |  |  |  |  |  | ✓ |  |  | ✓ |
| `passageTime` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `PATH_SEPARATOR` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `pathCounts` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `pathDependence` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `pathwayExists` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `pathwaysHon` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `pathwaysHypa` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `pathwaysMogen` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `patternOutcome` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `patternOutcomeCounts` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `pchisq` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `pchisqUpper` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `pearsonCorr` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `performance` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `permutationTest` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `permutationTestWtna` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `permute_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `permuteLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `persistenceLandscape` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `persistentHomology` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `pf` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `plot_chords` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plot_forest` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plot_mcml` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `plot_motif_subnetwork` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plot_motifs` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plot_polar` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plot_process_map` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `plot_transitions` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plot_variants` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `plotAssociationChord` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotAssociationForceNetwork` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotAssociationNetwork` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotAssociations` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotBootstrap` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotCentralities` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotChords` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plotCoefficients` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotCompareHeatmap` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotComparePyramid` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotComparison` | ✓ |  |  |  |  |  | ✓ | ✓ |  |  |  |  |
| `plotDifferenceNetwork` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `plotDistributions` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotDivergence` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotEdgeReliability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotEntropyProfile` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotForest` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plotFrequentItemsets` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotGroupDifference` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotGroupedRuleMatrix` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotHTNA` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `plotItemsetLattice` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotItemsetUpSet` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plotLSAChords` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `plotLSAComparison` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `plotLSAForest` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `plotLSAHeatmap` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plotLSAPolar` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `plotLSATransitions` | ✓ |  |  |  |  |  |  |  |  |  |  |  |
| `plotMarkovOrder` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotMatrix` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotMCML` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `plotMeanTimes` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotMosaic` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotMotifs` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotMotifSubnetwork` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotNetwork` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `plotNetworkGrid` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `plotPathwayResamples` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotPathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotPatternOutcome` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotPatterns` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotPolar` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plotPredictive` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotProcessMap` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `plotPruning` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotRuleDoubleDecker` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotRuleGraph` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotRuleMatrix` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotRuleMosaic` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotRuleParallel` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotRuleSankey` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotRuleScatter` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `plotSequenceIndex` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotSimplicial` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `plotSplitHalf` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotStability` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `plotStateDistribution` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `plotTrajectories` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotTransitions` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `plotTree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotTuning` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `plotVariants` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `pnorm` |  |  |  |  | ✓ |  |  |  |  |  |  |  |
| `positionwiseJSD` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `postHoc` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `prange` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `predictNext` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `predictTree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `prepareData` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `prepareLong` | ✓ | ✓ |  |  |  |  |  | ✓ |  |  | ✓ | ✓ |
| `prepareSequenceData` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `prepareTreeInput` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `process_map` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `PROCESS_MAP_LAYOUTS` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `processMap` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `processMapCaption` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `processMapData` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `processMapTables` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `prune` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `pruneDisparity` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `pruneTree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `pruneTreeGroup` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `pt2` | ✓ |  |  |  | ✓ |  |  |  |  |  |  | ✓ |
| `ptukey` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `ptukeyUpper` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `qAnalysis` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `qtukey` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `quantile7` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `quantileType7` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ |  |
| `queryPathway` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `rankArray` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `rankScale` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `recommendFromRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `redundantAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `register_lsa_engine` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `registerLSAEngine` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `relativeLinkageDisequilibrium` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `reliability_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `RELIABILITY_METRICS` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `reliabilityAnalysis` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `reliabilityLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `removeRedundantAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `renameGroups` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `representativeAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `representativeRuleKeys` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `resolveSmoothing` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `rgbToHex` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `rle` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `ROOT_CONTEXT` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `ROOT_PATHWAY` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `rowNormalize` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `rowNormalizeWtna` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `ruleCounts` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `ruleImprovement` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `rvCoefficient` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `scorePositions` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `scoreSequences` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `SeededRNG` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `separate_mcml` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `separateMCML` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `seqcost` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqdist` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqibad` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqidegrad` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqindic` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqinsecurity` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqipos` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqivardur` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqprecarity` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqST` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `seqsubsn` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `sequenceFrequencies` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `sequenceFrequencyMatrix` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `sequenceIndices` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `sequencePlotHtnaData` | ✓ |  |  |  |  | ✓ |  |  |  |  | ✓ | ✓ |
| `sequenceStateDistribution` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `sequenceStateFrequencies` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `sequenceTransitions` | ✓ |  |  | ✓ |  |  |  |  |  |  | ✓ |  |
| `SET3_PALETTE` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `sharpPathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `significantAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `simplicialDegree` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `simplicialEvidence` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `simulate` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `smoothCounts` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `smoothTree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `smoothTreeGroup` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `solveLinear` | ✓ | ✓ | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `sortAssociationRules` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `spearmanCorr` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `spearmanCorrArr` | ✓ |  |  |  | ✓ |  |  |  |  |  | ✓ | ✓ |
| `stability_lsa` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `stabilityLSA` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `standardizedLift` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `START_SENTINEL` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `START_SENTINEL_ALT` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `startActivities` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `stateCounts` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `stateDistribution` |  |  | ✓ |  |  |  |  |  |  |  |  |  |
| `stateFrequencies` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `statePresence` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `stdResiduals` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `subgraphs` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `subtree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `suffixChain` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `summarize_mcml` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `summarizeMCML` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `summary` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `survivingRows` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `tests` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `throughput_times` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `throughputTimes` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `tna` | ✓ | ✓ |  |  |  |  |  |  |  |  | ✓ | ✓ |
| `toBinaryMatrix` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ | ✓ |
| `token_replay` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `tokenReplay` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `toUnit` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `trace_coverage` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `trace_variants` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `traceCoverage` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `traceLengths` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `traceLengthSummary` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `traceVariants` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `transactionIds` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `transactionsToOneHot` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `transactionSummary` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `transfer_entropy` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `transferEntropy` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `transformColumns` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `transition_durations` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `transition_probabilities` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `transitionDurations` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `transitionEntropy` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `transitionMatrixFromKgrams` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
| `transitionProbabilities` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `transitions` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `tree_notation` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `tree_to_petri_net` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `treeDependence` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeDistance` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeDistanceBreakdown` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeLogLikelihood` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeModelFit` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeModelFitGroup` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeNotation` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `treePathways` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treePerplexity` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `treeToPetriNet` | ✓ |  |  |  |  |  |  |  | ✓ |  | ✓ | ✓ |
| `triad_census` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `TRIAD_DESCRIPTIONS` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `TRIAD_PATTERNS` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `TRIAD_TYPES` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `triadCensus` | ✓ |  | ✓ |  |  |  |  |  |  |  |  |  |
| `trimSequences` | ✓ |  |  | ✓ |  |  |  |  |  |  |  |  |
| `tukeyHSD` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `tuneTree` | ✓ |  |  |  |  |  | ✓ |  |  |  |  |  |
| `unregister_lsa_engine` |  |  |  |  |  |  |  | ✓ |  |  |  |  |
| `unregisterLSAEngine` | ✓ |  |  |  |  |  |  | ✓ |  |  |  |  |
| `validateMmmOptions` | ✓ |  | ✓ |  |  |  |  |  |  |  | ✓ |  |
| `viewBoxScale` | ✓ |  |  |  |  |  |  |  | ✓ |  |  | ✓ |
| `weightedEclat` | ✓ |  |  |  |  |  |  |  |  | ✓ |  |  |
| `welchAnova` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `welchPairs` | ✓ |  |  |  | ✓ |  |  |  |  |  |  |  |
| `withinWPermutation` | ✓ |  | ✓ |  |  |  |  |  |  |  |  | ✓ |
