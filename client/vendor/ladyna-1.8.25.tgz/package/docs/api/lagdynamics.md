# ladyna/lagdynamics — lag sequential analysis

Lag sequential analysis (LSA) models which events tend to follow which other events
at a given lag: it cross-tabulates `event(t) → event(t + lag)` transitions and tests
every cell against its expected frequency. This module is a pure TypeScript port of
the R **`lagdynamics`** package, **version 0.32** — the pinned reference for
everything here. Deterministic quantities (counts, expected values, adjusted
residuals, p-values, Yule's Q, kappa, likelihood-ratio and Pearson chi-square tests,
IPF fits, Beta-posterior certainty, transfer entropy) match the R fixtures in
`tests/lagdynamics-r-groundtruth.test.ts` and `tests/bayes-lsa-r-groundtruth.test.ts`
to the documented tolerances (typically 1e-10 to 1e-15). Stochastic verbs
(bootstrap, permutation, stability, reliability, comparison, Bayesian comparison)
are verified against R via **replay hooks** — you feed in the indices, shuffles,
splits, permutations, or Beta draws that R realized, so the *estimator* is compared
rather than the sampler (`indices`, `shuffles`, `subsamples`, `splits`,
`permutations`, `betaDrawsA`/`betaDrawsB` below).

A runnable gallery of every plot lives at [`demo/lagdynamics.html`](../../demo/lagdynamics.html).

## Import

```js
// Sub-path: everything under its original name, plus R-style snake_case aliases.
import {
  lsa, transitions, bootstrapLSA, compareLSA, transferEntropy,
  plotLSA, plotLSAHeatmap, plotTransitions, plotChords, plotPolar,
  plotForest, plotComparison,
} from 'ladyna/lagdynamics';

// Root: same functions, some renamed (see "Where each name is exposed").
import {
  lsa, lsaTransitionRows, bootstrapLSA, compareLSA, transferEntropy,
  plotLSA, plotLSAHeatmap, plotLSATransitions, plotLSAChords, plotLSAPolar,
  plotLSAForest, plotLSAComparison,
} from 'ladyna';
```

### Where each name is exposed

Verified against [`docs/api/exports.md`](./exports.md):

- **`ladyna/lagdynamics`** exports the full surface under the **original names**
  (`plotTransitions`, `plotChords`, `plotPolar`, `plotForest`, `plotComparison`,
  `plotLSAHeatmap`, `plotLSA`) plus the snake_case aliases
  (`plot_transitions`, `plot_chords`, `plot_polar`, `plot_forest`, `lsa_data`, …).
- **Root `ladyna`** re-exports the module but **renames five painters** to avoid a
  collision with the `transitiontrees` painters: `plotTransitions → plotLSATransitions`,
  `plotChords → plotLSAChords`, `plotPolar → plotLSAPolar`, `plotForest → plotLSAForest`,
  `plotComparison → plotLSAComparison`. `plotLSAHeatmap` and `plotLSA` keep their
  names. The generic accessors are likewise prefixed at the root:
  `transitions → lsaTransitionRows`, `nodes → lsaNodes`, `tests → lsaTests`,
  `transitionProbabilities → lsaTransitionProbabilities`, `initial → lsaInitial`.
  The snake_case aliases are **not** re-exported from the root.
- **`ladyna/light` and `ladyna/full` do not expose this module at all.** (The
  `prepareLong` they carry is the core one — next paragraph.)

### `prepareLong` — two different functions share the name

- `ladyna/lagdynamics` exports **this module's** `prepareLong(rows, options)`
  (`src/lagdynamics/data.ts`): rows are **objects** keyed by column name, and it
  returns `{ sequences: string[][], groups?: string[] }` for direct use with `lsa()`.
- Root `ladyna` (and `ladyna/core`, `ladyna/light`, `ladyna/full`) export the **core**
  `prepareLong(rows, headers, options)` (`src/core/prepare-long.ts`): rows are
  **arrays of cells** plus a separate `headers` array, and it returns a wide
  `PrepareLongResult` with metadata for `tna()` model building.

They are different functions with different signatures. Importing `prepareLong`
from the root does **not** give you the LSA pivot; import it from
`ladyna/lagdynamics` (or just pass the long-format options straight to `lsa()`,
which calls it internally when `action` is set).

## Fitting & engines

### `lsa(input, options?) → LSAFit | LSAGroup`

The main verb. Accepts event sequences (nested arrays of strings or 1-based
integer codes, with `null`/`''` treated as missing), a single flat sequence, a
pre-computed square count matrix (declare it with `as: 'transitions'`), a long
event log (array of row objects, with `action` set), or an `LSAData` object.
Returns an `LSAFit`, or an `LSAGroup` when `group` is given.

| Option | Default | Meaning |
|---|---|---|
| `lag` | `1` | Transition lag; negative lags look backwards. Matrix input supports only `lag: 1`. |
| `engine` | `'classical'` | Analysis engine (registry below). |
| `alternative` | `'two.sided'` | `'two.sided' \| 'greater' \| 'less'` for the z-based p-values. |
| `alpha` | `0.05` | Significance level for the `significant` edge flag. |
| `loops` | `true` | `false` forbids self-transitions via a zero-diagonal structural-zero matrix (classical engine only). |
| `structuralZeros` | `null` | K x K 0/1 matrix of estimable cells; expected counts then come from IPF. Classical engine only — the other engines throw. |
| `labels` | derived | State names; numeric codes are 1-based indices into `labels`. |
| `group` | `null` | One value per sequence (array), or a column name (string, long input only). Fitted per group; levels are sorted as R's `as.factor()` sorts them. |
| `as` | `'sequences'` | How to read a nested numeric array: `'sequences'` (default, matching R's list handling) or `'transitions'` (count matrix). |
| `actor`, `action`, `time`, `order`, `session` | — | Long-format column names; setting `action` triggers the internal `prepareLong` pivot. |
| `timeThreshold` | `900` | Seconds of inactivity that split a session (long input without `session`). |
| `unixTimeUnit` | `'seconds'` | `'seconds' \| 'milliseconds' \| 'microseconds'` for numeric time columns. |
| `params` | `{}` | Engine-specific parameters (e.g. `{ continuity: 0.5 }` for `two_cell`). |

Every `LSAFit` carries the matrices (`observed`, `expected`, `probability`,
`probabilityColumn`, `adjustedResiduals`, `pValues`, `yulesQ`, `kappa`, `kappaZ`,
`kappaP`, `weights`), the omnibus tests (`likelihoodRatio`, `pearsonChiSquare`),
a tidy `edges` table (one row per from → to cell with `count`, `expected`, `prob`,
`probCol`, `adjRes`, `p`, `yulesQ`, `kappa`, `kappaZ`, `kappaP`, `lift`, `sign`,
`significant`, plus any engine extras), `nodes`, `initialProbabilities`, the
resolved `params`, and `meta` (IPF diagnostics and raw engine extras).

### Engine shorthands

Each locks `engine` and passes everything else through to `lsa()`:

| Function | Engine | What it tests |
|---|---|---|
| `lsaClassical(data, options?)` | `'classical'` | Allison–Liker adjusted residuals against independence (IPF-based expecteds under structural zeros); also fills Yule's Q, Bakeman kappa (`kappa`, `kappaZ`, `kappaP`), likelihood-ratio and Pearson chi-square tests. |
| `lsaTwoCell(data, options?)` | `'two_cell'` | Per-cell 2 x 2 odds-ratio z-tests; `params.continuity` (default `0.5`) is added when any cell is zero. Extra edge columns: `oddsRatio`, `logOr`, `logOrSe`. |
| `lsaBidirectional(data, options?)` | `'bidirectional'` | Symmetric matched-pair analysis on `obs + obsᵀ`; the fit is undirected (`directed: false`). Extras in `meta.extra`: `symmetric_obs`, `symmetric_exp`, `marginals`. |
| `lsaParallelDominance(data, options?)` | `'parallel_dominance'` | Directional dominance `obs[i][j] − obs[j][i]` scaled by expected pair counts. Extra edge columns: `dominance`, `dominanceSe`. |
| `lsaNonparallelDominance(data, options?)` | `'nonparallel_dominance'` | Dominance scaled by observed pair totals, with an exact binomial p per off-diagonal pair. Extra edge columns: `dominance`, `pairTotals`, `binomialP`. |

Engine `extra` matrices are flattened column-major onto each edge row under a
camelCase name; scalar/vector extras stay in `fit.meta.extra`.

### Engine registry

Custom engines plug into the same `lsa()` verb.

- `registerLSAEngine(name, fn, description, requires?) → string` — register an
  `LSAEngine` (`(context: LSAEngineContext) => LSAEngineResult`); returns the name.
- `getLSAEngine(name) → LSAEngineEntry` — resolve; throws with the list of
  registered names if absent.
- `listLSAEngines() → Array<{ name, description, requires }>` — tidy sorted table.
- `unregisterLSAEngine(name) → void` — remove; throws if not registered.

```js
listLSAEngines().map(e => e.name)
// [ 'bidirectional', 'classical', 'nonparallel_dominance', 'parallel_dominance', 'two_cell' ]
```

### Data verbs

- `lsaData(input, labels?, options?) → LSAData` — normalize any accepted input.
  `options.as: 'sequences' | 'transitions'` disambiguates nested numeric arrays
  (default `'sequences'`, matching R's treatment of a list).
- `lsaDataFromSequences(raw, labels?) → LSAData` — event sequences; missing
  values dropped, string states sorted into labels when none are given.
- `lsaDataFromMatrix(observed, labels?) → LSAData` — a pre-computed square count
  matrix (labels default to `Code 1..K`).
- `lsaTransitions(input, lag = 1) → LSATransitions` — raw lagged counts before
  any engine runs: `observed`, `rowTotals`, `colTotals`, `nTransitions`, and a
  tidy `edges` table. Negative lags count backwards transitions.
- `prepareLong(rows, options) → { sequences, groups? }` — long event log of row
  **objects** → event sequences. Options: `action` (required), `actor`, `time`,
  `order`, `session`, `group`, `timeThreshold` (default `900` s),
  `unixTimeUnit` (`'seconds' | 'milliseconds' | 'microseconds'`). Distinct from
  the core `prepareLong` — see the note above.

### Structural-zero IPF

`lsaIPF(observed, options?) → LSAIPFResult` — iterative proportional fitting of
expected counts under a 0/1 `structure` matrix (quasi-independence). Options:
`structure` (default all-ones), `tolerance` (default `1e-8`), `maxIterations`
(default `200`). Returns `{ fit, iterations, converged, maxMarginDifference }`.
Used internally by the classical engine whenever `structuralZeros` (or
`loops: false`) is set; the fit's IPF diagnostics land in `fit.meta.ipf`.

## Accessors

All accessors dispatch on `LSAGroup` (prepending a `group` column) as well as on
a single fit.

- `transitions(x, options?) → Array<row>` — the tidy edge table of a fit, group,
  `lsaLags` result, **or any inference result** with an `edges` table.
  `TransitionFilterOptions`: `significant` (keep only significant/stable rows),
  `direction: 'any' | 'over' | 'under'`, `minCount`, `alpha` (override the fit's),
  `sort: 'none' | 'strength' | 'count' | 'prob'` (`'strength'` sorts by |adjusted
  residual| — or the matching strength column of an inference table).
- `nodes(x) → Array<{ state, outgoing, incoming }>`.
- `tests(x) → Array<{ test, statistic, df, p }>` — the omnibus rows: `lrx2`
  (likelihood ratio) and `x2` (Pearson chi-square), when the engine provides them.
- `transitionProbabilities(x) → Matrix | Record<string, Matrix>` — row-normalized
  `P(to | from)` with non-finite and structurally-zero cells cleaned to 0.
- `initial(x) → Array<{ state, initProb }>` — first-event probabilities.
- `lsaToTNA(x, weights = 'prob') → LSATNA | Record<string, LSATNA>` — bridge to
  the `ladyna` model layer (`weights: 'prob' | 'count' | 'adj_res' | 'lift'`);
  `prob`/`count` fits keep `inits` and 1-based `data` so the TNA model is
  resampleable.

## Grouped & multi-lag analysis

- **Grouped fits** — `lsa(data, { group })` returns an `LSAGroup`
  (`{ kind: 'lsa_group', groups, levels, groupSizes, labels, engine }`); levels
  are factor-sorted exactly as R sorts them. `transitions`, `nodes`, `tests`,
  `transitionProbabilities`, `initial`, `certaintyLSA`, `reliabilityLSA`,
  `lsaToTNA`, `compareLSA`, `bayesCompareLSA`, and `plotLSA` all accept a group
  directly.
- `lsaLags(data, lags = [1, 2, 3], options?) → LSALags` — one fit per lag
  (`{ kind: 'lsa_lags', lags, fits }`); `transitions()` on it stacks all lags.
- `lagProfile(input, from, to, lags = [1, 2, 3], options?) → LSAProfileRow[]` —
  one edge tracked across lags: `{ lag, from, to, count, prob, adjRes, p, significant }`.
  Accepts raw input or an existing `LSALags`.

## Inference: bootstrap, certainty, permutation, stability, reliability

All require event-level input (not a pre-computed matrix) except `certaintyLSA`,
which is analytic. All stochastic verbs take a `seed` (xoshiro128** `SeededRNG`)
and a replay hook for R-equivalence testing.

### `bootstrapLSA(fit, options?) → LSABootstrapResult`

Resampled percentile CIs and sign-stability for every edge.

| Option | Default | Meaning |
|---|---|---|
| `iterations` | `1000` | Bootstrap replicates. |
| `level` | `'auto'` | `'sequence'` (resample whole sequences; the default with ≥ 2 sequences) or `'event'` (stationary block bootstrap on the event stream; the default for a single sequence). |
| `blockLength` | `⌈√T⌉` | Mean geometric block length for the event-level bootstrap. |
| `confidenceLevel` | `0.95` | Percentile CI level (R type-7 quantiles). |
| `indices` | — | Replay hook: one row of zero-based resample indices per iteration. |
| `seed` | clock | RNG seed. |

Edges report count/adjusted-residual/probability/Yule's Q means, SEs, and CIs,
a bootstrap two-sided `adjResPBootstrap`, and `adjResStable` (CI excludes 0).
Raw replicate matrices (`bootObserved`, `bootAdjustedResiduals`,
`bootProbability`, `bootYulesQ`) and `indicesUsed` are returned for audit.

### `certaintyLSA(fit | group, options?) → LSACertaintyResult | Record<string, LSACertaintyResult>`

Analytic Beta-posterior certainty for each transition probability — the
confirmatory verb (no resampling, no seed).

| Option | Default | Meaning |
|---|---|---|
| `prior` | `0.5` | Jeffreys-style Beta prior count added to each cell. |
| `confidenceLevel` | `0.95` | Credible-interval level. |
| `inference` | `'stability'` | `'stability'`: posterior mass outside `prob x consistencyRange`; `'threshold'`: posterior mass below `edgeThreshold`. |
| `consistencyRange` | `[0.75, 1.25]` | Multiplicative band around the observed probability. |
| `edgeThreshold` | 10th pctile of positive probs | Threshold for `inference: 'threshold'`. |

Edges report the posterior mean/SE/CI of `prob`, a `pValue`, and `stable`
(`p < 1 − confidenceLevel` with a positive, estimable probability).

### `permuteLSA(fit, options?) → LSAPermutationResult`

Permutation test of the adjusted residuals against shuffled event order.
Options: `iterations` (default `1000`), `withinSequence` (default `true`;
`false` shuffles the pooled event stream), `shuffles` (replay: one full
zero-based permutation of the events per iteration), `seed`. Edge p-values use
the `(1 + exceed) / (1 + n)` estimator.

### `stabilityLSA(fit, options?) → LSAStabilityResult`

Subsampling stability of each edge's significance flag. Options: `iterations`
(default `500`, or the length of `subsamples`), `proportion` (default `0.8`,
rounded with R's half-to-even `round()`), `minStable` (default `0.95`),
`subsamples` (replay), `seed`. Edges report the retention `stability` share and
`stable = stability ≥ minStable`.

### `reliabilityLSA(fit | group, options?) → LSAReliabilityResult | Record<...>`

Split-half reliability: correlate the chosen weight matrix across random halves
of the sequences (needs ≥ 2 sequences). Options: `iterations` (default `100`),
`weights: 'prob' | 'count' | 'adj_res'` (default `'prob'`),
`method: 'pearson' | 'spearman'` (default `'pearson'`), `splits` (replay: the
first-half index sets), `seed`. Returns all `correlations` plus their `mean`,
`sd`, and 95% percentile `ciLow`/`ciHigh`.

## Comparison: permutation & Bayesian

Both accept **either** two fits (`compareLSA(a, b, options)`) **or** one
`LSAGroup` (`compareLSA(group, undefined, options)`). A two-level group returns
the plain two-group result; three or more levels return the pairwise variant
(`kind: 'lsa_comparison_pairwise'` / `'lsa_bayes_pairwise'`) with one comparison
per pair, a pooled edge table (with `groupA`/`groupB` columns), and — matching
R — a **single family-wide p-adjustment across all pairs**, never a double
correction. Compared fits must share engine, lag, and labels.

### `compareLSA(x, y?, options?) → LSAComparison | LSAPairwiseComparison`

Permutation test of per-edge group differences plus an omnibus statistic (the
squared Frobenius norm of the difference matrix over the tested cells, with its
own permutation p; per-pair omnibus p-values are adjusted across pairs as their
own family).

| Option | Default | Meaning |
|---|---|---|
| `iterations` | `1000` | Label permutations of the pooled sequences. |
| `measure` | `'log_or'` | `'prob' \| 'adj_res' \| 'log_or' \| 'yules_q' \| 'count' \| 'lift'`. |
| `adjust` | `'none'` | `'bonferroni' \| 'holm' \| 'BH' \| 'BY'` p-adjustment. |
| `minCount` | `5` | Cells with fewer pooled counts are not tested (p = NaN). |
| `permutations` | — | Replay hook: one zero-based permutation of `0..(nA+nB−1)` per iteration, captured from R. |
| `seed` | clock | RNG seed. |

### `bayesCompareLSA(x, y?, options?) → LSABayesComparison | LSABayesPairwiseComparison`

Beta-Binomial posterior comparison of transition probabilities: per-edge
posterior difference draws give the credible interval, probability of direction
(`pd`), a two-sided `p = 2(1 − pd)`, and an `effectSize`; `global` counts the
credibly different edges per pair.

| Option | Default | Meaning |
|---|---|---|
| `prior` | `0.5` | Beta prior count per cell. |
| `draws` | `10000` | Posterior Monte Carlo draws. |
| `confidenceLevel` | `0.95` | Credible-interval level. |
| `meanThreshold` | `0.01` | Minimum \|difference\| for a credible edge. |
| `boundThreshold` | `0.001` | Minimum distance of the nearer CI bound from 0. |
| `adjust` | `'none'` | p-adjustment (family-wide across pairs in the pairwise variant). |
| `betaDrawsA`, `betaDrawsB` | — | Replay hooks: R's realized `rbeta` draws, one row per edge in column-major order (must be supplied together, identical shape). |
| `seed` | clock | RNG seed. |

## Transfer entropy

`transferEntropy(x, y?, options?) → TransferEntropyRow[]`

Discrete Schreiber transfer entropy in bits, in two modes:

- **Paired**: `transferEntropy(x, y)` with aligned equal-length sequence sets
  returns both directions (`x → y`, `y → x`; labels via `xLabel`/`yLabel`).
- **Within one alphabet**: `transferEntropy(x)` builds 0/1 indicator series per
  state and returns one row per ordered state pair.

| Option | Default | Meaning |
|---|---|---|
| `lag` | `1` | Prediction horizon. |
| `history` | `1` | Target-history embedding length. |
| `test` | `'surrogate'` | `'surrogate'` permutes the source to get `teEffective` and `p`; `'none'` skips both. |
| `iterations` | `199` | Surrogate count. |
| `normalize` | `true` | `false` drops the `teNormalized` column (TE / conditional target entropy). |
| `seed` | clock | RNG seed for the surrogates. |
| `xLabel`, `yLabel` | `'x'`, `'y'` | Row labels in paired mode. |

Rows are `{ from, to, te, teEffective?, teNormalized?, p?, n }`, sorted by `te`
descending.

## Visualization

Seven self-contained SVG painters (`src/lagdynamics/visualize.ts`) — pure
string-returning functions, no D3, matching the R package's ggplot/cograph
palettes. All accept the base `LSAPlotOptions`:

| Base option | Default | Meaning |
|---|---|---|
| `width` | `760` | SVG width. |
| `height` | `560` | SVG height (the comparison barrel grows to fit its rows). |
| `title`, `subtitle` | per plot | Override the generated header. |
| `colors` | per plot | Node/segment palette. |
| `background` | `'#ffffff'` | Canvas fill. |
| `significant` | `false` | Restrict to cells with `p < alpha`. |

Browse them all live in [`demo/lagdynamics.html`](../../demo/lagdynamics.html).

### `plotLSA(input, type?, options?) → string | Record<string, string>`

Dispatcher: `type: 'heatmap' | 'network' | 'chord' | 'sunburst'` (default
`'heatmap'`) routes to `plotLSAHeatmap`, `plotTransitions`, `plotChords`, or
`plotPolar`. **On an `LSAGroup` it returns a `Record<string, string>` — one SVG
per group level (titled with the level) — not a single string.**

### `plotLSAHeatmap(fit, options?) → string`

Matrix heatmap, rows ordered by outgoing volume, modal/significant cells bold.

| Option | Default | Meaning |
|---|---|---|
| `which` | `'residuals'` | `'residuals' \| 'prob' \| 'count' \| 'expected'` — matrix and palette (diverging for residuals, sequential otherwise). |

### `plotTransitions(fit, options?) → string`

TNA/cograph-style circular transition network with curved reciprocal edges and
cograph-geometry self-loops. Root name: `plotLSATransitions`.

| Option | Default | Meaning |
|---|---|---|
| `weights` | `'residuals'` | `'residuals' \| 'tna' \| 'relative' \| 'count' \| 'prob' \| 'lift' \| 'yules_q'` — `'tna'`/`'relative'` draw the probability network with initial-probability node rings. |
| `top` | all | Keep the strongest N edges (or a fraction when `< 1`). |
| `decimals` | `1` (labels) / `2` (tooltips) | Edge-label precision. |
| `edgeLabels` | `true` | Draw numeric edge labels. |
| `edgeCutoff` | `0.05` for `prob`, else `0` | Hide edges at or below this absolute value. |
| `nodeFill` | palette / `'#fff'` | Override node fill. |
| `edgeWidthMin` | `0.55` | Minimum stroke width (SVG units). |
| `edgeWidthMax` | `2.8` | Maximum stroke width. |
| `arrowScale` | `1` | Arrowhead size relative to edge width. |

### `plotChords(fit, options?) → string`

Chord diagram: flow-sized ring segments, ribbons sized by the width metric and
colored by the color metric. Root name: `plotLSAChords`.

| Option | Default | Meaning |
|---|---|---|
| `widthMetric` | `'count'` | `'count' \| 'prob'` ribbon widths. |
| `colorMetric` | `'residuals'` | `'residuals' \| 'lift' \| 'prob' \| 'count'` ribbon fill. |
| `compare` | — | Second fit; ribbons are colored by the metric **difference**. |
| `selfLoops` | `true` | `false` drops the diagonal. |
| `alpha` | `0.6` | Ribbon fill opacity (not the significance level). |

### `plotPolar(fit, options?) → string`

Rose/wedge polar sunburst of outgoing transitions. Root name: `plotLSAPolar`.

| Option | Default | Meaning |
|---|---|---|
| `style` | `'rose'` | `'rose'` (equal slots, bar height = size) or `'wedge'` (sector = source volume, wedge width = frequency). |
| `fill` | `'residuals'` | `'residuals' \| 'prob' \| 'lift'` segment fill. |
| `size` | `'count'` | `'count' \| 'prob'` bar height (rose style). |
| `labels` | `'all'` (rose) / `'auto'` (wedge) | `'all' \| 'auto' \| 'none'` target labels. |
| `minShow` | `0.01` | Minimum row share drawn (wedge style). |
| `labelSize` | — | Declared but not currently applied. |

### `plotForest(result, options?) → string`

Radial forest of bootstrap or certainty CIs — takes an `LSABootstrapResult` or
`LSACertaintyResult`, one spoke per edge, dashed null ring. Root name:
`plotLSAForest`.

**Needs interval estimates.** A plain `lsa()` fit has no confidence intervals,
so it is rejected with a message naming the two verbs that produce a drawable
result — it used to render an empty ring labelled `NaN% CI`, which looked like a
finished figure. Wrap the fit first:

```js
plotForest(certaintyLSA(lsa(sequences)));   // analytic posterior — cheap
plotForest(bootstrapLSA(lsa(sequences)));   // resampled — slower, no model assumption
```

| Option | Default | Meaning |
|---|---|---|
| `metric` | `'prob'` (certainty) / `'residuals'` (bootstrap) | `'residuals' \| 'count' \| 'prob' \| 'yules_q'` (bootstrap only for non-default choices). |
| `top` | all | Keep the N largest \|estimates\|. |
| `showNonsignificant` | `true` | `false` keeps only stable edges. |
| `labelSize` | — | Declared but not currently applied. |

### `plotComparison(result, options?) → string | Record<string, string>`

Back-to-back comparison barrel (or difference heatmap) for `compareLSA` /
`bayesCompareLSA` results. **On a pairwise result it returns a
`Record<string, string>` keyed `A_vs_B` — one SVG per pair — not a single
string.** Root name: `plotLSAComparison`.

| Option | Default | Meaning |
|---|---|---|
| `style` | `'barrel'` | `'barrel'` (paired bars, p badge in the gutter) or `'heatmap'` (diverging difference matrix). |
| `top` | `12` | Rows shown in the barrel. |
| `value` | `'prob'` | `'prob' \| 'count'` bar lengths. |
| `rank` | `'frequency'` | `'frequency' \| 'effect'` row ordering. |

## End-to-end example

Run against the built package (`node`, `dist/lagdynamics/index.js` or the
`ladyna/lagdynamics` sub-path):

```js
import { lsa, transitions, tests, plotLSAHeatmap } from 'ladyna/lagdynamics';

const sequences = [
  ['plan', 'discuss', 'execute', 'monitor', 'plan', 'discuss', 'execute', 'execute'],
  ['discuss', 'plan', 'execute', 'execute', 'monitor', 'plan', 'discuss', 'execute'],
  ['plan', 'plan', 'discuss', 'execute', 'monitor', 'monitor', 'plan', 'discuss'],
  ['monitor', 'plan', 'discuss', 'execute', 'plan', 'discuss', 'execute', 'monitor'],
];

const fit = lsa(sequences, { engine: 'classical', lag: 1 });
transitions(fit, { significant: true });
tests(fit);
const svg = plotLSAHeatmap(fit, { title: 'Collaboration transitions' });
```

Actual output (`transitions(fit, { significant: true })`, rounded):

```
from        to        count  prob   adjRes  p
plan        discuss   7      0.778  4.439   0.0000
discuss     execute   6      0.857  3.504   0.0005
execute     monitor   4      0.571  3.134   0.0017
monitor     plan      4      0.800  3.134   0.0017
```

`tests(fit)`:

```
[
  { test: 'lrx2', statistic: 40.04079540759705, df: 9, p: 0.0000074702912675750355 },
  { test: 'x2',   statistic: 40.20853615520282, df: 9, p: 0.0000069651364372758096 }
]
```

And the plot is a self-contained SVG string: `svg.startsWith('<svg') === true`.

## snake_case aliases

`ladyna/lagdynamics` (only) also exports exact R-style spellings for migration
and parity audits:

| Alias | Canonical |
|---|---|
| `lsa_data` | `lsaData` |
| `lsa_transitions` | `lsaTransitions` |
| `lsa_ipf` | `lsaIPF` |
| `register_lsa_engine` | `registerLSAEngine` |
| `get_lsa_engine` | `getLSAEngine` |
| `list_lsa_engines` | `listLSAEngines` |
| `unregister_lsa_engine` | `unregisterLSAEngine` |
| `lsa_classical` | `lsaClassical` |
| `lsa_two_cell` | `lsaTwoCell` |
| `lsa_bidirectional` | `lsaBidirectional` |
| `lsa_parallel_dominance` | `lsaParallelDominance` |
| `lsa_nonparallel_dominance` | `lsaNonparallelDominance` |
| `transition_probabilities` | `transitionProbabilities` |
| `lsa_lags` | `lsaLags` |
| `lag_profile` | `lagProfile` |
| `lsa_to_tna` | `lsaToTNA` |
| `bootstrap_lsa` | `bootstrapLSA` |
| `certainty_lsa` | `certaintyLSA` |
| `permute_lsa` | `permuteLSA` |
| `stability_lsa` | `stabilityLSA` |
| `reliability_lsa` | `reliabilityLSA` |
| `compare_lsa` | `compareLSA` |
| `bayes_compare_lsa` | `bayesCompareLSA` |
| `transfer_entropy` | `transferEntropy` |
| `plot_transitions` | `plotTransitions` |
| `plot_chords` | `plotChords` |
| `plot_polar` | `plotPolar` |
| `plot_forest` | `plotForest` |

## Types

All exported from `ladyna/lagdynamics` (the root re-exports the main result and
option types):

- **Input & data**: `LSAInput`, `LSAData`, `LSATransitions`, `LSATransitionRow`,
  `Matrix`, `LongEventRow`, `PrepareLongOptions` (this module's, not core's).
- **Fitting**: `LSAOptions`, `LSAFit`, `LSAGroup`, `LSAEdge`, `LSANode`,
  `LSATest`, `LSAAlternative`, `LSAEngineName`, `LSALags`, `LSAProfileRow`,
  `TransitionFilterOptions`, `LSATNA`.
- **Engines & IPF**: `LSAEngine`, `LSAEngineEntry`, `LSAEngineContext`,
  `LSAEngineResult`, `LSAIPFOptions`, `LSAIPFResult`.
- **Inference**: `LSABootstrapOptions`, `LSABootstrapEdge`, `LSABootstrapResult`,
  `LSACertaintyOptions`, `LSACertaintyEdge`, `LSACertaintyResult`,
  `LSAPermutationOptions`, `LSAPermutationEdge`, `LSAPermutationResult`,
  `LSAStabilityOptions`, `LSAStabilityEdge`, `LSAStabilityResult`,
  `LSAReliabilityOptions`, `LSAReliabilityResult`.
- **Comparison**: `LSACompareMeasure`, `LSACompareOptions`, `LSAComparison`,
  `LSAComparisonEdge`, `LSAGlobal`, `LSAPairwiseComparison`,
  `LSABayesCompareOptions`, `LSABayesComparison`, `LSABayesGlobal`,
  `LSABayesPairwiseComparison`.
- **Transfer entropy**: `TransferEntropyOptions`, `TransferEntropyRow`.
- **Visualization**: `LSAPlotOptions`, `HeatmapOptions`, `TransitionPlotOptions`,
  `ChordOptions`, `PolarOptions`, `ForestOptions`, `ComparisonPlotOptions`.
