# ladyna/htna — heterogeneous TNA (actor networks) + MCML hierarchy plot

Heterogeneous Transition Network Analysis: transition networks over sequences
involving multiple actor groups (e.g. Human ↔ AI), where the actor partition is
carried as metadata (`partition` + `actorLevels`) on a single combined `TNA`
model. Every downstream ladyna analysis works on the result unchanged; the
functions in this module additionally *use* the partition — type-level
meta-paths, partition-preserving bootstrap, actor-aware plots.

**R reference:** the R **`htna`** package v0.1.0 (installed binary — for
`extract_meta_paths` the binary, *not* the GitHub source, is the pinned
reference). `htna()`/`htnaFromLong()` port `build_htna()`, `bootstrapHtna()`
ports `bootstrap_htna()`, `extractMetaPaths()` ports `extract_meta_paths()`,
`formatPaths()` byte-matches `print.htna_paths`, and `sequencePlotHtnaData()`
ports the data transforms inside `sequence_plot_htna()`. The plot layer keeps
R's conventions without pixel-matching R graphics: `htnaPlotData`/`plotHTNA`
reproduce `plot_htna()`'s palettes, shape assignment, and edge classification;
`plotMCML` follows the R **cograph** `cluster_summary` / MCML plot conventions
(Okabe–Ito colors, skewed hierarchy layout). `diffNetworks()` is a ladyna-only
helper (not an htna 0.1.0 export). Ground truth lives in
`tests/htna-*-r-groundtruth.test.ts` against
`tests/fixtures/htna_groundtruth.json` (regenerate:
`Rscript tools/generate-htna-fixtures.R`).

**Available from:** every export in this module is importable from `ladyna`
(root), `ladyna/htna`, `ladyna/light`, and `ladyna/full` — the plot layer included
(see `docs/api/exports.md`).

```ts
import {
  // model
  htna, htnaFromLong, bootstrapHtna, extractMetaPaths, formatPaths, diffNetworks,
  // plots
  plotHTNA, htnaPlotData, plotMCML, mcmlPlotData, sequencePlotHtnaData,
  plot_mcml, mcml_plot_data,                       // R-style aliases
  // palettes
  HTNA_COLOR_PALETTE, HTNA_SHAPE_PALETTE, MCML_COLOR_PALETTE,
} from 'ladyna/htna';
```

---

## Model

### `htna(data, options): TNA`

```ts
function htna(data: SequenceData | number[][], options: HtnaOptions): TNA
```

ladyna-native form of R `build_htna()`. The caller passes a `SequenceData` whose
sessions are already chronologically ordered (e.g. interleaved Human/AI
events) — or a raw weight matrix with `type: 'matrix'` — plus a `nodeGroups`
lookup tagging each code with its actor group. Builds the model via
`buildModel()` and returns a `TNA` with `partition` (one actor tag per label)
and `actorLevels` populated.

`HtnaOptions` extends `BuildModelOptions` (`type`, `scaling`, `labels`,
`beginState`, `endState`, `params`):

| option | type | default | meaning |
|---|---|---|---|
| `nodeGroups` | `Record<string, string[]>` | **required** | actor name → codes belonging to that actor. At least two actor groups. Each code must appear under exactly one actor (intra-actor duplicates are de-duplicated silently). |
| `actorLevels` | `string[]` | `Object.keys(nodeGroups)` | canonical actor ordering, stored on the model for consistent color/shape/layout assignment. Every entry must exist in `nodeGroups`. |

Throws if `nodeGroups` has fewer than two actors, if a code appears in more
than one actor's entry, if an `actorLevels` entry is missing from
`nodeGroups`, or if a code in `data` is assigned to no actor.

```ts
const model = htna(sessions, {
  nodeGroups: {
    Human: ['Specify', 'Request', 'Refine'],
    AI:    ['Plan', 'Execute', 'Report'],
  },
});
```

### `htnaFromLong(rows, options): TNA`

```ts
function htnaFromLong(rows: LongRow[], options: HtnaLongOptions): TNA
```

Long-format form, mirroring R `build_htna()` exactly: a flat array of event
rows with per-event actor tags. Events are sorted by `(session, order)`
(matching R's `combined[order(session, order), ]`), grouped per session, and
handed to `buildModel()`. Throws on empty `rows`.

Each `LongRow` is `{ session: string | number; order: number; code: string;
actor?: string }`. Actor resolution: per-row `actor` tags (when present on
**every** row) take precedence over the `nodeGroups` lookup; one of the two
must be supplied.

`HtnaLongOptions` extends `BuildModelOptions`:

| option | type | default | meaning |
|---|---|---|---|
| `nodeGroups` | `Record<string, string[]>` | — | node-level actor lookup; used only when rows lack per-event `actor` tags |
| `actorLevels` | `string[]` | first-occurrence order in the data (or `Object.keys(nodeGroups)`) | canonical actor ordering |
| `disambiguate` | `boolean` | `false` | when a code appears under multiple actors, rename events to `"<actor>:<code>"` so they become distinct nodes (R `disambiguate = TRUE`). Without it, collisions throw. Only meaningful with per-event actor tags. |

Runnable example (output below is real `node` output against `dist/index.js`):

```ts
import { htnaFromLong, extractMetaPaths, formatPaths } from 'ladyna/htna';

const rows = [
  { session: 's1', order: 1, code: 'Request', actor: 'Human' },
  { session: 's1', order: 2, code: 'Plan',    actor: 'AI' },
  { session: 's1', order: 3, code: 'Execute', actor: 'AI' },
  { session: 's1', order: 4, code: 'Verify',  actor: 'Human' },
  { session: 's1', order: 5, code: 'Refine',  actor: 'Human' },
  { session: 's1', order: 6, code: 'Execute', actor: 'AI' },
  { session: 's2', order: 1, code: 'Request', actor: 'Human' },
  { session: 's2', order: 2, code: 'Execute', actor: 'AI' },
  { session: 's2', order: 3, code: 'Report',  actor: 'AI' },
  { session: 's2', order: 4, code: 'Verify',  actor: 'Human' },
];

const model = htnaFromLong(rows, { actorLevels: ['Human', 'AI'] });
console.log(model.labels);
// [ 'Execute', 'Plan', 'Refine', 'Report', 'Request', 'Verify' ]
console.log(model.partition);
// [ 'AI', 'AI', 'Human', 'AI', 'Human', 'Human' ]
console.log(model.actorLevels);
// [ 'Human', 'AI' ]
```

### `bootstrapHtna(model, options?): BootstrapResult`

```ts
function bootstrapHtna(model: TNA, options: BootstrapOptions = {}): BootstrapResult
```

Port of R `bootstrap_htna()` (htna 0.1.0), which delegates to
`Nestimate::bootstrap_network()` and re-injects the partition the bootstrap
strips. Here it calls ladyna's `bootstrapTna()` and copies `partition` +
`actorLevels` from the input onto `result.model`. Throws if the input is not
an HTNA model (`partition` missing). Options and result are the plain
`BootstrapOptions` / `BootstrapResult` from `ladyna/analysis` (`iter` = 1000,
`level` = 0.05, `method` = `'stability'`, `consistencyRange` = `[0.75, 1.25]`,
`seed` = 42).

Cross-language note: R's Mersenne Twister and ladyna's xoshiro128** RNG streams
differ, so per-iteration samples — hence means/SDs/CI bounds — are not
byte-equal across languages even with matching seeds. What is guaranteed and
tested: the result's model carries the input's partition and actorLevels, the
source weights are not mutated, and bootstrap means converge to the original
weights for large `iter`.

```ts
const boot = bootstrapHtna(model, { iter: 200, seed: 1 });
console.log(boot.model.partition);
// ["AI","AI","Human","AI","Human","Human"]
```

### `extractMetaPaths(model, options?): MetaPathRow[]`

```ts
function extractMetaPaths(model: TNA, options: ExtractMetaPathsOptions = {}): MetaPathRow[]
```

Port of R `extract_meta_paths()` (htna 0.1.0 **installed binary** — the GitHub
source diverges). Each session is re-encoded as a sequence of actor types;
k-length type patterns are enumerated with `count`, `nSequences`, `support`
(proportion of sessions containing the pattern), `frequency` (share of counts
within the same `(length, gap)` group), and `lift` (observed / expected under
marginal independence: `expected = prod(marg_p) * total_windows`; `NaN` when
expected is 0). Rows are sorted `(length asc, gap asc, count desc)` to match R.
Throws if the model is not HTNA or has no sequence data.

| option | type | default | meaning |
|---|---|---|---|
| `length` | `number[]` | `[2, 3, 4]` | pattern lengths to enumerate (each ≥ 2); ignored when `schema` is set |
| `schema` | `string` | — | pattern DSL: `"Human->AI->Human"` (concrete) or `"Human->*->Human"` (`*` wildcard). Parts are actor-type names or `*` — concrete *state* names are not supported by the v0.1.0 binary. |
| `type` | `'contiguous' \| 'gapped'` | `'contiguous'` | contiguous positions vs positions spaced by `gap + 1` |
| `gap` | `number \| number[]` | `[1]` | gap size(s) for `type: 'gapped'`; a lone `0` falls back to `1` (R behaviour). One output row group per `(length, gap)`. |
| `minCount` | `number` | `1` | minimum count to retain a row |
| `minSupport` | `number` | `0` | minimum support |
| `minLift` | `number` | `0` | minimum lift; `0` disables the filter |
| `start` | `string[]` | — | keep only patterns whose first element is in this set |
| `end` | `string[]` | — | keep only patterns whose last element is in this set |
| `contain` | `string[]` | — | keep only patterns containing every element in this set |

### `formatPaths(rows, options?): string`

```ts
function formatPaths(rows: MetaPathRow[], options: FormatPathsOptions = {}): string
```

TS equivalent of R `print.htna_paths` (htna 0.1.0): renders `MetaPathRow[]` as
a fixed-width text table whose byte layout matches R's `print(mp, n = 10)`
exactly (column width = max(header, data) + 1, right-aligned;
support/frequency as `%.3f`, lift as `%.2f`, non-finite lift as `NA`).

`FormatPathsOptions`: `n` (max rows, default `10`), `nSequences` (session
count for the header line; `NA` when omitted), `level`
(`'meta'` default → "Meta-paths (type-level)" · `'state'` → "Patterns
(state-level)" · `'paths'` → "Paths").

Real output for the `htnaFromLong` example above:

```ts
const mp = extractMetaPaths(model);
console.log(formatPaths(mp, { n: 5, nSequences: model.data.length }));
```

```text
Meta-paths (type-level) over 2 sequences
Rows: 11 | Lengths: 2, 3, 4 | Gaps: 0
        schema length gap count n_seq support frequency lift
     Human->AI      2   0     3     2   1.000     0.375 1.50
     AI->Human      2   0     2     2   1.000     0.250 1.00
        AI->AI      2   0     2     2   1.000     0.250 1.00
  Human->Human      2   0     1     1   0.500     0.125 0.50
 AI->AI->Human      3   0     2     2   1.000     0.333 2.67
... (6 more)
```

### `diffNetworks(a, b): NetworkDiff`

```ts
function diffNetworks(a: TNA, b: TNA): NetworkDiff
```

Element-wise diff of two TNA weight matrices — a structured input for
"plot the difference between two networks" consumers. **Not** an htna 0.1.0
export; a ladyna-only helper. Both inputs must share the same label set (any
order; throws otherwise). Output rows enumerate every `(from, to)` pair where
either side is non-zero; `magnitude` = `weightB - weightA`; `kind` is
`'added' | 'removed' | 'increased' | 'decreased' | 'unchanged'`, with
per-kind `counts`. When *both* inputs are HTNA their partitions must agree
(throws on mismatch), and the result carries the shared `partition` +
`actorLevels` so renderers can color by actor.

```ts
const diff = diffNetworks(modelA, modelB);
console.log(diff.counts);
// {"added":0,"removed":0,"increased":0,"decreased":0,"unchanged":8}   ← identical inputs
```

---

## Plots

All painters (`plotHTNA`, `plotMCML`) return **self-contained SVG strings** —
inline `<style>`, no external assets, ready to drop into any DOM or file. The
`*PlotData` companions return the renderer-neutral geometry/styling package for
consumers that bring their own renderer (D3, canvas, Svelte/React cells).

### `htnaPlotData(model, options?): HtnaPlotData`

```ts
function htnaPlotData(model: TNA, options: HtnaPlotOptions = {}): HtnaPlotData
```

Layout + render data for R `plot_htna()` (htna 0.1.0): the exact 12-color and
8-shape palettes, per-actor color/shape assignment (`actorLevels[0]` →
`palette[0]`, …), node positions per layout, per-edge classification
(`'within'` / `'between'` / `'self'`), edge color = source actor's color, and
a legend. **Throws if `!isHtna(model)`** (`partition` required).

`HtnaPlotOptions`:

| option | type | default | meaning |
|---|---|---|---|
| `layout` | `HtnaLayout` | `'bipartite-arcs'` | `'bipartite-arcs'` (two facing arcs, Dynalytics/demo norm) · `'circular'` (one ring, R `plot_htna` fallback) · `'vertical'` (two columns) · `'horizontal'` (two rows) |
| `width` | `number` | `1080` | canvas width |
| `height` | `number` | `840` | canvas height |
| `groupColors` | `Record<string, string>` | `HTNA_COLOR_PALETTE` in `actorLevels` order | per-actor color override |
| `groupShapes` | `Record<string, HtnaShape>` | `HTNA_SHAPE_PALETTE` in `actorLevels` order | per-actor shape override |
| `edgeThreshold` | `number` | `0` | hide edges with weight ≤ this (default shows all non-zero) |
| `curvature` | `number` | `0.4` | curve magnitude for within-group edges (0..1), matches R `plot_htna`; between-group and self edges get `0` |
| `bipartiteGapHalf` | `number` | `40` | bipartite-arcs only: half the horizontal distance between the two arc centers |
| `bipartiteRadius` | `number` | auto (`min(width/2 − gapHalf − 60, (height − 100)/2)`) | bipartite-arcs only: arc radius |
| `bipartiteArcSpan` | `number` | `0.45π` (≈ 81°) | bipartite-arcs only: half-angle each side of the equator |

Result: `{ layout, width, height, nodes, edges, legend }` — each
`HtnaPlotNode` carries `id`, `label`, `partition`, `x`, `y`, `shape`, `color`,
and `initProb` (initial-state probability 0..1, drives the donut ring); each
`HtnaPlotEdge` carries `from`, `to`, `weight`, `color`, `kind`, `curvature`
(unit-less fraction of chord length; the renderer picks the sign, using
opposite signs for reciprocal pairs).

```ts
const pd = htnaPlotData(model);
console.log(pd.layout, pd.nodes.length, pd.edges.length);
// bipartite-arcs 6 8
console.log(pd.edges[0]);
// {"from":"Execute","to":"Report","weight":0.5,"color":"#fbb550","kind":"within","curvature":0.4}
```

### `plotHTNA(model, options?): string`

```ts
function plotHTNA(model: TNA, options: HtnaSvgOptions = {}): string
```

Self-contained SVG painter over `htnaPlotData()` — same **throws-on-non-HTNA**
behaviour. Draws shape-coded nodes with an initial-probability ring, weight-
scaled curved edges with arrowheads (reciprocal pairs bowed to opposite sides),
edge labels, node labels with a background halo, cluster legend, and optional
title/subtitle.

`HtnaSvgOptions` extends `HtnaPlotOptions` with:

| option | type | default | meaning |
|---|---|---|---|
| `nodeScale` | `number` | `1` | node radius multiplier (base radius 20) |
| `edgeWidthScale` | `number` | `1` | stroke-width multiplier (width ∝ \|weight\| / max) |
| `edgeOpacity` | `number` | `0.72` | edge stroke opacity |
| `arrowScale` | `number` | `1` | arrowhead size multiplier |
| `labelSize` | `number` | `12` | node label font size (px) |
| `edgeLabelSize` | `number` | `10` | edge label font size (px) |
| `edgeLabelDigits` | `number` | `2` | decimals for edge weight labels |
| `showLabels` | `boolean` | `true` | draw node labels |
| `showEdgeLabels` | `boolean` | `true` | draw edge weight labels |
| `arrows` | `boolean` | `model.type !== 'co-occurrence'` | draw arrowheads |
| `legend` | `boolean` | `true` | draw the actor legend (bottom-right) |
| `background` | `string` | `'#ffffff'` | canvas background |
| `title` | `string` | — | centered title |
| `subtitle` | `string` | — | centered subtitle |

```ts
const svg = plotHTNA(model, { title: 'Human-AI HTNA' });
console.log(svg.slice(0, 80));
// <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 840" width="1080" heig
```

### `mcmlPlotData(input, options?): McmlPlotData`

```ts
function mcmlPlotData(input: TNA | McmlLike, options: McmlPlotOptions = {}): McmlPlotData
```

Renderer-neutral geometry + styling for an MCML (multi-cluster multi-layer)
hierarchy plot: a macro layer of cluster-summary nodes above skewed elliptical
cluster shells containing the detail nodes, following R cograph's
`cluster_summary` / MCML plot conventions (the computation/renderer boundary
follows Nestimate + cograph; `mode` controls automatic edge labels and never
rewrites weights).

Two input forms:

1. **`McmlLike`** — an already-computed MCML object (structural contract
   shared by Nestimate `mcml` and cograph `cluster_summary`): `macro` layer
   (`weights`, `labels`, optional `inits`), optional per-cluster `clusters`
   layers, and `cluster_members`. Macro labels must match `cluster_members`
   names; each cluster layer's labels must equal its members in identical
   order.
2. **Plain `TNA` + `clusters`** — the adapter. `clusters` is
   `Record<clusterName, stateLabels[]>` — **STATE clusters** (groups of the
   model's state labels), *not* case/sequence clusters. Every label must be
   assigned to exactly one cluster. Macro weights are block-aggregated with
   `aggregation`; cluster inits are the model's inits renormalized within each
   block.

`McmlPlotOptions` (defaults from source):

| option | type | default | meaning |
|---|---|---|---|
| `clusters` | `McmlClusters` | — | **required for plain-TNA input**; ignored for `McmlLike` |
| `aggregation` | `'sum' \| 'mean' \| 'max'` | `'sum'` | block aggregation over non-zero cells (plain-TNA adapter only) |
| `mode` | `'weights' \| 'tna'` | `'weights'` | `'tna'` turns edge + summary-edge labels on by default; never converts weights |
| `theme` | `'classic' \| 'rich' \| 'light'` | `'classic'` | non-classic themes default to donut detail nodes, curved summary edges, lighter shells |
| `width` / `height` | `number` | `960` / `760` | canvas size (must be positive) |
| `minimum` | `number` | `0` | hide edges with \|weight\| ≤ this (and any that round to 0 at `edgeLabelDigits`) |
| `directed` | `boolean` | TNA: `model.type !== 'co-occurrence'` · McmlLike: `meta.directed !== false` | undirected input averages (i,j)/(j,i) in the adapter and draws each pair once |
| `colors` | `string[]` | `MCML_COLOR_PALETTE` | per-cluster colors (cycled) |
| `summaryPie` | `'inits' \| 'self'` | `'inits'` | summary-node ring proportion: initial probabilities vs self-transition share |
| `edgeColorBy` | `'auto' \| 'cluster' \| 'sign'` | `'auto'` | `'auto'` switches to sign coloring when any weight is negative |
| `edgePositiveColor` / `edgeNegativeColor` | `string` | `'#2E7D32'` / `'#C62828'` | sign colors |
| `edgeLabels` / `summaryEdgeLabels` | `boolean` | `mode === 'tna'` | weight labels on within / summary edges |
| `edgeLabelDigits` | `number` | `2` | label decimals |
| `showLabels` / `summaryLabels` / `legend` | `boolean` | `true` | detail labels / summary labels / legend |
| `title` / `subtitle` | `string` | — | headings |
| `spacing` | `number` | `3` | shell-ring radius in layout units |
| `shapeSize` | `number` | `1.2` | shell ellipse size |
| `summarySize` | `number` | `4` | summary-node radius control (`max(18, summarySize/4 * 27)` px) |
| `skewAngle` | `number` | `60` | perspective skew in degrees (0–90; compresses y by `cos`) |
| `topLayerScale` | `[number, number]` | `[0.8, 0.25]` | macro-layer ellipse rx/ry scale |
| `interLayerGap` | `number` | `0.6` | **the active layer-gap control** (current cograph) |
| `nodeRadiusScale` | `number` | `0.55` | detail-node orbit inside its shell |
| `nodeSize` | `number` | `2.4` | detail-node radius control |
| `nodeShape` | `McmlNodeShape \| McmlNodeShape[]` | `'circle'` | detail-node shape(s), cycled |
| `nodeDonut` | `boolean` | `theme !== 'classic'` | donut vs pie detail nodes |
| `nodeDonutInnerRatio` | `number` | `0.55` | clamped to 0.05–0.95 |
| `summaryDonutInnerRatio` | `number` | `0.6` | clamped to 0.05–0.95 (summary nodes are painted as compact ring nodes; `summaryDonut` is always `false`) |
| `curvedEdges` | `boolean` | `theme !== 'classic'` | curve summary edges |
| `summaryCurve` | `number` | directed ? `0.25` : `0` | summary-edge curvature |
| `summaryArrows` | `boolean` | `true` | arrowheads on summary edges (when directed) |
| `betweenArrows` | `boolean` | `false` | arrowheads on between-shell edges |
| `edgeWidthRange` | `[number, number]` | `[0.3, 1.3]` | within-edge width range |
| `betweenEdgeWidthRange` | `[number, number]` | `[0.5, 2]` | between-edge width range |
| `summaryEdgeWidthRange` | `[number, number]` | `[0.5, 2]` | summary-edge width range |
| `edgeAlpha` / `betweenEdgeAlpha` / `summaryEdgeAlpha` / `interLayerAlpha` | `number` | `0.35` / `0.6` / `0.7` / `0.5` | opacities |
| `shellAlpha` | `number` | `0.15` (`0.10` for `'light'`) | shell fill opacity |
| `shellBorderWidth` | `number` | `0.75` (`0` for `'light'`) | shell border |
| `layerSpacing` | `number \| null` | — | **compatibility-only**: accepted but unused; `interLayerGap` positions the layer |
| `clusterShape` | `string` | — | **compatibility-only**: summary nodes remain circular pies/donuts |
| `labelPosition` | `number` | — | **compatibility-only**: detail labels are positioned radially |

Result `McmlPlotData`: `shells`, `detailNodes`, `summaryNodes`, and four edge
lists by kind (`withinEdges`, `betweenEdges`, `summaryEdges`,
`interLayerEdges`), plus `legend`, canvas/theme fields, and resolved
`options` (`showLabels`, `summaryLabels`, `legend`, `shellAlpha`,
`shellBorderWidth`).

```ts
const mcml = mcmlPlotData(model, {
  clusters: { Human: ['Request', 'Verify', 'Refine'], AI: ['Plan', 'Execute', 'Report'] },
});
console.log(mcml.summaryNodes.map(n => n.label), mcml.withinEdges.length, mcml.summaryEdges.length);
// [ 'Human', 'AI' ] 3 4
```

### `plotMCML(input, options?): string`

```ts
function plotMCML(input: TNA | McmlLike, options: McmlPlotOptions = {}): string
```

Bundled self-contained SVG painter over `mcmlPlotData()` (same options, same
plain-TNA-requires-`clusters` rule). Renders one dashed summary→shell guide
per cluster (the node-level `interLayerEdges` mapping stays in the data),
summary edges with arrowheads, reciprocal within-cluster edges as two half-
chords with an arrow at each end, pie/donut detail nodes, ring-annotated
summary nodes, legend, and title/subtitle.

```ts
const svg = plotMCML(model, {
  clusters: { Human: ['Request', 'Verify', 'Refine'], AI: ['Plan', 'Execute', 'Report'] },
  mode: 'tna',
});
console.log(svg.slice(0, 60));
// <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 760
```

### `plot_mcml` / `mcml_plot_data`

R-style aliases: `plot_mcml === plotMCML`, `mcml_plot_data === mcmlPlotData`.

### `sequencePlotHtnaData(model, options?): SequencePlotHtnaData`

```ts
function sequencePlotHtnaData(model: TNA, options: SequencePlotHtnaOptions = {}): SequencePlotHtnaData
```

Data layer for R `sequence_plot_htna()` (htna 0.1.0). R's function is a data
transform plus a delegation to `Nestimate::sequence_plot()` for rendering;
ladyna owns the transform, the consumer renders the matrix. Throws if the model
is not HTNA or has no sequence data (`model.data`).

| option | type | default | meaning |
|---|---|---|---|
| `by` | `'state' \| 'group'` | `'state'` | `'state'`: split each session per actor, right-pad with `null` to the global max length, stack all actors' rows (parallel `group` tag per row; per-actor `pieces` also returned). `'group'`: re-encode every cell as its actor type — one row per original session, `group` left empty. |
| `actorLevels` | `string[]` | sorted unique partition values (matches R `sort(unique(node_groups$group))`) | canonical actor order; controls the per-actor split order in `'state'` mode |

Result: `{ by, actors, data, group, pieces? }` where `data` is a wide
`(string | null)[][]` session matrix.

```ts
const seq = sequencePlotHtnaData(model, { by: 'group' });
console.log(JSON.stringify(seq.data));
// [["Human","AI","AI","Human","Human","AI"],["Human","AI","AI","Human",null,null]]
```

---

## Palettes

### `HTNA_COLOR_PALETTE`

R `plot_htna()`'s default 12-color sequence (exact hex codes), assigned to
actors in `actorLevels` order (cycled):

```ts
['#4FC3F7', '#fbb550', '#7eb5d6', '#98d4a2',
 '#f4a582', '#92c5de', '#d6c1de', '#b8e186',
 '#fdcdac', '#cbd5e8', '#f4cae4', '#e6f5c9']
```

### `HTNA_SHAPE_PALETTE`

R `plot_htna()`'s default 8-shape sequence, same assignment rule. (The bundled
`plotHTNA` painter draws `circle`, `square`, `diamond`, and `triangle`
natively; the remaining shapes fall back to circles in the SVG painter but are
carried faithfully in `htnaPlotData` for renderers that support them.)

```ts
['circle', 'square', 'diamond', 'triangle', 'pentagon', 'hexagon', 'star', 'cross']
```

### `MCML_COLOR_PALETTE`

The Okabe–Ito 8-color palette used for MCML cluster colors (cograph
convention), cycled over clusters:

```ts
['#E69F00', '#56B4E9', '#009E73', '#F0E442',
 '#0072B2', '#D55E00', '#CC79A7', '#999999']
```

---

## Types

All exported from `ladyna/htna` (and the root/light/full bundles):

**Build** — `HtnaOptions` (extends `BuildModelOptions`; `nodeGroups`,
`actorLevels?`), `HtnaLongOptions` (extends `BuildModelOptions`;
`nodeGroups?`, `actorLevels?`, `disambiguate?`), `LongRow` (`session`,
`order`, `code`, `actor?`).

**Meta-paths** — `MetaPathRow` (`schema`, `length`, `gap`, `count`,
`nSequences`, `support`, `frequency`, `lift`), `ExtractMetaPathsOptions`,
`FormatPathsOptions` (`n?`, `nSequences?`, `level?`).

**Diff** — `NetworkDiff` (`labels`, `partition?`, `actorLevels?`, `edges`,
`counts`), `NetworkDiffEdge` (`from`, `to`, `weightA`, `weightB`,
`magnitude`, `kind`).

**HTNA plot** — `HtnaPlotData`, `HtnaPlotOptions`, `HtnaSvgOptions`,
`HtnaPlotNode`, `HtnaPlotEdge`, `HtnaPlotLegendEntry`,
`HtnaShape` (`'circle' | 'square' | 'diamond' | 'triangle' | 'pentagon' |
'hexagon' | 'star' | 'cross'`),
`HtnaLayout` (`'bipartite-arcs' | 'circular' | 'vertical' | 'horizontal'`).

**Sequence plot** — `SequencePlotHtnaData`, `SequencePlotHtnaOptions`.

**MCML plot** — `McmlMatrix` (`Matrix | number[][]`),
`McmlClusters` (`Record<string, readonly string[]>` — state clusters),
`McmlTheme` (`'classic' | 'rich' | 'light'`),
`McmlSummaryPie` (`'inits' | 'self'`),
`McmlEdgeColorBy` (`'auto' | 'cluster' | 'sign'`),
`McmlAggregation` (`'sum' | 'mean' | 'max'`),
`McmlNodeShape` (`'circle' | 'square' | 'diamond' | 'triangle'`),
`McmlLayerLike` (`weights`, `inits?`, `labels`, `data?`),
`McmlLike` (`macro`, `clusters?`, `cluster_members`, `meta?`, `nodes_df?`),
`McmlPlotOptions`, `McmlPlotNode`, `McmlPlotShell`, `McmlSummaryNode`,
`McmlPlotEdgeKind` (`'within' | 'between' | 'summary' | 'inter-layer'`),
`McmlPlotEdge`, `McmlPlotLegendEntry`, `McmlPlotData`.

Related helpers documented elsewhere: `isHtna()` (from `ladyna/core`) tests
whether a `TNA` carries a partition; `asHTNA`/`as_htna` (from `ladyna/analysis`)
convert compatible objects.
