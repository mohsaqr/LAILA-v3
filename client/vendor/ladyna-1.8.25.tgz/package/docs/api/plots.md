# ladyna plots — the complete catalogue

**Generated** by `tools/generate-plots-index.mjs` from the built library and
[`exports.md`](exports.md) — do not edit the tables by hand. Every input type,
return type and subpath below is read from `dist/**/*.d.ts`.

ladyna ships **59 painter implementations**, exported under
**64 camelCase names** (5 of them root-only renames, below) plus
**9 snake_case R-style aliases** — 73 exported names in total.

## The one rule

Every painter returns a **self-contained SVG string**. There is no D3, no canvas,
no runtime dependency, and no DOM required — the whole wiring idiom is:

```ts
import { plotNetwork, plotProcessMap, processMap } from 'ladyna';

element.innerHTML = plotNetwork(model);
element.innerHTML = plotProcessMap(processMap(model));
```

If a picture you need does not exist, add an option or a painter to the matching
module — do not hand-roll a one-off chart in app, demo, or notebook code.

## Return type: `string`, or `Record` for groups

Painters that accept a grouped input are overloaded: a single object returns one
SVG `string`, a grouped input returns a `Record<groupName, string>` — one SVG per
group. These are the painters where that applies:

| painter | input | returns |
|---|---|---|
| `plotComparison` | `LSAComparison \| LSAPairwiseComparison \| LSABayesComparison \| LSABayesPairwiseComparison` | `string \| Record<string, string>` |
| `plotComparison` | `TreeComparison` | `string` |
| `plotLSA` | `LSAFit \| LSAGroup` | `string \| Record<string, string>` |
| `plotNetwork` | `GroupTNA` | `Record<string, string>` |
| `plotNetwork` | `TNA` | `string` |
| `plotProcessMap` | `Record<string, ProcessMap>` | `Record<string, string>` |
| `plotProcessMap` | `ProcessMap` | `string` |
| `plotSequenceIndex` | `Record<string, SequenceData>` | `Record<string, string>` |
| `plotSequenceIndex` | `SequenceData` | `string` |
| `plotStateDistribution` | `Record<string, SequenceData>` | `Record<string, string>` |
| `plotStateDistribution` | `SequenceData` | `string` |

Everything else returns a plain `string`.

## The catalogue

### Networks

`ladyna/core` — the default views for a TNA model. Full signatures, options and defaults: [core.md](core.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotDifferenceNetwork` | Δ = A − B between two networks, edges signed and colour-coded, with an optional permutation-significance overlay. | `TNA` / `GroupTNA` | `ladyna`, `ladyna/core`, `light`, `full` |
| `plotNetwork` | The transition network — circle layout, weight-scaled curved edges, initial-probability rings. The R `plot.tna` analogue, and the default view for any model. | `GroupTNA` / `TNA` | `ladyna`, `ladyna/core`, `light`, `full` |
| `plotNetworkGrid` | Small multiples of every group in one SVG, sharing a layout and colour scale so panels are visually comparable. | `GroupTNA` | `ladyna`, `ladyna/core`, `light`, `full` |

### Analysis results

`ladyna/analysis` — figures for centralities, comparison, reliability, stability, Markov order, topology. Full signatures, options and defaults: [analysis.md](analysis.md). `plotMotifSubnetwork`, `plotMotifs`, `plotSimplicial` are documented in [motifs.md](motifs.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotCentralities` | Horizontal bars for one centrality measure, sorted descending; pass `measures` for a small-multiples grid. | `CentralityResult` | `ladyna`, `ladyna/analysis` |
| `plotCoefficients` | Generic forest/coefficient plot — one row per estimate with a confidence interval, marker filled when p < .05. | `readonly CoefficientItem[]` | `ladyna`, `ladyna/analysis` |
| `plotCompareHeatmap` | Pattern × group heatmap of residuals for two or more groups, rows ranked by largest absolute z. | `readonly CompareRow[]` | `ladyna`, `ladyna/analysis` |
| `plotComparePyramid` | Back-to-back bars for exactly two groups, each bar filled by that cell’s residual. | `readonly CompareRow[]` | `ladyna`, `ladyna/analysis` |
| `plotEdgeReliability` | Case-drop edge reliability — a 2×2 grid of mean ± SD ribbons against the proportion of cases dropped. | `CasedropReliabilityResult` | `ladyna`, `ladyna/analysis` |
| `plotMarkovOrder` | Markov order selection — log-likelihood/AIC/BIC across orders beside the likelihood-ratio tests. | `MarkovOrderResult` | `ladyna`, `ladyna/analysis` |
| `plotMatrix` | Labelled matrix heatmap: one rect per cell, optional in-cell values, colour legend. | `Matrix \| readonly (readonly number[])[]` | `ladyna`, `ladyna/analysis` |
| `plotMotifSubnetwork` | One induced named three-node model drawn by the standard TNA network painter, with substantial weight-scaled curved arrows and no pan/zoom. | `MotifInput` | `ladyna`, `ladyna/analysis` |
| `plotMotifs` | Cograph-style directed motif views: MAN-type counts, significance bars, canonical patterns, or named weighted triad cards. | `MotifAnalysisResult` | `ladyna`, `ladyna/analysis` |
| `plotSimplicial` | The simplicial complex — vertices, edges and filled higher-order faces of a Q-analysis structure. | `SimplicialComplex` | `ladyna`, `ladyna/analysis`, `light`, `full` |
| `plotSplitHalf` | Split-half reliability across metrics, from `reliabilityAnalysis()` or `networkReliability()`. | `ReliabilityResult \| NetworkReliabilityResult` | `ladyna`, `ladyna/analysis` |
| `plotStability` | Edge-stability curves across the resampling proportions. | `StabilityResult` | `ladyna`, `ladyna/analysis` |

### Sequences

`ladyna/sequences` — the TraMineR-parity sequence figures. Full signatures, options and defaults: [sequences.md](sequences.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotEntropyProfile` | Normalized cross-sectional entropy per position — one line per group, overlaid in a single figure. | `SequenceData \| Record<string, SequenceData>` | `ladyna`, `ladyna/sequences` |
| `plotMeanTimes` | Mean positions spent in each state (TraMineR `seqmtplot`) as grouped bars with ±SD whiskers. | `SequenceData \| Record<string, SequenceData>` | `ladyna`, `ladyna/sequences` |
| `plotMosaic` | A true mosaic (Marimekko) of a contingency table, tiles filled by standardized residual. | `readonly number[][]` | `ladyna`, `ladyna/sequences` |
| `plotPatternOutcome` | Pattern presence against an outcome — counts per pattern split by outcome level. | `readonly PatternOutcomeCountRow[]` | `ladyna`, `ladyna/sequences` |
| `plotPatterns` | Discovered sequence patterns ranked by their support/strength metric. | `PatternResult \| readonly PatternEntry[]` | `ladyna`, `ladyna/sequences` |
| `plotSequenceIndex` | TraMineR `seqIplot`: one row per sequence, one coloured rectangle per position. | `Record<string, SequenceData>` / `SequenceData` | `ladyna`, `ladyna/sequences` |
| `plotStateDistribution` | Cross-sectional state distribution at each position (TraMineR `seqdplot`). | `Record<string, SequenceData>` / `SequenceData` | `ladyna`, `ladyna/sequences` |

### Heterogeneous & hierarchical

`ladyna/htna` — actor networks and micro/macro cluster layers. Full signatures, options and defaults: [htna.md](htna.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotHTNA` | The heterogeneous actor network — shape-coded nodes, initial-probability rings, weight-scaled curved edges. | `TNA` | `ladyna`, `ladyna/htna`, `light`, `full` |
| `plotMCML` | Hierarchical micro/macro cluster network, drawn from `buildMCML()` or a model plus clusters. | `TNA \| McmlLike` | `ladyna`, `ladyna/htna`, `light`, `full` |

### Transition trees

`ladyna/transitiontrees` — 12 painters over a fitted context tree. Full signatures, options and defaults: [transitiontrees.md](transitiontrees.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotBootstrap` | Forest plot of bootstrap G² CIs against the χ² critical value, coloured by stability class. | `BootstrapPathwaysResult` | `ladyna`, `ladyna/transitiontrees` |
| `plotComparison` | Side-by-side comparison of two fitted context trees. | `TreeComparison` | `ladyna`, `ladyna/transitiontrees` |
| `plotDistributions` | Stacked 100% next-state probability bars, one per context, with a state legend. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotDivergence` | Lollipop chart of KL divergence from the shorter-history prediction, marking prediction flips. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotGroupDifference` | Signed heatmap of next-state probability differences between two groups of trees. | `Record<string, ContextTree>` | `ladyna`, `ladyna/transitiontrees` |
| `plotPathwayResamples` | Small-multiple histograms of the raw resample distributions per pathway. | `BootstrapPathwaysResult` | `ladyna`, `ladyna/transitiontrees` |
| `plotPathways` | Next-state probability heatmap — one row per pathway, modal cell bold, `›` marking flips. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotPredictive` | Held-out predictive performance from `scorePositions` — log loss, ECDF, or per-position. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotPruning` | Suffix-memory diagnostic: a pathway’s suffix chain, bright where the node survives pruning. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotTrajectories` | Forward prefix-trajectory flow tree over the training data, ribbon width encoding flow. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotTree` | The context tree itself — `horizontal` phylogram, radial `dendrogram`, or count-proportional `icicle`. | `ContextTree` | `ladyna`, `ladyna/transitiontrees` |
| `plotTuning` | Cross-validated perplexity from `tuneTree` versus maximum depth, best configuration starred. | `TuneTreeResult` | `ladyna`, `ladyna/transitiontrees` |

### Lag sequential analysis

`ladyna/lagdynamics` — LSA fits, inference and comparison. Full signatures, options and defaults: [lagdynamics.md](lagdynamics.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotChords` | Chord diagram — flow-sized ring segments, ribbons sized and coloured by chosen metrics. | `LSAFit` | `ladyna` **as `plotLSAChords`**, `ladyna/lagdynamics` |
| `plotComparison` | Back-to-back comparison barrel (or difference heatmap) for a `compareLSA` / `bayesCompareLSA` result. | `LSAComparison \| LSAPairwiseComparison \| LSABayesComparison \| LSABayesPairwiseComparison` | `ladyna` **as `plotLSAComparison`**, `ladyna/lagdynamics` |
| `plotForest` | Radial forest of bootstrap or certainty CIs, one spoke per edge, dashed null ring. | `LSABootstrapResult \| LSACertaintyResult` | `ladyna` **as `plotLSAForest`**, `ladyna/lagdynamics` |
| `plotLSA` | Dispatcher: `heatmap` (default), `network`, `chord`, or `sunburst` — routes to the painter below. | `LSAFit \| LSAGroup` | `ladyna`, `ladyna/lagdynamics` |
| `plotLSAHeatmap` | Matrix heatmap of the LSA fit, rows ordered by outgoing volume, modal/significant cells bold. | `LSAFit` | `ladyna`, `ladyna/lagdynamics` |
| `plotPolar` | Rose/wedge polar sunburst of outgoing transitions. | `LSAFit` | `ladyna` **as `plotLSAPolar`**, `ladyna/lagdynamics` |
| `plotTransitions` | The lag-sequential transition network, with cograph-geometry self-loops. | `LSAFit` | `ladyna` **as `plotLSATransitions`**, `ladyna/lagdynamics` |

### Process mining

`ladyna/processmining` — process maps and trace variants. Full signatures, options and defaults: [processmining.md](processmining.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotProcessMap` | Start→End process map of a model, event log, or sequences. | `Record<string, ProcessMap>` / `ProcessMap` | `ladyna`, `ladyna/processmining`, `light`, `full` |
| `plotVariants` | Trace variants as segmented bars, one row per distinct path. Takes the `traceVariants()` result. | `readonly TraceVariant[]` | `ladyna`, `ladyna/processmining`, `light`, `full` |

### Association rules

`ladyna/association` — itemsets, rules, and rule diagnostics. Full signatures, options and defaults: [association.md](association.md).

| verb | draws | takes | import from |
|---|---|---|---|
| `plotAssociationChord` | Flow-sized item arcs joined by true support-width association ribbons. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotAssociationForceNetwork` | Deterministic force-directed item network with boundary-aware curved arrows; the same layout powers the draggable explorer. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotAssociationNetwork` | Directed item association network with support-weighted edges, lift color, and connectivity-scaled nodes. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotAssociations` | Dispatcher for every association-rule and frequent-itemset visualization. | `RuleInput \| ItemsetInput` | `ladyna`, `ladyna/association` |
| `plotFrequentItemsets` | Horizontal support/count ranking of frequent, closed, maximal, or generator itemsets. | `ItemsetInput` | `ladyna`, `ladyna/association` |
| `plotGroupedRuleMatrix` | Compact LHS-group × RHS balloon matrix for large rule collections. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotItemsetLattice` | Hasse-style frequent-itemset lattice with immediate-subset edges. | `ItemsetInput` | `ladyna`, `ladyna/association` |
| `plotItemsetUpSet` | UpSet-style support bars aligned with an exact item-membership matrix. | `ItemsetInput` | `ladyna`, `ladyna/association` |
| `plotRuleDoubleDecker` | Conditional RHS distribution split by LHS presence for one rule. | `AssociationRule` | `ladyna`, `ladyna/association` |
| `plotRuleGraph` | Directed bipartite item → rule → item graph. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotRuleMatrix` | LHS × RHS balloon matrix, size and colour encoding rule quality. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotRuleMosaic` | Area-proportional 2×2 mosaic for one rule and its transaction database. | `AssociationRule` | `ladyna`, `ladyna/association` |
| `plotRuleParallel` | Parallel-coordinate rule paths from antecedent items through the implication to consequent items. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotRuleSankey` | Conserved alluvial flow with stacked support ribbons from antecedents through rules to consequents. | `RuleInput` | `ladyna`, `ladyna/association` |
| `plotRuleScatter` | Support × confidence scatterplot, with lift shading; two-key mode shades by rule length. | `RuleInput` | `ladyna`, `ladyna/association` |

## Name collisions and root renames

`lagdynamics` and `transitiontrees` both export a `plotComparison`, and
`lagdynamics` uses several generic painter names. On the **root** `ladyna`
subpath the lagdynamics painters are therefore renamed; on `ladyna/lagdynamics`
they keep their original names.

| module-local name (`ladyna/lagdynamics`) | root name (`ladyna`) |
|---|---|
| `plotChords` | `plotLSAChords` |
| `plotComparison` | `plotLSAComparison` |
| `plotForest` | `plotLSAForest` |
| `plotPolar` | `plotLSAPolar` |
| `plotTransitions` | `plotLSATransitions` |

`plotLSA` and `plotLSAHeatmap` keep their names on both. The `transitiontrees`
`plotComparison` is unaffected — it is the one that keeps the plain name at root.

## snake_case aliases

R-style spellings, for migration and parity audits. Each is the same function
object as its canonical name.

| alias | canonical |
|---|---|
| `plot_chords` | `plotChords` |
| `plot_forest` | `plotForest` |
| `plot_mcml` | `plotMCML` |
| `plot_motif_subnetwork` | `plotMotifSubnetwork` |
| `plot_motifs` | `plotMotifs` |
| `plot_polar` | `plotPolar` |
| `plot_process_map` | `au` |
| `plot_transitions` | `plotTransitions` |
| `plot_variants` | `av` |

## Options

Painters share a common option shape — `width`, `height`, `title`, `subtitle`,
`background` — on top of per-painter options documented on the module pages.
`transitiontrees` painters additionally take `theme: 'dark' | 'light'`.

## Live galleries

`npm run demo`, then: `demo/motifs.html`, `demo/association.html`, `demo/processmining.html`,
`demo/mcml.html`, `demo/lagdynamics.html`, `demo/transitiontrees/`.
