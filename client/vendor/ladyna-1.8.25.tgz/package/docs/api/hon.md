# ladyna HON family — higher-order networks (R Nestimate ports)

The HON family models sequential data beyond the first-order Markov
assumption: variable-order rule networks (HON/HON+), multi-order De Bruijn
generative models (MOGen), hypergeometric pathway-anomaly detection (HYPA),
matrix-factorization embeddings (HONEM), order-1-failure diagnostics
(path dependence), pathway extraction, multi-cluster multi-level transition
networks (MCML), and Mixture Markov Model clustering (MMM).

**R reference: `Nestimate` (source tree, currently 0.8.5).** Every algorithm
in this family is validated against R Nestimate ground truth
(`tests/{mogen,hon,hypa,honem,path-dependence,pathways}-r-groundtruth.test.ts`
and the MCML/MMM suites), not against the R `tna` package. Per the project
reference contract, *"differs from `tna`" is NOT a defect for this family* —
the pinned reference is per module. Deterministic analyses match Nestimate to
≤ 1e-12; MMM has a separate validation contract (ARI = 1 + log-likelihood,
because mixture labels are identifiable only up to permutation).

**Visualization:** the MCML SVG renderer `plotMCML()` lives in `ladyna/htna`
(see `docs/api/htna.md`) — a `buildMCML()` result pipes directly into it.
HON/HYPA/MOGen **pathways** get the blob view: feed them to
`buildSimplicialPathway()` and render with `plotSimplicial()`, this module's
one painter (see [topology.md](topology.md)).

**Availability** (from `docs/api/exports.md`): every export below is
importable from the root (`ladyna`) and `ladyna/analysis`. All are also in
`ladyna/light` and `ladyna/full` except: `clusterMmm` and `validateMmmOptions`
(root, analysis, light — not full) and `mmmAssign` (root and analysis only).
`ladyna/wasm` and `ladyna/wasm/web` mirror `ladyna/light`.

## Import

```js
import {
  // MOGEN
  buildMogen, mogenTransitions, pathCounts, stateFrequencies,
  // HON
  buildHon,
  // HYPA
  buildHypa,
  // HONEM
  buildHonem,
  // Path dependence
  pathDependence,
  // Pathways
  pathwaysHon, pathwaysHypa, pathwaysMogen,
  // MCML (+ Nestimate-style snake_case aliases)
  buildMCML, clusterSummary, summarizeMCML, mcmlLayerModel,
  separateMCML, asTNA, asHTNA, aggregateMCMLWeights,
  build_mcml, cluster_summary, summarize_mcml, separate_mcml, as_tna, as_htna,
  // MMM
  mmm, clusterMmm, mmmAssign, validateMmmOptions,
} from 'ladyna';            // or 'ladyna/analysis'
```

All sequence-consuming verbs accept `string[][]`, `SequenceData`
(`(string | null)[][]` wide format, one row per trajectory), or a `TNA`
built by `tna()` (its `.data` is used). Examples below share this dataset
(order-2 structure: `A -> B` is always followed by `C`, `D -> B` by `A`):

```js
const seqs = [
  ['A','B','C','A','B','C','A','B','C'],
  ['D','B','A','D','B','A','D','B','A'],
  ['A','B','C','D','B','A','A','B','C'],
  ['D','B','A','A','B','C','D','B','A'],
  ['A','B','C','A','B','C','D','B','A'],
  ['D','B','A','D','B','A','A','B','C'],
];
```

## MOGEN — multi-order generative model

Port of `Nestimate::build_mogen` / `mogen_transitions` / `path_counts` /
`state_frequencies`. Builds De Bruijn graph layers from order 0 (marginal)
up to order `maxOrder`, computes log-likelihood, AIC, BIC, and degrees of
freedom per order, and selects the optimal Markov order via the chosen
information criterion (Scholtes 2017; Gote & Scholtes 2023).

### `buildMogen(data, options?): MogenResult`

```ts
buildMogen(data: MogenInput, options: MogenOptions = {}): MogenResult
```

| Option | Default | Meaning |
|---|---|---|
| `maxOrder` | `5` | Highest order tested (clamped to longest path − 1) |
| `criterion` | `'aic'` | `'aic'`, `'bic'`, or `'lrt'` (sequential likelihood-ratio test) |
| `lrtAlpha` | `0.01` | Significance level for the sequential LRT, in (0, 1) |

Returns per-order `aic`, `bic`, `logLikelihood`, cumulative `dof`,
per-layer `layerDof`, the per-order `transitionMatrices` (index 0 is the
1×S marginal), raw `countMatrices`, `transitionNodes` labels, `states`,
`nPaths`, `nObservations`, and the selected `optimalOrder`.

```js
const mg = buildMogen(seqs, { maxOrder: 3, criterion: 'bic' });
// {
//   optimalOrder: 2, criterion: 'bic', orders: [0, 1, 2, 3],
//   aic:    [149.6, 93.12, 55.04, 59.04],
//   bic:    [155.57, 107.04, 72.94, 80.92],
//   logLik: [-71.8, -39.56, -18.52, -18.52],
//   dof: [3, 7, 9, 11], states: ['A', 'B', 'C', 'D'],
//   nPaths: 6, nObservations: 54, ...
// }
```

### `mogenTransitions(mg, options?): MogenTransitionRow[]`

```ts
mogenTransitions(mg: MogenResult,
  options: { order?: number; minCount?: number } = {}): MogenTransitionRow[]
```

Tidy transition table at one order (default `mg.optimalOrder`), sorted by
count descending. `probability` is rounded to 4 decimals with R's
round-half-to-even, matching Nestimate output exactly. `minCount` (default
`1`) drops rarer transitions.

```js
mogenTransitions(mg, { order: 2 });
// [
//   { path: 'A -> B -> C', count: 9, probability: 1, from: 'A -> B', to: 'C' },
//   { path: 'D -> B -> A', count: 9, probability: 1, from: 'D -> B', to: 'A' },
//   { path: 'A -> A -> B', count: 3, probability: 1, from: 'A -> A', to: 'B' },
//   ...
// ]
```

### `pathCounts(data, k = 2, top?): PathCountRow[]`

Counts every k-state path (k ≥ 2) pooled across trajectories; `top` keeps
only the most frequent rows. Sorted by count descending, then path.

```js
pathCounts(seqs, 3, 4);
// [
//   { path: 'A -> B -> C', count: 9, proportion: 0.2143 },
//   { path: 'D -> B -> A', count: 9, proportion: 0.2143 },
//   { path: 'A -> A -> B', count: 3, proportion: 0.0714 },
//   { path: 'A -> D -> B', count: 3, proportion: 0.0714 }
// ]
```

### `stateFrequencies(data): StateFrequencyRow[]`

Marginal state counts and proportions, sorted by count descending.

```js
stateFrequencies(seqs);
// [
//   { state: 'A', count: 18, proportion: 0.3333 },
//   { state: 'B', count: 18, proportion: 0.3333 },
//   { state: 'C', count: 9,  proportion: 0.1667 },
//   { state: 'D', count: 9,  proportion: 0.1667 }
// ]
```

## HON — higher-order network builder

### `buildHon(data, options?): HonResult`

```ts
buildHon(data: HonInput, options: HonOptions = {}): HonResult
```

Port of `Nestimate::build_hon`. Implements both BuildHON (Xu,
Wickramarathne & Chawla 2016) and BuildHON+ (Saebi et al. 2020). A context
is extended to a higher order only when the KL-divergence of its
next-state distribution against the current valid rule exceeds the
adaptive threshold `order / log2(1 + N)`. HON+ (the default) builds
observations lazily and prunes with a MaxDivergence pre-check; edges are
then rewired so higher-order nodes are properly connected.

| Option | Default | Meaning |
|---|---|---|
| `maxOrder` | `5` | Maximum rule order |
| `minFreq` | `1` | Minimum count for a transition to be retained |
| `collapseRepeats` | `false` | Collapse adjacent duplicate states first |
| `method` | `'hon+'` | `'hon+'` (lazy, MaxDivergence pruning) or `'hon'` (eager BuildHON) |

Returns the arrow-notation adjacency `matrix` (row-stochastic per rule),
sorted `nodes`, the `edges` list (`path`, `from`, `to`, `count`,
`probability`, `fromOrder`, `toOrder`), plus `nNodes`, `nEdges`,
`firstOrderStates`, `maxOrderRequested`, `maxOrderObserved`, `minFreq`,
`nTrajectories`, `directed: true`, `method`.

```js
const hon = buildHon(seqs, { maxOrder: 3 });
// { nNodes: 7, nEdges: 12, maxOrderObserved: 2, method: 'hon+',
//   firstOrderStates: ['A', 'B', 'C', 'D'], nTrajectories: 6, ... }
hon.nodes;
// ['A', 'A -> B', 'B', 'B -> A', 'C', 'D', 'D -> B']
hon.edges;   // first rows:
// [
//   { path: 'A -> D', count: 3, probability: 0.2, fromOrder: 1, toOrder: 1, ... },
//   { path: 'A -> A', count: 3, probability: 0.2, fromOrder: 1, toOrder: 1, ... },
//   { path: 'A -> B', count: 9, probability: 0.6, fromOrder: 1, toOrder: 2, ... },
//   ...
// ]
```

## HYPA — hypergeometric pathway anomaly

### `buildHypa(data, options?): HypaResult`

```ts
buildHypa(data: HypaInput, options: HypaOptions = {}): HypaResult
```

Port of `Nestimate::build_hypa` (LaRock et al. 2020). Builds the k-th
order De Bruijn graph, then scores every edge against a
multi-hypergeometric null model: `p_under = P(X ≤ f)` and
`p_over = P(X ≥ f)` with `X ~ Hypergeometric(N, K, n)` where
`Xi[v,w] = out_strength[v] · in_strength[w]`, `N = round(Σ Xi)`,
`K = round(Xi[v,w])`, `n = Σ adj` (clamped to `N`). The hypergeometric CDF
matches R's `phyper` exactly. Anomalies are classified from
BH-adjusted p-values (`observed ≥ minCount` required).

| Option | Default | Meaning |
|---|---|---|
| `k` | `3` | De Bruijn order |
| `alpha` | `0.05` | Significance level, in (0, 0.5) |
| `minCount` | `5` | Minimum observed count for an edge to be flagged |
| `pAdjustMethod` | `'BH'` | Any `PAdjustMethod` (`'holm'`, `'bonferroni'`, …) or `'none'` |

Returns `scores` (over-anomalies sorted by ratio descending, then
under-anomalies by ratio ascending, then normal edges), the raw
`adjacency` matrix and `adjacencyLabels`, the propensity matrix `xi`, plus
`k`, `alpha`, `pAdjust`, `nAnomalous`, `nOver`, `nUnder`, `nEdges`,
`nodes`, `directed: true`.

```js
const hy = buildHypa(seqs, { k: 2, minCount: 2 });
// { k: 2, nEdges: 10, nAnomalous: 0, nOver: 0, nUnder: 0, ... }
hy.scores;   // first rows:
// [
//   { path: 'A -> A -> B', observed: 3, expected: 2.471, ratio: 1.214,
//     pAdjustedOver: 0.5754, anomaly: 'normal', ... },
//   { path: 'A -> B -> C', observed: 9, expected: 11.118, ratio: 0.81,
//     pAdjustedOver: 0.8378, anomaly: 'normal', ... },
//   ...
// ]
```

Each `HypaScoreRow` also carries `pValue` (alias of `pUnder`, matching R's
`p_value` column), `pUnder`, `pOver`, `pAdjustedUnder`, `pAdjustedOver`.

## HONEM — higher-order network embedding

### `buildHonem(hon, options?): HonemResult`

```ts
buildHonem(hon: HonemInput, options: HonemOptions = {}): HonemResult
```

Port of `Nestimate::build_honem` (Saebi et al. 2020). Direct matrix
factorization — no random walks: `D` is the row-normalized HON adjacency,
the neighborhood matrix is
`S = (1/Z) Σ_{k=0..maxPower} exp(-k) · D^{k+1}`, and the embedding is
`U[, 1:dim] · diag(√σ)` from a truncated SVD of `S` (hand-rolled Jacobi
eigendecomposition of `SᵀS`, then `U = SVΣ⁻¹`). Input is a `buildHon()`
result or a bare square `Matrix` (nodes then auto-named `node_1`, …).

| Option | Default | Meaning |
|---|---|---|
| `dim` | `32` | Embedding dimension (clamped to `nNodes − 1`) |
| `maxPower` | `10` | Highest matrix power in the decay sum |

Singular vectors are sign-ambiguous: compare `|embedding|` element-wise
across implementations (singular values are exact) — that is the contract
the R-ground-truth test uses.

```js
const em = buildHonem(hon, { dim: 4 });
// { dim: 4, nNodes: 7, explainedVariance: 0.95378,
//   singularValues: [1.1056, 0.7053, 0.5986, 0.53], ... }
// |embeddings| row 0: [0.3206, 0.2202, 0.2014, 0.0476]
```

## Path dependence

### `pathDependence(data, options?): PathDependenceResult`

```ts
pathDependence(data: PathDependenceInput,
  options: PathDependenceOptions = {}): PathDependenceResult
```

Port of `Nestimate::path_dependence`. Diagnoses where the order-1 Markov
assumption fails: for each order-k context it compares the empirical
next-state distribution `P(next | full context)` against the order-1
prediction `P(next | last state)`, reporting KL divergence, entropy drop,
and whether the modal next state flips. Windows containing missing cells
are dropped (matching R's `grepl("NA", ...)` behavior).

| Option | Default | Meaning |
|---|---|---|
| `order` | `2` | Context length (≥ 2) |
| `minCount` | `5` | Minimum context occurrences to keep a row |
| `base` | `2` | Logarithm base (2 = bits) |

Returns `contexts` sorted by KL descending (`context`, `n`, `hOrder1`,
`hOrderK`, `hDrop`, `kl` — `Infinity` when the order-1 model gives zero
mass to an observed target — `topO1`, `topOk`, `flips`), plus chain-level
count-weighted aggregates over finite-KL contexts.

```js
const pd = pathDependence(seqs, { order: 2, minCount: 3 });
pd.contexts;   // first rows:
// [
//   { context: 'B -> A', n: 6, hOrder1: 1.371, hOrderK: 1, kl: 1.3219,
//     topO1: 'B', topOk: 'A', flips: true },
//   { context: 'A -> B', n: 9, hOrder1: 1, hOrderK: 0, kl: 1,
//     topO1: 'A', topOk: 'C', flips: true },
//   { context: 'D -> B', n: 9, hOrder1: 1, hOrderK: 0, kl: 1,
//     topO1: 'A', topOk: 'A', flips: false },
//   ...
// ]
pd.chain;
// { klWeighted: 0.7227, hDropWeighted: 0.6774, nContexts: 8, nFlips: 2 }
```

## Pathways — top-N pathway extraction

Port of the `Nestimate::pathways` generic. Each function returns pathway
strings in `"A B -> C"` simplicial format (sources space-separated, last
arrow to the target), suitable for simplicial-complex tooling
(`buildSimplicialPathway`, cograph `plot_simplicial`).

### `pathwaysHon(hon, options?): string[]`

Higher-order edges (`fromOrder > 1`) from a `buildHon()` result, sorted by
count descending.

| Option | Default | Meaning |
|---|---|---|
| `minCount` | `1` | Minimum edge count |
| `minProb` | `0` | Minimum transition probability |
| `top` | all | Keep only the N most frequent |
| `order` | any | Pin to one specific `fromOrder` |

### `pathwaysHypa(hypa, options?): string[]`

Anomalous pathways from a `buildHypa()` result. `type` (default `'all'`)
selects `'over'` (ratio descending), `'under'` (ratio ascending), or both
(over first, then under — R's rbind order).

### `pathwaysMogen(mogen, options?): string[]`

Transitions at one order of a `buildMogen()` result (default
`optimalOrder`; returns `[]` when that is 0). Options: `order`, `minCount`
(default `1`), `minProb` (default `0`), `top`.

```js
pathwaysHon(hon, { top: 3 });          // ['A B -> C', 'D B -> A', 'B A -> D']
pathwaysHypa(hy, { type: 'over' });    // []   (no anomalies in this small dataset)
pathwaysMogen(mg, { order: 2, top: 3 }); // ['A B -> C', 'D B -> A', 'A A -> B']
```

### Tidy pathway verbs — `honPathways` / `mogenPathways` / `hypaPathways`

```ts
function honPathways(hon: HonResult, options?: PathwaysHonOptions): PathwayStatsRow[]
function mogenPathways(mogen: MogenResult, options?: PathwaysMogenOptions): PathwayStatsRow[]
function hypaPathways(hypa: HypaResult, options?: PathwaysHypaOptions): PathwayStatsRow[]
```

Same inputs, same filtering and same ordering as `pathwaysHon` /
`pathwaysMogen` / `pathwaysHypa` — but one tidy row per pathway instead of a
bare string, carrying **every statistic the underlying result holds**. The
string verbs are unchanged and stay available for the simplicial tooling that
consumes them.

Each `PathwayStatsRow` has:

| Column | Present for | Meaning |
|---|---|---|
| `path` | all | Simplicial string, `"A B -> C"` — identical to the string verbs |
| `states` | all | Every state token, context first and target last |
| `context` | all | The source context tokens (`states` without the target) |
| `target` | all | The predicted next state |
| `order` | all | Number of context tokens (HON's `fromOrder`, MOGen's / HYPA's `k`) |
| `count` | HON, MOGen | Raw observation count |
| `probability` | HON, MOGen | Transition probability |
| `toOrder` | HON | Order of the target tuple after rewiring |
| `observed`, `expected`, `ratio` | HYPA | Hypergeometric comparison |
| `pValue`, `pUnder`, `pOver` | HYPA | Raw tails (`pValue` is the under tail, matching R's `p_value`) |
| `pAdjustedUnder`, `pAdjustedOver` | HYPA | Adjusted tails |
| `pAdjusted` | HYPA | The tail matching `anomaly` — `pAdjustedOver` when over-represented |
| `anomaly` | HYPA | `'over'`, `'under'` or `'normal'` |

`states` and `context` are **real token arrays**, read back from the encoded
k-gram keys rather than re-split out of `path`. That matters because the
simplicial `path` format joins context states with a space, so a state label
like `"read book"` cannot be recovered from the string — but survives intact
in `context`.

`hypaPathways` gained the `top` option its siblings already had (truncate
after ordering); `pathwaysHypa` accepts it too, which is purely additive.

```js
honPathways(hon, { top: 2 });
// [ { path: 'A B -> C', states: ['A','B','C'], context: ['A','B'], target: 'C',
//     order: 2, count: 9, probability: 0.75, toOrder: 2 }, … ]

hypaPathways(hy, { type: 'over', top: 1 })[0];
// { path: 'A -> B', states: ['A','B'], context: ['A'], target: 'B', order: 1,
//   observed: 12, expected: 6.2, ratio: 1.94, anomaly: 'over',
//   pAdjusted: 0.018, … }
```

## MCML — multi-cluster multi-level transition networks

Computation counterpart of Nestimate's `build_mcml()` / `cluster_summary()`
contract. Given a partition of the state space into named clusters, MCML
produces a **macro** layer (cluster-to-cluster transitions) and one
**micro** layer per cluster (within-cluster transitions). Rendering is in
`ladyna/htna`: pass the `MCML` object to `plotMCML()` (`docs/api/htna.md`).
Snake_case aliases `build_mcml`, `cluster_summary`, `summarize_mcml`,
`separate_mcml`, `as_tna`, `as_htna` are the same functions under
Nestimate's names.

### `buildMCML(input, clusters, options?): MCML`

```ts
buildMCML(input: SequenceData | TNA | McmlEdgeInput[] | Matrix | number[][],
  clusters: McmlClusterMap, options: BuildMCMLOptions = {}): MCML
```

Dispatches on input: sequences (or a count-based `TNA` carrying `.data`)
are decomposed into transition pairs and aggregated per cluster; a bare
matrix / matrix-backed `TNA` delegates to `clusterSummary()`; an edge list
(`{from, to, weight?}[]`) is aggregated directly. Every node must belong
to exactly one cluster.

| Option | Default | Meaning |
|---|---|---|
| `aggregation` | `'sum'` | `'sum'`, `'mean'`, `'median'`, `'max'`, `'min'`, `'density'`, `'geomean'` (zeros excluded, per Nestimate) |
| `type` | `'tna'` | `'tna'` (row-normalize), `'frequency'`, `'cooccurrence'` (symmetrize), `'raw'` |
| `directed` | `true` | `false` symmetrizes before processing |
| `computeWithin` | `true` | Also build the per-cluster micro layers |
| `labels` | — | Required for a bare `Matrix` / `number[][]` input |

```js
const clusters = { social: ['A', 'B'], cognitive: ['C', 'D'] };
const mcml = buildMCML(seqs, clusters, { aggregation: 'sum', type: 'tna' });
mcml.meta;
// { type: 'tna', method: 'sum', directed: true, nNodes: 4, nClusters: 2,
//   clusterSizes: { cognitive: 2, social: 2 }, source: 'transitions' }
mcml.macro.labels;    // ['cognitive', 'social']
// macro weights (row-stochastic): [[0.2, 0.8], [0.3636, 0.6364]]
// mcml.edges: 48 node-level transitions, 24 tagged type: 'between'
```

### `clusterSummary(input, clusters, options?): MCML`

```ts
clusterSummary(input: TNA | Matrix | number[][], clustersInput: McmlClusterMap,
  options: Omit<BuildMCMLOptions, 'type'> = {}): MCML
```

Aggregates an **existing node-level weight matrix** into macro and micro
layers (no sequence decomposition; `meta.type` is `'aggregate'`,
`meta.source` is `'matrix'`). Cluster name order is preserved as given
(buildMCML's sequence path sorts them). Same `aggregation` / `directed` /
`computeWithin` / `labels` options.

```js
const model = tna(seqs);
const cs = clusterSummary(model, clusters, { aggregation: 'mean' });
// macro (mean of node-level probabilities): [[0.4333, 0.35], [0.75, 0.5]]
// cs.meta: { type: 'aggregate', method: 'mean', directed: true, nNodes: 4,
//   nClusters: 2, clusterSizes: { social: 2, cognitive: 2 }, source: 'matrix' }
```

### `summarizeMCML(model): McmlSummaryRow[]`

Tidy per-cluster flow summary: off-diagonal within-cluster total, macro
between-cluster out-flow and in-flow (`betweenIn` is `null` for undirected
models).

```js
summarizeMCML(mcml);
// [
//   { cluster: 'cognitive', size: 2, withinTotal: 1,    betweenOut: 0.8,    betweenIn: 0.3636... },
//   { cluster: 'social',    size: 2, withinTotal: 1.75, betweenOut: 0.3636..., betweenIn: 0.8 }
// ]
```

### `mcmlLayerModel(model, layer = 'macro'): TNA`

Converts one layer (`'macro'` or a cluster name) into an ordinary `TNA`
so every existing ladyna accessor works on it. Model type maps
`tna → 'relative'`, `cooccurrence → 'co-occurrence'`, else `'frequency'`.

```js
mcmlLayerModel(mcml, 'macro');
// TNA with labels ['cognitive', 'social'], type 'relative'
```

### `separateMCML(model): GroupTNA` · `asTNA(model): GroupTNA`

Nestimate `as_tna.mcml()` equivalent: one ordinary TNA per level, named
`macro` plus each within-cluster micro model, packaged as a `GroupTNA` so
grouped ladyna analyses consume all levels. `asTNA` is the
Nestimate-compatible name for the identical function.

```js
const grp = separateMCML(mcml);
Object.keys(grp.models);   // ['macro', 'cognitive', 'social']
```

### `asHTNA(model, options?): TNA`

```ts
asHTNA(model: MCML, options: AsHTNAOptions = {}): TNA
```

Nestimate `as_htna.mcml()` equivalent: expands the hierarchy back into one
faithful **node-level** HTNA by rebuilding from the original sequences
(macro/micro matrices cannot recover node-level between-cluster
transitions). Sequence-built MCML objects retain that source; matrix- or
edge-built objects require `options.data`. `options.clusters` overrides
the partition; remaining options are `BuildModelOptions` passed to the
`htna()` builder (`type` defaults to `'relative'`).

```js
asHTNA(mcml);   // TNA over ['A', 'B', 'C', 'D'], type 'relative', with
                // `partition` and `actorLevels` set from the cluster partition
```

### `aggregateMCMLWeights(input, method = 'sum', nPossible?): number`

The Nestimate-equivalent edge-weight aggregation kernel used by the MCML
builders, exported for reuse. **Zeros are excluded** before aggregating;
an all-zero input returns 0. `'density'` divides the sum by `nPossible`
(the block size) when given; `'geomean'` uses positive values only.

```js
aggregateMCMLWeights([2, 0, 4, 6], 'mean');       // 4
aggregateMCMLWeights([2, 0, 4, 6], 'density', 8); // 1.5
aggregateMCMLWeights([2, 4, 8], 'geomean');       // 4
```

## MMM — Mixture Markov Model clustering

Port of `Nestimate:::.mmm_em` + `.mmm_quality` (and `build_mmm`'s
information criteria): basic deterministic EM in log space with log-sum-exp
and R's exact log-zero epsilon. Linear in N (`O(N·K)`), so it clusters
100k+ sequences where distance-based `clusterData` (O(n²)) is infeasible.
**Separate validation contract:** equivalence to R is ARI = 1 plus matching
log-likelihood, never element-wise cluster ids (labels are identifiable
only up to permutation). Counts follow Nestimate's wide-format contract —
an interior NA *breaks* a transition pair (`A,NA,B → ∅`), it is not
compacted away; the initial state is the first column only.

### `mmm(data, options): MMMResult`

```ts
mmm(data: MmmInput, options: MmmOptions): MMMResult
```

| Option | Default | Meaning |
|---|---|---|
| `k` | required | Number of mixture components (≥ 2) |
| `maxIter` | `200` | Max EM iterations (R `build_mmm`) |
| `tol` | `1e-8` | Convergence tolerance on \|Δ logLik\| |
| `alpha` | `0.01` | Laplace smoothing (R `smooth`) |
| `seed` | `42` | Deterministic init seed (ignored with `initPosterior`) |
| `nStarts` | `1` | Independent EM starts, seeds `seed..seed+nStarts−1`; best logLik wins, ties → lowest seed |
| `initPosterior` | — | N×K row-major starting responsibilities, consumed verbatim (forces `nStarts = 1`; the R cross-check hook) |
| `covariates` | — | n×p covariate rows on cluster membership (no intercept column — one is added); mixing weights become a multinomial logit `π_i = softmax([1, X_i]·B)` |
| `covariateNames` | `X1..Xp` | Names reported with the coefficients |
| `refCluster` | `1` | Reference cluster (1-indexed) whose coefficients are fixed at 0 |

Returns hard `assignments` (1-indexed, ties → lowest index, R
`max.col(ties.method="first")`), soft `responsibilities`, mixing `pi`,
per-cluster `delta` (initial distributions) and row-stochastic
`transition` matrices, `logLik`, `df`, `aic`, `bic`, `icl`
(= BIC + 2·classEntropy), a `quality` block (`avepp`, `aveppOverall`,
`entropy`, `relativeEntropy`, `classificationError`, `classEntropy`),
`iterations`, `converged`, `nStarts`, `restartLogLiks`, `labels`,
`nSequences`, and — when covariates were supplied — a `covariateModel`
(coefficients, odds ratios, Louis-identity SEs, Wald z/p, per-sequence
priors).

```js
const mixSeqs = [
  // 10 rows of ['A','B','A','B','A','B','A','B'],
  // 10 rows of ['C','D','C','D','C','D','C','D']
];
const fit = mmm(mixSeqs, { k: 2, seed: 42 });
// { k: 2, converged: true, iterations: 169, logLik: -14.0427, df: 31,
//   bic: 120.9531, icl: 120.9531,
//   assignments: [2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1],
//   pi: [0.5000..., 0.4999...], quality: { aveppOverall: 0.99999993...,
//   entropy: 0.000002, ... }, labels: ['A', 'B', 'C', 'D'], ... }
```

### `clusterMmm(data, options): MmmGroupTNA`

ladyna analogue of `Nestimate::cluster_mmm`: wraps `mmm()` and returns a
`GroupTNA` — one `'relative'`-type TNA per component (EM transition matrix
as `weights`, EM initial distribution as `inits`, member rows as `data`) —
plus the full fit metadata on `.clustering` (`MmmClustering`: assignments,
responsibilities, mixing, quality, ICs, restart log-likelihoods,
`covariateModel` when fitted, and the aligned sequence frame). The object
is a structurally valid `GroupTNA`, so it flows through every grouped
consumer (group plots, `compareModels`, …). Same options as `mmm()`.

```js
const grp = clusterMmm(mixSeqs, { k: 2, seed: 42, nStarts: 3 });
Object.keys(grp.models);              // ['Cluster 1', 'Cluster 2']
grp.clustering.restartLogLiks;        // [-14.0427, -14.1421, -14.1413]
grp.clustering.bic;                   // 120.9531
```

### `mmmAssign(data, params): MmmAssignResult`

```ts
mmmAssign(data: MmmInput, params: MmmAssignParams): MmmAssignResult
```

Scores (possibly held-out) sequences against an already-fitted mixture in
one linear pass — `log π_m + log δ_m[s₀] + Σ log P_m[from,to]` — using the
same E-step math (EPS smoothing, NA initial → state 0, unknown/NA tokens
skip the pair). Fitting is O(n·S²) in memory; assignment is streaming, so
a mixture fitted on a sample can label millions of sequences. `params` is
`{ pi, delta, transition, labels }`, passed straight off an `MMMResult`
(or reassembled from a `clusterMmm` result).

```js
mmmAssign([['A','B','A','B'], ['C','D','C','D'], ['A','B','C','D']], {
  pi: fit.pi, delta: fit.delta, transition: fit.transition, labels: fit.labels,
});
// { assignments: [2, 1, 2], avepp: [1, 1, 0.5713],
//   aveppOverall: 0.8571, counts: [1, 2], nSequences: 3 }
```

### `validateMmmOptions(o): void`

Validates resolved MMM hyper-parameters (`{k, maxIter, tol, alpha, seed,
nStarts}`), mirroring R `build_mmm`'s `stopifnot` block — throws on
non-whole/non-finite `k < 2`, `maxIter < 1`, `tol ≤ 0`, `alpha < 0`,
`nStarts < 1`, negative `seed`. Called internally by `mmm()`; exported so
`ladyna` and the WASM `tnaw` enforce the identical contract.

```js
validateMmmOptions({ k: 1, maxIter: 200, tol: 1e-8, alpha: 0.01, seed: 42, nStarts: 1 });
// Error: mmm: k must be a whole finite number >= 2
```

## Types

All exported from `ladyna` / `ladyna/analysis` (type-only, erased at runtime).

**MOGEN** — `MogenInput`: `string[][] | SequenceData | TNA`. ·
`MogenCriterion`: `'aic' | 'bic' | 'lrt'`. · `MogenOptions`: options of
`buildMogen`. · `MogenResult`: full multi-order fit (see above). ·
`MogenTransitionRow`: `{path, count, probability, from, to}`. ·
`PathCountRow`: `{path, count, proportion}`. · `StateFrequencyRow`:
`{state, count, proportion}`.

**HON** — `HonInput`: `string[][] | SequenceData | TNA`. · `HonMethod`:
`'hon+' | 'hon'`. · `HonOptions`: options of `buildHon`. · `HonEdgeRow`:
one rewired HON edge. · `HonResult`: adjacency + edge list + metadata.

**HYPA** — `HypaInput`: `string[][] | SequenceData | TNA`. ·
`HypaOptions`: options of `buildHypa`. · `HypaScoreRow`: per-edge anomaly
scores. · `HypaResult`: sorted scores + De Bruijn adjacency + Xi.

**HONEM** — `HonemInput`: `HonResult | Matrix`. · `HonemOptions`:
`{dim?, maxPower?}`. · `HonemResult`: embeddings, singular values,
explained variance.

**Path dependence** — `PathDependenceInput`: `SequenceData | string[][]`.
· `PathDependenceOptions`: `{order?, minCount?, base?}`. ·
`PathDependenceContextRow`: per-context KL/entropy/flip row. ·
`PathDependenceResult`: sorted contexts + chain aggregates.

**Pathways** — `PathwaysHonOptions`: `{minCount?, minProb?, top?, order?}`.
· `PathwaysHypaOptions`: `{type?: 'all' | 'over' | 'under'}`. ·
`PathwaysMogenOptions`: `{order?, minCount?, minProb?, top?}`.

**MCML** — `McmlBuildAggregation`: the seven aggregation names. ·
`McmlBuildType`: `'tna' | 'frequency' | 'cooccurrence' | 'raw'`. ·
`McmlClusterMap`: `Record<string, readonly string[]>` partition. ·
`McmlEdgeInput`: `{from, to, weight?}`. · `McmlLayer`: one layer's
`{weights, inits, labels, data}`. · `McmlEdge`: node-level transition
tagged `'within' | 'between'`. · `McmlMeta`: build metadata. ·
`McmlSource`: retained node-level sequences (`{kind: 'sequences', data}`).
· `MCML`: the full hierarchy (`macro`, `clusters`, `cluster_members`,
`edges`, `meta`, `source`). · `BuildMCMLOptions`: options of `buildMCML`.
· `McmlSummaryRow`: one `summarizeMCML` row. · `AsHTNAOptions`:
`BuildModelOptions` (minus `labels`) + `{data?, clusters?}`.

**MMM** — `MmmInput`: `string[][] | SequenceData | TNA`. · `MmmOptions`:
options of `mmm`/`clusterMmm` (`k` required). · `MmmQuality`: the
cluster-quality block (`.mmm_quality`). · `MMMResult`: the canonical full
fit. · `MmmClustering`: fit metadata carried on `MmmGroupTNA.clustering`.
· `MmmGroupTNA`: `GroupTNA & {clustering: MmmClustering}`. ·
`MmmAssignParams`: `{pi, delta, transition, labels}` fitted parameters. ·
`MmmAssignResult`: `{assignments, avepp, aveppOverall, counts, nSequences}`.
