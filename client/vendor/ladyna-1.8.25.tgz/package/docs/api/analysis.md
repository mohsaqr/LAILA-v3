# ladyna/analysis — TNA analysis verbs

Analysis functions that operate on a `TNA` (or `GroupTNA`) model: centrality
measures, statistical inference (bootstrap, permutation), reliability and
stability estimation, pruning, community/clique detection, sequence
clustering, group comparison, simulation, Markov-chain analysis and
diagnostics, process maps (DFG), and the three Bayesian verbs
(`certainty`, `bayesCompare`, `entropyBayes`).

> **Not covered here:** the HON/Nestimate pathway family — `buildMogen`,
> `buildHon`, `buildHypa`, `buildHonem`, `pathDependence`,
> `pathwaysHon`/`pathwaysHypa`/`pathwaysMogen` (and their tidy siblings
> `honPathways`/`hypaPathways`/`mogenPathways`), the MCML family
> (`buildMCML` and friends), and the mixture Markov model (`mmm`) — is
> documented in **[docs/api/hon.md](./hon.md)**, along with the
> simplicial-complex and hypergraph topology verbs.
>
> That includes the simplicial pathway pipeline exported from this subpath:
> `buildSimplicialKgrams()` (sequences → pooled k-grams → optional `buildHypa`
> join → an annotated pathway complex), `simplicialEvidence()` (the tidy
> per-pathway table), the `SimplexMeta` channel those two carry, and the
> metadata-aware `plotSimplicial()` options (`colorBy`, `sort`, `range`,
> `layoutStates`, `smoothIters`, `mode`). See
> **[docs/api/topology.md](./topology.md)**.

**R reference.** Unless noted otherwise, functions here match R **`tna`
v1.2.3** to 1e-10 or better (see `tests/*-r-groundtruth.test.ts`). A number
of verbs instead port R **`Nestimate`** functions — each such function says
so explicitly below (`certainty`, `bayesCompare`, `entropyBayes`,
`casedropReliability`, `networkReliability`, `passageTime`,
`markovStability`, `markovOrderTest`, `networkMetrics`, the diagnostics
trio, `clusterCovariates`).

## Import

```js
import { tna, centralities, bootstrapTna, prune } from 'ladyna';
// or the analysis subpath only:
import { centralities, permutationTest } from 'ladyna/analysis';
```

### Availability by subpath

Everything on this page is importable from **`ladyna`** (root) and
**`ladyna/analysis`**, with these exceptions (per the generated matrix in
[exports.md](./exports.md)):

- **Excluded from `ladyna/light`** (the 10 names reserved for the
  WASM-accelerated `tnaw` kernels, listed in `src/light.ts`):
  `bootstrapTna`, `centralities`, `permutationTest`, `estimateCS`,
  `compareWeightMatrices`, `markovOrderTest`, `passageTime`,
  `markovStability`, `casedropReliability`, `reliabilityAnalysis`.
  The pure-TS versions remain available from root, `ladyna/analysis`,
  and `ladyna/full`. Most Markov internals (`extractTuples`, `g2Statistic`,
  `layerDof`, `logLikelihood`, `marginalDistribution`,
  `transitionMatrixFromKgrams`, `withinWPermutation`, `pchisqUpper`,
  `fitMultinom`, `multinomSE`) are likewise root/analysis/full only.
- **Root + `ladyna/analysis` only** (not yet re-exported by light/full):
  `certainty`, `bayesCompare`, `entropyBayes`, `networkMetrics`,
  `clusterFromDistance`, and the aliases `centralityStability`,
  `edgeCaseDropStability`, `modelReliability`.
- **`ladyna/analysis` only:** `stateDistribution`, `invertMatrix`.
- `transitionEntropy` and `chainStructure` are in `ladyna/light` but not
  `ladyna/full`.

**Naming.** Everything here is camelCase; there are no snake_case aliases in
the TNA family (the `build_mcml`-style snake aliases belong to the MCML/HON
family in hon.md). Three descriptive camelCase aliases exist for the
four-concept stability terminology: `centralityStability` = `estimateCS`,
`edgeCaseDropStability` = `casedropReliability`, `modelReliability` =
`reliabilityAnalysis`.

**GroupTNA dispatch.** Verbs typed `TNA | GroupTNA` detect a grouped model
via `isGroupTNA()` and apply themselves per group. Most return a
`Record<groupName, Result>` (`betweennessNetwork`, `prune`, `cliques`,
`communities`, `buildDFG`); `centralities` instead returns one *flattened*
result with a parallel `groups` column. `compareSequences` *requires* a
`GroupTNA`. Everything else takes a single `TNA`.

All examples below were run against `dist/index.js` and show real output.
Shared setup used throughout:

```js
import { tna } from 'ladyna';

const seqs = [
  ['plan', 'discuss', 'execute', 'reflect'],
  ['discuss', 'plan', 'execute', 'execute', 'reflect'],
  ['plan', 'execute', 'reflect', 'discuss'],
  ['discuss', 'execute', 'plan', 'reflect'],
  ['plan', 'plan', 'discuss', 'execute'],
  ['execute', 'reflect', 'plan', 'discuss'],
];
const model = tna(seqs);   // 4 states, labels sorted alphabetically
```

---

## Centralities

### `centralities(model, options?)`

```ts
function centralities(
  model: TNA | GroupTNA,
  options?: {
    loops?: boolean;        // default false — zero the diagonal first
    normalize?: boolean;    // default false — minmax-scale each measure
    measures?: CentralityMeasure[];  // default: all of AVAILABLE_MEASURES
  },
): CentralityResult
```

Node centrality measures, matching R `tna::centralities` (igraph semantics,
`1/weight` distances for path-based measures). Returns
`{ labels, measures }` where `measures` maps each measure name to a
`Float64Array` aligned with `labels`. For a `GroupTNA` the rows of all
groups are concatenated and a `groups: string[]` column identifies each row's
group (one flat result, not a record).

| Option | Default | Meaning |
|---|---|---|
| `measures` | all 10 | Subset of `AVAILABLE_MEASURES` |
| `loops` | `false` | Keep self-loops (diagonal) when `true` |
| `normalize` | `false` | Min-max scale each measure to [0, 1] |

```js
const c = centralities(model, { measures: ['OutStrength', 'Betweenness', 'PageRank'] });
console.log(c.labels);
console.log('OutStrength', Array.from(c.measures.OutStrength).map(v => v.toFixed(4)));
console.log('Betweenness', Array.from(c.measures.Betweenness));
console.log('PageRank', Array.from(c.measures.PageRank).map(v => v.toFixed(4)));
// [ 'discuss', 'execute', 'plan', 'reflect' ]
// OutStrength [ '1.0000', '0.8333', '0.8571', '1.0000' ]
// Betweenness [ 1, 2, 0, 2 ]
// PageRank [ '0.2462', '0.2627', '0.2408', '0.2503' ]
```

### `AVAILABLE_MEASURES`

```ts
const AVAILABLE_MEASURES: CentralityMeasure[] = [
  'OutStrength', 'InStrength', 'ClosenessIn', 'ClosenessOut',
  'Closeness', 'Betweenness', 'BetweennessRSP', 'Diffusion', 'Clustering',
  'PageRank',
];
```

The 10 supported measures, in canonical order.

### `betweennessNetwork(model)`

```ts
function betweennessNetwork(model: TNA | GroupTNA): TNA | Record<string, TNA>
```

Edge-betweenness network: returns a new `TNA` whose weight matrix holds the
edge betweenness of every edge (R `tna::betweenness_network`). GroupTNA in,
record of per-group TNA models out.

```js
const bn = betweennessNetwork(model);
// row for 'discuss' (labels: discuss, execute, plan, reflect):
// [ 0, 3, 1, 0 ]
```

---

## Inference: bootstrap, permutation

### `bootstrapTna(model, options?)`

```ts
function bootstrapTna(model: TNA, options?: BootstrapOptions): BootstrapResult

interface BootstrapOptions {
  iter?: number;                       // default 1000
  level?: number;                      // default 0.05
  method?: 'stability' | 'threshold';  // default 'stability'
  threshold?: number;                  // 'threshold' method cutoff; default = 10th percentile of weights
  consistencyRange?: [number, number]; // default [0.75, 1.25]
  seed?: number;                       // default 42
}
```

Case-resampling bootstrap of edge weights (R `tna::bootstrap`). The model
must carry its sequence data (`model.data`). Each `BootstrapEdge` reports the
observed `weight`, `bootstrapMean`, `bias`, a `pValue`, the significance
flag, the consistency range (`crLower`/`crUpper` = weight × range) and the
percentile CI (`ciLower`/`ciUpper`). `result.model` is the model with
non-significant edges zeroed.

```js
const bs = bootstrapTna(model, { iter: 200, seed: 42 });
bs.edges.find(e => e.from === 'plan' && e.to === 'discuss');
// {
//  from: 'plan', to: 'discuss',
//  weight: 0.42857142857142855,
//  bootstrapMean: 0.4357431457431462,
//  bias: 0.007171717171717662,
//  pValue: 0.5223880597014925,
//  significant: false,
//  crLower: 0.3214285714285714, crUpper: 0.5357142857142857,
//  ciLower: 0.14285714285714285, ciUpper: 0.7142857142857143
// }
```

### `bootstrapWtna(input, options?)`

```ts
function bootstrapWtna(input: BootstrapWtnaInput, options?: BootstrapOptions): BootstrapResult

interface BootstrapWtnaInput {
  originalModel: TNA;
  records: Record<string, string | number>[];
  codes: string[];
  wtnaOpts: WtnaOptions;
  modelType: 'tna' | 'ftna';
  scaling: string | null | '';
}
```

Same bootstrap for a window-based (WTNA) model: resamples one-hot *rows*,
rebuilds the windowed transition matrix each iteration. Same options and
result shape as `bootstrapTna`.

### `permutationTest(x, y, options?)`

```ts
function permutationTest(x: TNA, y: TNA, options?: PermutationOptions): PermutationResult

interface PermutationOptions {
  measures?: string[];    // centralities to permute too (R `measures=`); omit to skip
  iter?: number;          // default 1000
  adjust?: PAdjustMethod; // default 'none'
  level?: number;         // default 0.05
  seed?: number;          // default 42
  paired?: boolean;       // default false
}
```

Permutation test comparing two TNA models built from sequence data
(R `tna::permutation_test`). Both models need `model.data` and identical
labels. Returns per-edge stats (`edgeStats: { from, to, diffTrue,
effectSize, pValue }[]`), flat `diffTrue`/`diffSig`/`pValues` arrays, and —
only when `measures` was supplied — a `centralities` block mirroring R's
`$centralities` (state varying fastest).

```js
const pt = permutationTest(x, y, { iter: 1000, seed: 42 }); // x, y: two 6-sequence models
[...pt.edgeStats].sort((a, b) => a.pValue - b.pValue)[0];
// { from: 'discuss', to: 'execute', diffTrue: 0.75,
//   effectSize: 2.2699372610583763, pValue: 0.03396603396603397 }
```

### `permutationTestWtna(inputX, inputY, modelX, modelY, options?)`

```ts
function permutationTestWtna(
  inputX: PermutationWtnaInput,
  inputY: PermutationWtnaInput,
  modelX: TNA,
  modelY: TNA,
  options?: PermutationOptions,
): PermutationResult
```

WTNA variant: pools the windowed groups from both inputs, randomly
re-partitions each iteration and rebuilds the two WTNA matrices.
`PermutationWtnaInput` = `{ records, codes, wtnaOpts, modelType, scaling }`.

---

## Reliability & stability

ladyna distinguishes four concepts (see `R-EQUIVALENCE-FIXES.md`):
**bootstrap** (above), **centrality stability** (`estimateCS`), **edge
case-drop stability** (`casedropReliability`), and **model reliability**
(`reliabilityAnalysis` / `networkReliability`).

### `estimateCS(model, options?)` — alias `centralityStability`

```ts
function estimateCS(model: TNA, options?: StabilityOptions): StabilityResult

interface StabilityOptions {
  measures?: CentralityMeasure[]; // default ['InStrength','OutStrength','Betweenness']
  iter?: number;                  // default 500
  dropProps?: number[];           // default [0.1 … 0.9]
  threshold?: number;             // default 0.7  (correlation threshold)
  certainty?: number;             // default 0.95 (proportion of iterations above threshold)
  seed?: number;                  // default 42
  corrMethod?: 'pearson' | 'spearman' | 'kendall'; // default 'pearson'
  loops?: boolean;                // default false — zero diagonal before centralities
  replayIndices?: Record<number, number[][]>;      // deterministic R-parity replay
}
```

Centrality stability via case-dropping bootstrap (R `tna::estimate_cs`, with
Nestimate-parity extensions: `kendall`, raw `correlations` matrices, and a
`summary` frame). The CS coefficient per measure is the largest drop
proportion at which the correlation with the full-sample centralities stays
≥ `threshold` in ≥ `certainty` of iterations.

```js
const big = tna(simulate(model, { n: 100, seqLength: 12, seed: 7 }));
const cs = estimateCS(big, { iter: 100, seed: 42 });
cs.csCoefficients;
// { InStrength: 0.5, OutStrength: 0.9, Betweenness: 0.4 }
```

### `estimateCsWtna(input, originalModel, options?)`

```ts
function estimateCsWtna(
  input: StabilityWtnaInput,     // { records, codes, wtnaOpts, modelType, scaling }
  originalModel: TNA,
  options?: StabilityOptions,
): StabilityResult
```

Centrality stability for WTNA models (row-level case dropping). Same options
and result as `estimateCS`.

### `casedropReliability(model, options?)` — alias `edgeCaseDropStability`

```ts
function casedropReliability(
  model: TNA,
  options?: CasedropReliabilityOptions,
): CasedropReliabilityResult

interface CasedropReliabilityOptions {
  iter?: number;          // default 500
  dropProps?: number[];   // default [0.1 … 0.9]
  threshold?: number;     // default 0.7
  certainty?: number;     // default 0.95
  method?: 'spearman' | 'pearson' | 'kendall'; // default 'spearman' (Nestimate)
  includeDiag?: boolean;  // default false — exclude self-loops from the edge vector
  seed?: number;          // default 42
  replayIndices?: Record<number, number[][]>;
}
```

Edge-weight case-drop stability — port of R
**`Nestimate::casedrop_reliability`**. Four model-level metrics per
iteration × drop proportion (`mean_abs_dev`, `median_abs_dev`,
`correlation`, `max_abs_dev`), a per-drop summary frame (mean, sd, median,
mad, q025, q975 per metric) and a CS coefficient
(`cs = max dropProp where mean(corr ≥ threshold) ≥ certainty`, else 0).
Note the default correlation method is **spearman**, unlike `estimateCS`.

### `estimateEdgeStability(model, options?)` *(deprecated)*

```ts
function estimateEdgeStability(model: TNA, options?: StabilityOptions): EdgeStabilityResult
```

Legacy thin projection over `casedropReliability` (kept for Desktop
callers; uses `includeDiag: true` and a pearson default). Returns
`{ meanCorrelations, csCoefficient, dropProps, threshold, certainty }`.
Prefer `casedropReliability`.

### `estimateNetworkStability(model, options?)`

```ts
function estimateNetworkStability(model: TNA, options?: StabilityOptions): NetworkStabilityResult
```

Case-dropping stability of *global* metrics: tracks density and mean edge
weight across subsamples; returns per-drop correlation vectors and a CS
coefficient for each (`densityCS`, `meanWeightCS`).

### `reliabilityAnalysis(sequenceData, modelType, opts?)` — alias `modelReliability`

```ts
function reliabilityAnalysis(
  sequenceData: SequenceData,
  modelType: 'tna' | 'ftna' | 'ctna' | 'atna',
  opts?: {
    iter?: number;            // default 100
    split?: number;           // default 0.5
    atnaBeta?: number;        // default 0.1 (atna only)
    seed?: number;            // default 42
    scaling?: string;
    addStartState?: boolean;  startStateLabel?: string;
    addEndState?: boolean;    endStateLabel?: string;
  },
): ReliabilityResult
```

Split-half whole-model reliability: repeatedly splits the sequences in two,
builds a model per half, and compares the weight matrices with all
**22 metrics** of `RELIABILITY_METRICS`. Needs ≥ 4 sequences (≥ 2 per
half). `iterations` is keyed by metric key (`'pearson'`, `'rmsd'`, …);
`summary` rows carry the display label in `metric`.

```js
const rel = reliabilityAnalysis(seqs, 'tna', { iter: 50, seed: 42 });
rel.summary.slice(0, 3).map(r => ({ metric: r.metric, mean: +r.mean.toFixed(4), sd: +r.sd.toFixed(4) }));
// [ { metric: 'Mean Abs. Diff.',   mean: 0.2819, sd: 0.0567 },
//   { metric: 'Median Abs. Diff.', mean: 0.2575, sd: 0.0374 },
//   { metric: 'RMS Diff.',         mean: 0.3908, sd: 0.0856 } ]
```

### `networkReliability(models, options?)`

```ts
function networkReliability(
  models: TNA | TNA[] | Record<string, TNA>,
  options?: NetworkReliabilityOptions,
): NetworkReliabilityResult

interface NetworkReliabilityOptions {
  iter?: number;             // default 1000 (must be >= 2)
  split?: number;            // default 0.5, in (0, 1)
  scale?: ReliabilityScale;  // 'none' | 'minmax' | 'standardize' | 'proportion'; default 'none'
  seed?: number;             // default 42
  replayIndices?: number[][] | Record<string, number[][]>;
}
```

Split-half reliability across one or several models at once — port of R
**`Nestimate::network_reliability`**. Returns 4 metrics per iteration
(`mean_dev`, `median_dev`, `cor`, `max_dev`) plus a mean/sd summary row per
model × metric. `reliabilityAnalysis` is the 22-metric superset for a single
dataset.

### `compareWeightMatrices(a, b)`

```ts
function compareWeightMatrices(a: TNA, b: TNA): Record<string, number>
```

The 22-metric comparison kernel used by `reliabilityAnalysis` and
`compareModels`: deviations (mad, median_ad, rmsd, max_ad, rel_mad,
cv_ratio), correlations (pearson, spearman, kendall, dcor), dissimilarities
(euclidean, manhattan, canberra, braycurtis, frobenius), similarities
(cosine, jaccard, dice, overlap, rv), and pattern agreement (rank_agree,
sign_agree). Vector-level metrics operate on the full n×n matrix flattened
column-major, matching R `as.vector()`.

### `RELIABILITY_METRICS`

```ts
const RELIABILITY_METRICS: MetricDef[]  // 22 × { key, label, category }
```

Metric catalogue (categories: Deviations, Correlations, Dissimilarities,
Similarities, Pattern) in the canonical order used by every reliability
result.

---

## Pruning

### `prune(model, thresholdOrOptions?)`

```ts
function prune(model: GroupTNA, thresholdOrOptions?: number | PruneOptions): Record<string, TNA>;
function prune(model: TNA, thresholdOrOptions?: number | PruneOptions): TNA;

interface PruneOptions {
  method?: 'threshold' | 'lowest' | 'disparity'; // default 'threshold'
  threshold?: number;  // default 0.1  ('threshold' method)
  lowest?: number;     // default 0.05 ('lowest' method: proportion of non-zero edges to cut)
  alpha?: number;      // default 0.5  ('disparity' significance level)
  level?: number;      // alias for alpha — R's spelling
}
```

Prune edges — R `tna::prune`. Typed overloads: a `GroupTNA` returns a
`Record<groupName, TNA>`, a `TNA` returns a `TNA`. A bare number is
shorthand for `{ method: 'threshold', threshold: n }`. The `threshold` and
`lowest` methods remove candidate edges **one at a time** and keep any edge
whose removal would disconnect the graph (R's weak-connectivity guard).
An unknown method throws.

```js
const pruned = prune(model, { method: 'threshold', threshold: 0.2 });
// edges before: 11, after: 7
```

### `pruneDisparity(model, alpha = 0.5)`

```ts
function pruneDisparity(model: TNA, alpha = 0.5): TNA
```

Disparity-filter backbone (Serrano et al. 2009) at significance `alpha` —
what `prune({ method: 'disparity' })` delegates to. Keeps an edge when
`min(outP, inP) < alpha` (see `R-EQUIVALENCE-FIXES.md`).

---

## Communities & cliques

### `communities(model, options?)`

```ts
function communities(
  model: TNA | GroupTNA,
  options?: { methods?: CommunityMethod | CommunityMethod[] }, // default ['leading_eigen']
): CommunityResult | Record<string, CommunityResult>
```

Community detection on the symmetrized network (igraph `mode = "plus"`:
`A[i,j] + A[j,i]`, diagonal doubled), matching R `tna::communities`.
Returns `{ counts, assignments, labels }` where `assignments[method]` is a
0-based membership vector per requested method.

```js
const comm = communities(model, { methods: ['louvain', 'leading_eigen'] });
// assignments: { louvain: [0,1,0,0], leading_eigen: [1,0,0,1] }
// counts:      { louvain: 2, leading_eigen: 2 }
```

### `AVAILABLE_METHODS`

```ts
const AVAILABLE_METHODS: CommunityMethod[] = [
  'fast_greedy', 'louvain', 'label_prop',
  'leading_eigen', 'edge_betweenness', 'walktrap',
];
```

### `cliques(model, options?)`

```ts
function cliques(
  model: TNA | GroupTNA,
  options?: { size?: number; threshold?: number }, // defaults: size 2, threshold 0
): CliqueResult | Record<string, CliqueResult>
```

Directed cliques of `size` k: node sets where every pair has edges in
**both** directions with weight ≥ `threshold` (and > 0), matching R
`tna::cliques`. Returns per-clique sub-matrices, indices, and labels.

```js
const cq = cliques(model, { size: 2, threshold: 0.1 });
// 3 dyads: [["discuss","plan"], ["execute","plan"], ["plan","reflect"]]
```

---

## Sequence clustering

### `clusterData(data, k, options?)`

```ts
function clusterData(
  data: SequenceData | TNAData | number[][],
  k: number,
  options?: {
    dissimilarity?: string;  // string data: 'hamming' (default), 'lv', 'osa', 'dl',
                             //   'lcs', 'qgram', 'cosine', 'jaccard', 'jw'
                             // numeric data: 'euclidean' (default), 'manhattan'
    method?: string;         // 'pam' (default) or a hierarchical linkage
    naSyms?: string[];       // default ['*', '%']
    weighted?: boolean;
    lambda?: number;
  },
): ClusterResult
```

Unified clustering verb. Auto-detects the input: `TNAData` / `string[][]`
use string distance metrics; `number[][]` uses numeric metrics. `method` is
`'pam'` (partitioning around medoids, R `cluster::pam`) or a hierarchical
linkage (`average`, `complete`, `single`, `ward.D`, `ward.D2`, `mcquitty`,
`median`, `centroid`). Returns 1-based `assignments`, `silhouette`, `sizes`,
the `distance` matrix, and — for hierarchical methods — the R
`hclust`-convention `merge`/`heights`/`order`.

```js
const cl = clusterData(seqsX, 2, { dissimilarity: 'hamming', method: 'pam' });
// k=2, sizes=[20, 10], silhouette=0.171, assignments (1-based): [2,1,1,2,1,2,2,1,2,2, …]
```

### `clusterSequences(data, k, options?)` *(deprecated)*

```ts
function clusterSequences(data: SequenceData | TNAData, k, options?): ClusterResult
```

Legacy name; forwards to `clusterData()`.

### `clusterFromDistance(distance, k, options?)`

```ts
function clusterFromDistance(
  distance: number[][] | Matrix,
  k: number,
  options?: { method?: string },  // 'pam' (default) or a hierarchical linkage
): { clustering: number[]; k: number; method: string }
```

Cluster a **precomputed** dissimilarity matrix (e.g. from `seqdist()`),
which `clusterData` cannot accept (it treats `number[][]` as raw data).
Returns 1-based labels, as `clusterQuality()` expects.

```js
clusterFromDistance(cl.distance, 3, { method: 'ward.D2' });
// { method: 'ward.D2', clustering: [3,1,3,3,3,2,3,2,3,2, …], k: 3 }
```

### `computeDendrogram(dist, method = 'average')`

```ts
function computeDendrogram(dist: Matrix, method = 'average'):
  { merge: number[][]; heights: number[]; order: number[] }
```

Full hierarchical tree from a distance matrix without cutting — R
`hclust` conventions (negative = leaf, positive = prior merge).

### `findRepresentatives(data, options?)`

```ts
function findRepresentatives(
  data: SequenceData,
  options?: {
    dissimilarity?: string;              // default 'hamming'
    n?: number;                          // number of representatives
    k?: number;                          // optional: per-cluster mode
    criterion?: 'medoid' | 'frequency';  // default 'medoid'
    naSyms?: string[];                   // default ['*', '%']
  },
): RepresentativeResult[]
```

Representative sequences: medoids (minimum total distance) or most-frequent
sequences, overall or per cluster when `k` is given. Each result carries
`{ index, sequence, distance, cluster? }`.

```js
findRepresentatives(seqsX, { n: 2, criterion: 'medoid' })[0];
// { index: 1, sequence: ['plan','execute','reflect','discuss','execute','plan','discuss','execute'],
//   distance: 5.103448275862069 }
```

### `clusterCovariates(assignments, meta, options?)`

```ts
function clusterCovariates(
  assignments: readonly number[],   // 1-indexed cluster per session
  meta: MetaData,                   // from prepareLong()
  options?: ClusterCovariatesOptions,
): ClusterCovariatesResult

interface ClusterCovariatesOptions {
  terms?: string[];        // default: every metadata column except .session_id/.session_nr
  adjust?: PAdjustMethod;  // post-hoc adjustment, default 'holm'
  membership?: boolean;    // also fit the multinomial membership logit, default true
  refCluster?: string;     // reference cluster by name, default first
  level?: number;          // CI level, default 0.05 (95%)
  clusterNames?: string[]; // default 'Cluster 1'…'Cluster k'
}
```

Do the clusters differ on the metadata, and who ends up where? — engine-side
counterpart of R **`Nestimate::build_clusters(covariates = ~ …)`**. The
`profile` block tests each covariate marginally (numeric → ANOVA + eta² +
Kruskal–Wallis; categorical → chi-square + Cramér's V + standardized
residuals, with pairwise post-hoc); the optional `membership` block is one
multinomial logit of membership on all covariates at once (with Firth
fallback under separation — check `membership.seOk` before reporting
SEs/ORs).

### `fitMultinom(X, R, refIdx, beta0?, opts?)` / `multinomSE(X, R, priors, refIdx)`

```ts
function fitMultinom(
  X: number[][], R: number[][], refIdx: number, beta0?: number[][],
  opts?: { maxIter?: number; tol?: number; ridge?: number; firth?: boolean },
): MultinomFit  // { beta, priors, logLik, iterations, converged }

function multinomSE(X, R, priors, refIdx): { se: number[][]; ok: boolean }
```

The weighted multinomial-logit kernel behind `clusterCovariates` (and the
covariate mixture model): responses `R` are *fractional* posteriors, not 0/1
labels. Defaults: `maxIter 100`, `tol 1e-10`, `ridge 1e-9`. `multinomSE`
returns observed-information standard errors (`ok: false` when unusable).

### `solveLinear(A, b)` / `invertMatrix(A)`

```ts
function solveLinear(A: number[][], b: number[]): number[] | null
function invertMatrix(A: number[][]): number[][] | null
```

Gauss–Jordan with partial pivoting; `null` when singular. Numeric helpers
exported for reuse (`invertMatrix` from `ladyna/analysis` only).

---

## Comparison

### `compareSequences(x, options?)`

```ts
function compareSequences(
  x: GroupTNA,           // >= 2 groups, each with sequence data
  options?: {
    sub?: number[];      // subsequence lengths; default [1..min(5, seqLen)]
    minFreq?: number;    // display filter, default 5
    test?: boolean;      // run permutation test, default false
    iter?: number;       // default 1000
    adjust?: 'bonferroni' | 'holm' | 'fdr' | 'BH' | 'none'; // default 'bonferroni'
    seed?: number;       // default 42
  },
): CompareRow[]
```

Compare subsequence patterns across the groups of a `GroupTNA` (R
`tna::compare_sequences`). Each row is one pattern with per-group
`frequencies`, `proportions`, standardized **adjusted** residuals
(`chisq.test()$stdres`, ~N(0,1) under independence), and — when
`test: true` — a permutation `effectSize` and `pValue`. Proportions,
residuals, and the test are all computed on the complete table *before* the
`minFreq` display filter. To compare one pair out of K > 2 groups, pass a
GroupTNA containing just those two models.

```js
const g = groupTna(allSeqs, groupVector);  // 'A' × 30, 'B' × 30
const rows = compareSequences(g, { sub: [2], minFreq: 10, test: true, iter: 500, seed: 42 });
rows[0];
// { pattern: 'discuss->execute',
//   frequencies: { A: 30, B: 42 }, proportions: { A: 0.1429, B: 0.2 },
//   residuals: { A: -1.5536, B: 1.5536 }, effectSize: 2.4775, pValue: 0.4172 }
```

### `compareModels(a, b)`

```ts
function compareModels(a: TNA, b: TNA): Record<string, number>
```

Compare two models with the 22 reliability metrics — a first-class wrapper
around `compareWeightMatrices`.

```js
const cm = compareModels(tna(seqsX), tna(seqsY));
// 22 keys; e.g. pearson = 0.9629, rmsd = 0.069
```

### `stdResiduals(counts)`

```ts
function stdResiduals(counts: number[][]): number[][]
```

Standardized **adjusted** residuals of a contingency table — R
`chisq.test()$stdres`: `(o − e) / sqrt(e (1 − r/N)(1 − c/N))`, not the
(too-small) Pearson residual.

---

## Simulation

### `simulate(model, options?)`

```ts
function simulate(model: TNA, options?: SimulateOptions): SequenceData

interface SimulateOptions {
  n?: number;                        // default 50
  seqLength?: number | [number, number]; // fixed or [min, max]; default 20
  seed?: number;                     // default 42
}
```

Generate sequences by walking the Markov chain: initial states sampled from
`model.inits`, transitions from the rows of `model.weights`. Deterministic
under `seed` (xoshiro128** `SeededRNG`).

```js
simulate(model, { n: 3, seqLength: 5, seed: 1 });
// [ [ 'discuss', 'plan', 'discuss', 'plan', 'reflect' ],
//   [ 'discuss', 'execute', 'plan', 'discuss', 'execute' ],
//   [ 'plan', 'discuss', 'plan', 'discuss', 'plan' ] ]
```

---

## WTNA (window-based TNA)

### `buildWtnaMatrix(records, codes, opts?)`

```ts
function buildWtnaMatrix(
  records: Record<string, string | number>[],  // one-hot rows + optional actor/session columns
  codes: string[],                             // binary state column names
  opts?: WtnaOptions,
): WtnaResult   // { matrix, withinMatrix, labels }

interface WtnaOptions {
  actor?: string;      // grouping column — each actor is an independent stream (R actor=)
  session?: string;    // variable-size windowing column (R session=)
  windowSize?: number; // fixed window size, default 3 (R interval=)
  windowType?: 'tumbling' | 'sliding';  // default 'tumbling'
  type?: 'frequency' | 'relative';      // default 'frequency'
}
```

Window-based transition matrix from one-hot event records — port of R
`wtna()`. `matrix[i][j]` counts state *i* in window *t* leading to state *j*
in window *t + 1* (row-normalized when `type: 'relative'`);
`withinMatrix` counts co-occurrence within the same window.

```js
const w = buildWtnaMatrix(records, ['A', 'B', 'C'],
  { actor: 'actor', windowSize: 3, type: 'relative' });
// labels: [ 'A', 'B', 'C' ]
// matrix:  [ [ 0, 0.5, 0.5 ], [ 0, 0.5, 0.5 ], [ 0, 0, 0 ] ]
// within:  [ [ 0, 2, 0 ], [ 2, 0, 2 ], [ 0, 2, 0 ] ]
```

### WTNA building blocks

The pipeline stages `buildWtnaMatrix` composes, exported individually:

```ts
function toBinaryMatrix(records, codes): number[][]        // records → n × k 0/1 matrix
function applyWindowing(X, windowSize, windowType): number[][]      // fixed-size windows
function applyIntervalWindowing(X, labels): number[][]     // one window per session label
function computeWtnaTransitions(W): number[][]             // window t → t+1 counts
function computeWithinWindow(W): number[][]                // within-window co-occurrence
function rowNormalizeWtna(M): number[][]                   // counts → row proportions
```

---

## Markov chain & diagnostics

### `passageTime(x, options?)`

```ts
function passageTime(x: MarkovInput, options?: PassageTimeOptions): PassageTimeResult
// MarkovInput = TNA | Matrix | number[][]
// options: { states?: string[]; normalize?: boolean /* default true */ }
```

Mean first-passage times via the Kemeny–Snell fundamental matrix
`Z = (I − P + 1·piT)^-1`, `M[i,j] = (Z[j,j] − Z[i,j]) / pi[j]`, diagonal
`1/pi_i` — port of R **`Nestimate::passage_time`**. Matrix/array inputs get
labels `S1…Sn`. Returns `{ matrix, stationary, persistence, states }`.

```js
const pt = passageTime(big);   // big = tna(simulate(model, {n:100, seqLength:12, seed:7}))
// MFPT row 'discuss': [ 4.501, 1.655, 3.552, 3.222 ]
// pi: [ 0.2222, 0.2861, 0.2582, 0.2335 ]
```

### `markovStability(x, options?)`

```ts
function markovStability(x: MarkovInput, options?: { normalize?: boolean }): MarkovStabilityResult
```

Per-state stability profile — port of R **`Nestimate::markov_stability`**.
One row per state: `persistence` (P_ii), `stationaryProb`, `returnTime`,
`sojournTime`, `avgTimeToOthers`, `avgTimeFromOthers`; plus the underlying
`mpt` passage-time object.

```js
markovStability(big).stability[0];
// { state: 'discuss', persistence: 0, stationaryProb: 0.2222, returnTime: 4.5009,
//   sojournTime: 1, avgTimeToOthers: 2.8097, avgTimeFromOthers: 3.0221 }
```

### `markovOrderTest(data, options?)`

```ts
function markovOrderTest(data: MarkovOrderInput, options?: MarkovOrderOptions): MarkovOrderResult
// MarkovOrderInput = string[][] | SequenceData | TNA (needs model.data)

interface MarkovOrderOptions {
  maxOrder?: number;  // default 3
  nPerm?: number;     // default 500 (within-w permutations per order)
  alpha?: number;     // default 0.05
  seed?: number;      // default 42
  replay?: MarkovOrderReplay;  // bitwise-exact external permutation replay
}
```

Which Markov order does the data support? — port of R
**`Nestimate::markov_order_test`**: sequential G² likelihood-ratio tests
between order k−1 and k with a within-context permutation null, plus
AIC/BIC selection. `testTable` has one row per order 0…maxOrder;
`optimalOrder` is the highest order whose permutation test is significant.

```js
const seqs100 = simulate(model, { n: 100, seqLength: 12, seed: 7 });
const mot = markovOrderTest(seqs100, { maxOrder: 2, nPerm: 200, seed: 42 });
// optimalOrder: 1, bicOrder: 1, aicOrder: 1
// [ { order: 0, loglik: -1655.36, BIC: 3331.99, pPerm: NaN },
//   { order: 1, loglik: -1098.67, BIC: 2268.25, pPerm: 0.005 },
//   { order: 2, loglik: -1092.69, BIC: 2412.27, pPerm: 0.6965 } ]
```

### Markov-order building blocks

Deterministic internals of the order test, exported for replay/verification:

```ts
function extractTrajectories(data: MarkovOrderInput): string[][]  // coerce + drop len<2
function kgramCounts(trajectories, k, options?: KgramCountsOptions): KgramCounts  // k-gram node/edge counts
function transitionMatrixFromKgrams(nodes, edges, options?: TransitionMatrixOptions): Matrix  // row-stochastic k-gram matrix
function layerDof(mat: Matrix): number                            // sum over rows of max(nonzero−1, 0)
function marginalDistribution(trajectories): { states; probs }    // order-0 marginal
function logLikelihood(trajectories, k, transMats, transNodes): number
function extractTuples(trajectories, k): Tuples                   // (x, w, s) tuples per context
function g2Statistic(tuples): { stat: number; df: number }        // aggregated G²
function withinWPermutation(tuples, nPerm, rng, replayFlatIndices?): number[]  // null G² draws
function pchisqUpper(q: number, df: number): number               // upper-tail chi-square probability
```

#### `KgramExplosionError` — the typed overflow guard

```ts
class KgramExplosionError extends Error {
  readonly name: 'KgramExplosionError';
  readonly order: number | undefined;   // the k that blew up
  readonly projected: number;           // distinct k-grams / matrix side length
  readonly limit: number;               // the bound that was exceeded
  readonly stage: 'counts' | 'matrix';  // which safeguard tripped
}
```

The k-gram state space grows exponentially in `k`, and an over-ambitious
`maxOrder` used to surface as V8's opaque `"Array buffer allocation failed"`
(or simply exhaust memory) somewhere deep inside `buildMogen` / `buildHon` /
`buildHypa`. Both k-gram safeguards now throw this typed subclass instead, so
a consumer can `catch (e) { if (e instanceof KgramExplosionError) … }` and
tell the user to lower the order rather than reporting a generic crash.

| Stage | Where | Default bound | Raise it with |
|---|---|---|---|
| `'counts'` | `kgramCounts()` — distinct k-grams retained | 2,000,000 | `kgramCounts(traj, k, { maxStates })` |
| `'matrix'` | `transitionMatrixFromKgrams()` — dense n×n side length | 5,800 (≈257 MiB) | `transitionMatrixFromKgrams(nodes, edges, { maxNodes })` |

Both bounds are deliberately generous: nothing that fits in memory trips
them, so no existing workload changes behaviour. The `'matrix'` message is
byte-identical to the plain `Error` it replaces. `KgramExplosionError` is
exported everywhere `kgramCounts` is (`ladyna`, `ladyna/analysis`, `ladyna/light`,
`ladyna/full`).

```js
try {
  buildMogen(trajectories, { maxOrder: 12 });
} catch (e) {
  if (e instanceof KgramExplosionError) {
    console.warn(`order ${e.order} needs ${e.projected} states (limit ${e.limit})`);
  }
}
```

### `transitionEntropy(x, options?)`

```ts
function transitionEntropy(
  x: DiagnosticsInput,   // Matrix | number[][] | TNA
  options?: { base?: number /* default 2 */; normalize?: boolean /* default true */ },
): TransitionEntropy
```

Shannon diagnostics of a chain — port of R **`Nestimate::transition_entropy`**:
per-state row entropies, stationary distribution, entropy rate
`h(P) = sum_i pi_i H(P_i.)`, redundancy `H(pi) − h(P)`, and normalised
forms.

```js
const te = transitionEntropy(x);   // x = tna(simulate(model, {n:60, seqLength:10, seed:7}))
// entropyRate: 1.2562, redundancy: 0.7378,
// rowEntropy: [ 0.8648, 1.205, 1.8669, 0.9956 ]
```

### `chainStructure(x, options?)`

```ts
function chainStructure(
  x: DiagnosticsInput,
  options?: { normalize?: boolean /* default true */; tol?: number /* default 1e-10 */ },
): ChainStructure
```

Qualitative shape of the chain — port of R **`Nestimate::chain_structure`**:
state classification (absorbing/recurrent/transient), communicating classes
(SCCs), periods, irreducibility/aperiodicity/regularity/reversibility,
hitting probabilities, and absorption analysis (`N = (I − Q)^-1`).

```js
const cs = chainStructure(x);
// isIrreducible: true, isAperiodic: true,
// classification: [ 'recurrent', 'recurrent', 'recurrent', 'recurrent' ]
```

### `stateDistribution(x)`

```ts
function stateDistribution(x: DiagnosticsInput): { state: string; proportion: number }[]
```

Column-marginal distribution `colSums(W) / sum(W)` — R
`Nestimate::state_distribution`. (`ladyna/analysis` subpath only.)

```js
stateDistribution(x);
// [ { state: 'discuss', proportion: 0.2174 }, { state: 'execute', proportion: 0.2904 },
//   { state: 'plan', proportion: 0.2744 },   { state: 'reflect', proportion: 0.2178 } ]
```

---

## DFG (process map)

### `buildDFG(model, options?)`

```ts
function buildDFG(
  model: TNA | GroupTNA,
  options?: { startLabel?: string; endLabel?: string },
): DFGResult | Record<string, DFGResult>
```

Directly-follows graph for process maps. Uses `model.data` when available
(accurate per-case metrics), else falls back to the weight matrix. Nodes
and edges carry all three metric modes at once: `absolute` counts,
`relative` proportions, and `case` fractions (share of cases containing the
activity/transition). GroupTNA in, record out.

**`startLabel` / `endLabel` TAG an already-present label — they never inject
one.** They are read only to decide a node's `type`: a node whose id equals
`startLabel` is typed `'start'`, one equal to `endLabel` is typed `'end'`,
everything else is `'activity'`. If the sequences do not already contain
that label, nothing is added and nothing changes — no boundary node appears.
To actually *add* Start/End nodes, either inject them into the sequences
first with [`injectSentinels`](./processmining.md#injectsentinelsinput-startlabel-endlabel--eventlog),
or use [`processMap(log, { sentinels: true })`](./processmining.md#processmapinput-options--processmap--recordstring-processmap),
which injects and tags in one step.

```js
const dfg = buildDFG(model);
dfg.nodes[0]; // { id: 'discuss', type: 'activity', absoluteFreq: 6, relativeFreq: 0.24, caseFreq: 1 }
dfg.edges[0]; // { from: 'plan', to: 'discuss', absoluteCount: 3,
              //   relativeCount: 0.15789473684210525, caseCount: 0.5 }
dfg.totalTransitions; // 19
```

### `buildDFGFromSequences(sequences, labels?, startLabel?, endLabel?)`

```ts
function buildDFGFromSequences(
  sequences: SequenceData,
  labels?: string[],
  startLabel?: string,
  endLabel?: string,
): DFGResult
```

Same computation directly from raw sequences, without building a model
first.

---

## Descriptives

### `networkMetrics(weights, options?)`

```ts
function networkMetrics(weights: Matrix, options?: { directed?: boolean }): NetworkMetric[]
```

The 13 whole-network descriptives — port of R
**`Nestimate:::.summary_metrics_from_weights`** (the `$network_metrics`
block of `compare_model()`). `directed` defaults to auto-detection
(asymmetric implies directed). Deliberately reproduces R's counter-intuitive
conventions: In-Strength is `rowSums(|W|)` / Out-Strength `colSums(|W|)`
(swapped, mirroring tna's labelling), the diagonal counts toward edge count
and density, and mean distance uses the weights directly as distances.

```js
networkMetrics(model.weights).map(m => m.metric + '=' + +m.value.toFixed(4)).join(', ');
// Node Count=4, Edge Count=11, Network Density=0.9167, Mean Distance=0.4077,
// Mean Out-Strength=1, SD Out-Strength=0.1692, Mean In-Strength=1, SD In-Strength=0,
// Mean Out-Degree=2.75, SD Out-Degree=0.9574, Centralization (Out-Degree)=0.3333,
// Centralization (In-Degree)=0.3333, Reciprocity=0.6667
```

---

## Lite descriptives (dynajs lineage)

Five simple verbs ported verbatim from the retired **`dynajs`** ("Lite TNA")
fork during the 2026-08-22 name consolidation, so its ten consumer apps keep
byte-identical numbers. They carry **no R-parity contract** — the reference is
the dynajs source. Note the deliberate contrasts with their R-parity cousins:
`networkDensity` excludes the diagonal by default (the Nestimate-parity
density inside `networkMetrics()` counts it), and `detectCommunities` returns
a flat Louvain assignment vector (the R-tna-parity `communities()` returns
per-method records).

### `networkDensity(model, options?)`

```ts
function networkDensity(model: TNA, options?: { loops?: boolean }): number
```

Fraction of possible directed edges with weight > 0. `loops` (default
`false`) counts the diagonal in both numerator and denominator. For
undirected model types (`co-occurrence`, `attention`) each edge is counted
once.

```js
networkDensity(model);                  // 0.6666666666666666
networkDensity(model, { loops: true }); // 0.625
```

### `degreeDistribution(model, options?)`

```ts
function degreeDistribution(model: TNA, options?: { loops?: boolean }): DegreeDistribution
// DegreeDistribution = { inDegree, outDegree, totalDegree: Float64Array; labels: string[] }
```

Unweighted in/out/total degree per node (edge = weight > 0), index-aligned
with `labels`.

```js
const d = degreeDistribution(model);
[...d.outDegree]; // [2, 2, 1, 3]  (discuss, execute, plan, review)
```

### `detectCommunities(model, options?)`

```ts
function detectCommunities(model: TNA, options?: { resolution?: number }): DetectedCommunities
// DetectedCommunities = { labels: string[]; assignments: number[]; modularity: number; nCommunities: number }
```

Directed weighted Louvain with a resolution (gamma) knob — higher fragments
into more communities. Deterministic (sequential node sweep, no RNG).

```js
detectCommunities(model);
// { labels: ['discuss','execute','plan','review'], assignments: [0,1,0,1],
//   modularity: 0.0083, nCommunities: 2 }
```

### `stateCounts(data)` / `statePresence(data)`

```ts
function stateCounts(data: SequenceData): Record<string, number>
function statePresence(data: SequenceData): Record<string, number>
```

`stateCounts` totals occurrences of each state across all sequences;
`statePresence` counts how many sequences contain each state at least once.
Both ignore `null`/`undefined`/`''` and sort keys by state name.
(`stateCounts` was dynajs's `stateFrequencies` — renamed because ladyna's
`stateFrequencies` is the Nestimate-parity tidy-row verb.)

```js
stateCounts(seqs);   // { discuss: 7, execute: 6, plan: 7, review: 6 }
statePresence(seqs); // { discuss: 5, execute: 5, plan: 4, review: 5 }
```

---

## Bayesian: certainty, bayesCompare, entropyBayes

All three port R **`Nestimate`** verbs (`certainty`, `bayes_compare`,
`entropy_bayes`) and require a model built from sequence data (they read
`model.counts`) with **no scaling** applied.

### `certainty(model, options?)`

```ts
function certainty(model: TNA, options?: CertaintyOptions): CertaintyResult

interface CertaintyOptions {
  prior?: number;              // Dirichlet concentration per cell; default 0.5 (Jeffreys)
  ciLevel?: number;            // tail mass for CI and stability cutoff; default 0.05
  inference?: 'stability' | 'threshold';  // default 'stability'
  consistencyRange?: [number, number];    // band around observed weight; default [0.75, 1.25]
  edgeThreshold?: number;      // 'threshold' cutoff; default = 10th percentile of non-zero weights
}
```

Analytic Bayesian edge intervals — port of R **`Nestimate::certainty`**.
Entirely closed form (no Monte Carlo, no RNG): each row is
Dirichlet(counts + prior), so each edge is marginally Beta and its CI,
p-value, and stability flag come from the incomplete-beta function.

```js
const ct = certainty(big, { prior: 0.5 });   // big: 100 simulated sequences
ct.edges.find(e => e.from === 'plan' && e.to === 'discuss');
// { from: 'plan', to: 'discuss', count: 120, weight: 0.3947, mean: 0.3938, sd: 0.0279,
//   ciLower: 0.3398, ciUpper: 0.4491, crLower: 0.2961, crUpper: 0.4934,
//   pValue: 0.0004, stable: true }
```

### `bayesCompare(x, y, options?)`

```ts
function bayesCompare(x: TNA, y: TNA, options?: BayesCompareOptions): BayesCompareResult

interface BayesCompareOptions {
  prior?: number;          // default 0.5
  draws?: number;          // Monte-Carlo draws; default 10000
  ci?: number;             // credible mass; default 0.95
  meanThreshold?: number;  // practical-significance floor on |diff|; default 0.01
  boundThreshold?: number; // floor on the CI bound nearest zero; default 0.001
  seed?: number;
  betaDrawsX?: number[][]; // R-replay hooks (column-major, one row per edge)
  betaDrawsY?: number[][];
}
```

Dirichlet–Multinomial comparison of two models sharing the same labels —
port of R **`Nestimate::bayes_compare`**. Despite the name there is **no
Bayes factor**: each edge gets a posterior mean difference, an equal-tailed
quantile credible interval, and a probability of direction; the thresholds
are a practical-significance gate, and adjustment is hard-coded `"none"` as
in R. `edges` is all n² cells; `summary` keeps cells observed on either
side. The gamma sampler differs from R's `rbeta`, so seeds cannot reproduce
R draws — use `betaDrawsX`/`betaDrawsY` for estimator-level parity.

```js
const bc = bayesCompare(x, y, { draws: 4000, seed: 42 });  // x, y: 60 sequences each
bc.global;      // { groupX: 'x', groupY: 'y', nCredible: 0 }
bc.summary[0];
// { from: 'discuss', to: 'execute', countX: 82, countY: 95, probX: 0.7051, probY: 0.7346,
//   diff: -0.0295, ciLower: -0.1405, ciUpper: 0.0842, ciWidth: 0.2247,
//   pDifference: 0.691, pValue: 0.618, effectSize: -0.5104, significant: false }
```

### `entropyBayes(model, options?)`

```ts
function entropyBayes(model: TNA, options?: EntropyBayesOptions): EntropyBayesResult

interface EntropyBayesOptions {
  prior?: number;      // default 0.5
  draws?: number;      // default 4000
  ci?: number;         // default 0.95
  minShare?: number;   // edge credibility floor on entropy-rate share; default 0.01
  base?: number;       // log base; default 2
  seed?: number;
  gammaDraws?: number[][];  // R-replay hook (n*n rows × draws, column-major)
}
```

Posterior uncertainty for the chain's entropy — port of R
**`Nestimate::entropy_bayes`**. Per posterior draw it computes the entropy
rate, stationary entropy, and redundancy (`summary`), per-state row
entropies and stationary mass (`states`), and per-edge contributions with a
credibility flag (`edges`, sorted by contribution). `network` is the
posterior-mean contribution matrix; `model` is the same matrix pruned to
credible edges (R `$model`).

```js
const eb = entropyBayes(x, { draws: 2000, seed: 42 });
eb.summary;
// [ { quantity: 'entropy_rate',       mean: 1.2866, sd: 0.0387, ciLower: 1.2104, ciUpper: 1.3613 },
//   { quantity: 'stationary_entropy', mean: 1.9924, sd: 0.0036, ciLower: 1.9838, ciUpper: 1.9979 },
//   { quantity: 'redundancy',         mean: 0.7057, sd: 0.0403, ciLower: 0.6268, ciUpper: 0.7837 } ]
eb.edges[0];
// { from: 'plan', to: 'discuss', count: 65, contribution: 0.1393, sd: 0.0084,
//   ciLower: 0.123, ciUpper: 0.1554, share: 0.1083, shareLower: 0.0983,
//   shareUpper: 0.1184, credible: true }
```

---

## Types

One-liners for the exported types (all importable from `ladyna` /
`ladyna/analysis` as `import type`):

- `PruneOptions` — method/threshold/lowest/alpha(+`level` alias) for `prune`.
- `CentralityResult`, `CliqueResult`, `CommunityResult`, `ClusterResult`, `CompareRow` — result shapes (re-exported from `ladyna/core` types).
- `RepresentativeResult` — `{ index, sequence, distance, cluster? }`.
- `MultinomFit` — `{ beta, priors, logLik, iterations, converged }` from `fitMultinom`.
- `WtnaOptions`, `WtnaResult` — WTNA build options / `{ matrix, withinMatrix, labels }`.
- `BootstrapOptions`, `BootstrapEdge`, `BootstrapResult`, `BootstrapWtnaInput` — bootstrap I/O.
- `PermutationOptions`, `EdgeStat`, `PermutationResult`, `PermutationWtnaInput` — permutation I/O.
- `StabilityOptions`, `StabilityResult`, `StabilitySummaryRow`, `StabilityWtnaInput` — centrality stability I/O.
- `EdgeStabilityResult`, `NetworkStabilityResult` — legacy edge/network stability results.
- `CasedropReliabilityOptions`, `CasedropReliabilityResult`, `CasedropReliabilityMetricMatrix`, `CasedropReliabilitySummaryRow` — case-drop stability I/O.
- `MetricDef`, `ReliabilityMetricSummary`, `ReliabilityResult`, `ReliabilityScale` — 22-metric reliability shapes.
- `NetworkReliabilityOptions`, `NetworkReliabilityResult`, `NetworkReliabilityIterations`, `NetworkReliabilitySummaryRow` — `networkReliability` I/O.
- `SimulateOptions` — `{ n, seqLength, seed }`.
- `DFGNode`, `DFGEdge`, `DFGResult`, `DFGOptions` — process-map shapes.
- `MarkovInput`, `PassageTimeOptions`, `PassageTimeResult`, `MarkovStabilityRow`, `MarkovStabilityResult` — passage-time/stability I/O.
- `MarkovOrderInput`, `MarkovOrderOptions`, `MarkovOrderResult`, `MarkovOrderTestRow`, `MarkovOrderReplay` — order-test I/O.
- `DiagnosticsInput`, `TransitionEntropyOptions`, `TransitionEntropy`, `ChainStructureOptions`, `ChainStructure`, `StateClassification` — diagnostics I/O.
- `CertaintyOptions`, `CertaintyEdge`, `CertaintyResult` — `certainty` I/O.
- `BayesCompareOptions`, `BayesCompareEdge`, `BayesCompareResult` — `bayesCompare` I/O.
- `EntropyBayesOptions`, `EntropyBayesQuantity`, `EntropyBayesState`, `EntropyBayesEdge`, `EntropyBayesResult` — `entropyBayes` I/O.
- `NetworkMetric` — `{ metric, value }` row of `networkMetrics`.
- `ClusterCovariatesOptions`, `ClusterCovariatesResult`, `CovariateProfileRow`, `MembershipModel` — `clusterCovariates` I/O.

## Plots (SVG painters)

Four self-contained SVG painters, ported from the d3 figures that had been
re-implemented in every downstream consumer (Dynalytics Desktop views, the
carm-tna notebook, `demo/nestimate-ports.ts`). Each returns a **string** — a
standalone `<svg>` document with `viewBox`, `max-width:100%`, `<title>`
tooltips and no external assets — exactly like `plotNetwork` and
`plotSimplicial`. No d3, no runtime dependency; the scales
(`scaleBand`, `scaleLinear`, `scaleDiverging`), `d3.ticks`, and the
`interpolateRdBu` / `interpolateBlues` ramps are hand-rolled in
`src/analysis/charts.ts`.

Rendering only — there is no R-parity requirement on pixels.

```js
import { tna, centralities, estimateCS, plotMatrix, plotCentralities, plotStability } from 'ladyna';

const model = tna(sequences);
document.body.innerHTML =
    plotMatrix(model.weights, { labels: model.labels, title: 'Transition probabilities' })
  + plotCentralities(centralities(model), { measure: 'Betweenness' })
  + plotStability(estimateCS(model, { iter: 100, seed: 1 }));
```

### plotMatrix(matrix, options?)

Labelled matrix heatmap: one rect per cell, row labels right-aligned on the
left, column labels rotated -40° below the grid, optional in-cell values, and
a colour legend. `matrix` is a `Matrix` or a `number[][]` (ragged input
throws). Non-finite cells paint grey.

The ramp is **sequential blues** by default and **diverging blue-white-red**
(symmetric about 0, positive = red) as soon as any cell is negative — so a
transition matrix and a difference matrix both look right with no extra
argument.

| option | default | meaning |
|---|---|---|
| `labels` | 1-based indices | labels for both axes |
| `rowLabels` / `colLabels` | `labels` | per-axis labels (non-square matrices) |
| `diverging` | auto (`true` if any value < 0) | force the diverging ramp |
| `limit` | max abs / max value | colour clamp; values past it saturate |
| `showValues` | auto (cells > 22px wide) | print the value inside each cell |
| `decimals` | `3` | digits for in-cell values |
| `legend` | `true` | draw the gradient key below the grid |
| `colors` | RdBu / Blues extremes | `[low, mid, high]` diverging, `[low, high]` sequential |
| `width` / `height` | sized from the cell grid (cells 18–36px) | SVG size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

Returns the SVG string. Throws on an empty or ragged matrix, or on a label
count that does not match the matrix.

`MatrixPlotOptions` is the exported option type.

### plotCentralities(result, options?)

Horizontal bar chart of one centrality measure, sorted descending, `rx=4`
corners, value labels to the right of each bar and the measure name as a bold
caption. Input is a `CentralityResult` (from `centralities()`).

Pass `measures` instead of `measure` to get a small-multiples grid — one panel
per measure, `columns` panels per row.

| option | default | meaning |
|---|---|---|
| `measure` | `'OutStrength'` | which measure to draw |
| `measures` | — | draw a grid, one panel per measure |
| `columns` | `2` | panels per row in grid mode |
| `sort` | `true` | sort bars by descending value |
| `colors` | Tableau-10 | bar palette, cycled by state index |
| `width` / `height` | `340` / `max(nStates * 28 + 40, 200)` per panel | panel size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

Throws when the result has no states, when `measures` is empty, or when the
named measure is absent from the result.

`CentralityPlotOptions` is the exported option type.

### plotStability(result, options?)

Case-drop stability curves: mean centrality correlation against the proportion
of cases dropped, one line (plus dots) per measure over a shaded **95%
quantile band** computed from the raw per-iteration correlations the result
already carries, with the dashed red acceptability threshold and percent x
ticks. Input is a `StabilityResult` (from `estimateCS()`).

When the result carries CS coefficients, a **chip row above the chart** shows
each measure's swatch, CS value and a colour-coded verdict — ≥ 0.5 *stable*
(green), ≥ 0.25 *moderate* (amber), else *unstable* (red), the bootnet
cut-offs — replacing the bottom legend. `showVerdicts: false` restores the
classic in-SVG legend with `· CS=<coef>` entries.

A `NaN` correlation breaks the line into segments rather than dropping the
series, so a zero-variance measure still appears.

| option | default | meaning |
|---|---|---|
| `threshold` | `result.threshold` (0.7) | dashed reference line |
| `dots` | `true` | mark each sampled drop proportion |
| `band` | `true` (= `[0.025, 0.975]`) | per-measure quantile band from `result.correlations`; a `[lo, hi]` pair picks other quantiles; `false` → mean lines only |
| `showVerdicts` | `true` when CS present | CS chips + verdicts above the chart (replaces the legend) |
| `showCs` | `true` | append `· CS=<coef>` to legend entries (legend mode only) |
| `colors` | 6-colour CS palette | line palette, cycled by measure index |
| `width` / `height` | `760` / `260` (plot area, excluding margins/legend) | size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

Throws when the result carries no measures or no drop proportions.

`StabilityPlotOptions` is the exported option type.

### plotCoefficients(items, options?)

Generic forest / coefficient plot: one row per estimate, a horizontal
confidence interval with end caps, a square marker at the point estimate
(**filled** when p < .05, hollow otherwise), the p-value in the right margin
and a dashed reference line. Input is plain
`{ name, estimate, ci?: [low, high], p? }[]` — `CoefficientItem[]` — so any
effect-size table can be drawn with it.

Ported from the carm-tna notebook's `_renderForestPlot`. It is **not** called
`plotForest`: that name belongs to `ladyna/lagdynamics`, whose painter is typed
to an LSA result.

| option | default | meaning |
|---|---|---|
| `sort` | `'estimate'` | `'estimate'` sorts by \|estimate\| descending; `'none'` keeps input order |
| `refValue` | `0` | dashed reference line — pass `1` for odds ratios |
| `logScale` | `false` | lay the x axis out on a log scale (ticks stay labelled on the original scale) |
| `xLabel` | `'estimate'` | x-axis caption |
| `rowHeight` / `labelWidth` | `22` / `230` | row pitch and left label gutter |
| `colors` | `['#1565c0']` | marker / interval colour (first entry only) |
| `width` / `height` | `640` / `max(120, 22·n + 50)` | canvas size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

Under `logScale` a value ≤ 0 has no position: such a row is dropped and such an
interval end drops its interval, silently — the house rule for an unusable
optional input. A row with no usable `ci` draws its marker alone.

Worked example, feeding it from [`patternOutcome()`](sequences.md#patternoutcome):

```js
import { patternOutcome, plotCoefficients } from 'ladyna';

// Binary outcome — odds-ratio rows, so the null is 1 and the axis is log.
const bin = patternOutcome(sequences, found, pass);
const orSvg = plotCoefficients(
  bin.rows.map(r => ({ name: r.pattern, estimate: r.oddsRatio, ci: [r.ciLow, r.ciHigh], p: r.p })),
  { refValue: 1, logScale: true, xLabel: 'odds ratio (log scale)' },
);

// Continuous outcome — OLS slopes, so the null is 0 and the axis is linear.
const cont = patternOutcome(sequences, found, score);
const bSvg = plotCoefficients(
  cont.rows.map(r => ({ name: r.pattern, estimate: r.estimate, ci: [r.ciLow, r.ciHigh], p: r.p })),
  { refValue: 0, xLabel: 'β (points per occurrence)' },
);
```

Throws `no items` on an empty list and `no drawable estimates` when nothing
survives the `logScale` filter. `CoefficientItem` and `CoefficientPlotOptions`
are the exported types.

---

## Pattern comparison painters (SVG)

Two painters for [`compareSequences()`](#comparesequencesx-options) results, ported from
the carm-tna notebook (`notebook-render/pattern-compare-pyramid.js` and
`src/tna-notebook_v2.html:7586`). Both **read `row.residuals`** — the
standardized adjusted residuals `compareSequences` already computed on the
complete pre-`minFreq` table — and never recompute one, so a figure can never
disagree with the table it was drawn from.

Both use `plotMosaic`'s ColorBrewer **RdBu** ramp in the mosaic's polarity —
over-represented residuals paint **blue**, under-represented **red**, clamped
to ±4 (`colorClamp`) — so residual colour means one thing package-wide
(mosaic, pyramid, heatmap). In-cell labels pick black or white by the fill's
luminance. The heatmap fills the house 760px canvas (cells share the row
width); pass `width` to override.

`CompareSort` = `'residual'` (default — largest \|z\| first) `| 'frequency' |
'pattern' | 'none'`.

### plotComparePyramid(result, options?)

Back-to-back bars for **exactly two groups**: the left bar is group A's
frequency, the right bar group B's, each filled by that cell's residual and
labelled with it (when the bar clears 28px), with the adjusted p in the centre
gutter — emphasised when it is below .05.

```js
import { compareSequences, plotComparePyramid } from 'ladyna';

const rows = compareSequences(groupModel, { minFreq: 5, test: true, seed: 1 });
const svg = plotComparePyramid(rows, { top: 12 });
```

| option | default | meaning |
|---|---|---|
| `top` | `15` | keep the first N rows after sorting |
| `sort` | `'residual'` | see `CompareSort` above |
| `colorClamp` | `4` | ± clamp of the diverging fill |
| `showPValues` | auto — `true` when any row carries a `pValue` | draw the centre p gutter (72px); off replaces it with a divider line |
| `width` / `height` | `760` / 28px per drawn row + margins | canvas size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

Throws `no rows` on an empty result and
`needs exactly 2 groups, got K` otherwise — use the heatmap for K > 2.
`ComparePyramidOptions` is the exported option type.

### plotCompareHeatmap(result, options?)

Pattern × group heatmap of the same residuals, for **two or more** groups. Rows
are ranked by the largest \|z\| across the groups and cut to `top`, so the
patterns that discriminate most sit at the top; column labels are rotated 35°
and a ±`colorClamp` colour key sits on the right.

```js
import { compareSequences, plotCompareHeatmap } from 'ladyna';

const rows = compareSequences(groupModel, { minFreq: 5 });
const svg = plotCompareHeatmap(rows, { top: 20, showValues: true });
```

| option | default | meaning |
|---|---|---|
| `top` | `15` | keep the first N rows after sorting (the notebook hardcodes 15) |
| `sort` | `'residual'` | see `CompareSort` above |
| `colorClamp` | `4` | ± clamp of the diverging fill |
| `showValues` | auto — on when cells are > 40px wide | print the residual inside each cell (white above \|z\| = 2) |
| `legend` | `true` | draw the ±clamp colour key |
| `width` / `height` | sized from the cell grid (26px rows, 60–100px columns) | canvas size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

The colour key is 32 stacked rects rather than an SVG `<linearGradient>`: a
painter that returns a *string* cannot own a document-global gradient id, and
two figures on one page would collide.

Throws `no rows` on an empty result and `rows carry no groups` when the rows
have no residual record. `CompareHeatmapOptions` is the exported option type.

*Available from:* root, analysis. Tests: `tests/pattern-plots.test.ts`.

---

## Diagnostic painters (SVG)

Three more self-contained SVG painters, consolidated from the D3 figures that
existed only inside Dynalytics Desktop (`src/views/markov-plots.ts`,
`src/views/dashboard.ts`, `src/views/chart-utils.ts`) and the carm-tna
notebook (`notebook-render/markov-plots.js`, `split-half-figure.js`,
`edge-reliability-panel.js`). They are pure result-object-in /
static-figure-out, so the engine owns them; the source files carry a
`// Source: <file>:<line>` line above every ported function.

Like the painters above, each returns a standalone `<svg>` **string** with no
external assets and no runtime dependency. The D3 vocabulary they needed
(`scaleLinear`, `scaleBand`, `d3.ticks`, `nice`, `axisBottom`, `axisLeft`,
`line`, `area`, `curveBasis`, `quantile`, `tickFormat`) is re-implemented
exactly in `src/analysis/diagnosticPlots.ts`.

Rendering only — no R-parity requirement on pixels. Constants, KDE bandwidth
rules, bin counts, thresholds and colours are carried over verbatim, including
two deliberately preserved quirks: the Markov KDE's `approxIqr` is not a real
IQR (it indexes the sorted sample without interpolation), and the two figures
use *different* Silverman rules — `0.9 * min(sd, iqr/1.34) * n^-0.2` with a
population `sd` for the Markov nulls, `1.06 * sd * n^-0.2` with a sample `sd`
for the reliability densities.

```js
import {
  tna, markovOrderTest, reliabilityAnalysis, casedropReliability,
  plotMarkovOrder, plotSplitHalf, plotEdgeReliability,
} from 'ladyna';

const model = tna(sequences);
document.body.innerHTML =
    plotMarkovOrder(markovOrderTest(sequences, { maxOrder: 3, seed: 1 }))
  + plotSplitHalf(reliabilityAnalysis(sequences, 'tna', { iter: 200, seed: 1 }))
  + plotEdgeReliability(casedropReliability(model, { iter: 200, seed: 1 }));
```

### plotMarkovOrder(result, options?)

Markov order-selection figure. Two columns share one canvas: the **left**
stacks log-likelihood, AIC and BIC across orders (a dotted rule at
`result.bicOrder`, a dashed rule at `result.optimalOrder`, 50px per order);
the **right** shows one Gaussian-KDE permutation null of G² per order
`k = 1..maxOrder`, with the observed statistic as a red rule and an inline
`p = …`. Orders whose permutation vector is empty print
`No permutations available at this order (df = 0).`

Input is a `MarkovOrderResult` from `markovOrderTest()`.

| option | default | meaning |
|---|---|---|
| `type` | `'both'` | `'fit'` = left column only, `'null'` = right column only, `'both'` = side by side |
| `colors` | carm `--cnr-*` light-theme hexes | partial override of `MarkovOrderPlotColors` (`loglik`, `aic`, `bic`, `warning`, `grid`, `text`, `faint`, `muted`, `danger`, `density`) |
| `title` | — | heading drawn above the columns |
| `background` | `'#ffffff'` | canvas background |

Throws when the argument is not a `markovOrderTest()` result, when
`maxOrder < 1`, or when `testTable` is empty.

`MarkovOrderPlotOptions` and `MarkovOrderPlotColors` are the exported types.

### plotSplitHalf(result, options?)

Split-half reliability figure. Accepts either a `reliabilityAnalysis()` result
(22 metrics) or a `networkReliability()` result (4 metrics per model; pick one
with `model`, default the first). The four `networkReliability` keys are mapped
onto the shared display labels — `mean_dev` → Mean Abs. Diff., `median_dev` →
Median Abs. Diff., `cor` → Pearson, `max_dev` → Max Abs. Diff. — so both inputs
drive the same panels.

Four views:

- **`'histograms'`** (default) — Nestimate `plot(rel)` parity: a 2×2 histogram
  grid over Mean/Median/Max absolute difference and Pearson on a 740×460
  canvas, 25 uniform bins per panel, a dashed vertical mean rule with its
  value, per-panel x and y axes and a rotated `Count` label.
- **`'boxplot'`** — Desktop's Box Plots tab: one stacked panel per metric
  category (Deviations, Correlations, Dissimilarities, Similarities, Pattern),
  Tukey boxes with 1.5×IQR whiskers and outlier rings.
- **`'density'`** — Desktop's Density tab: overlaid KDE curves per category
  with a dashed mean line and value label per metric, plus an inline legend.
- **`'meansd'`** — Desktop's Mean ± SD tab: horizontal bars from 0 to the mean
  with ±1 SD error bars and a mean dot.

| option | default | meaning |
|---|---|---|
| `view` | `'histograms'` | `'histograms' \| 'boxplot' \| 'density' \| 'meansd'` |
| `model` | first model | which model of a multi-model `networkReliability` result |
| `accent` | `'#4e79a7'` | histogram bar colour (carm `--cnr-accent`) |
| `colors` | per-category Tableau palettes | palettes for the other three views |
| `width` | `620` | panel width for the boxplot / density / mean±SD views |
| `title` | `'Split-half reliability of the network'` | heading |
| `subtitle` | `"<iter> iterations · 50/50 random split"` | second heading line |
| `background` | `'#ffffff'` | canvas background |

Throws when the argument is not a reliability result, when no metric has a
finite iteration value, or when `model` names a model that is not present.

`SplitHalfPlotOptions` and `SplitHalfView` are the exported types.

### plotEdgeReliability(result, options?)

Case-drop edge reliability: a 2×2 grid of mean ± SD ribbons against the
proportion of cases dropped — Correlation, Mean |diff|, Median |diff| (MAD),
Max |diff| — with a shared rotated y-label (`Mean ± SD across iterations`), a
shared x-label (`Proportion of cases dropped`), tick labels only on the bottom
row, and the reliability threshold drawn as a dashed rule on the **Correlation
panel only** (Nestimate `plot(edge_stab)` behaviour).

Input is a `CasedropReliabilityResult`; the painter reads `result.summary[]`
(`{ metric, dropProp, mean, sd }`) and sorts each metric's rows by `dropProp`.
Desktop has no figure for this analysis — only a table — so there was nothing
to reconcile.

| option | default | meaning |
|---|---|---|
| `threshold` | `result.threshold` | dashed rule on the Correlation panel; a non-finite value drops the rule |
| `accent` | `'#4e79a7'` | SD ribbon fill |
| `title` | — | optional heading |
| `background` | `'#ffffff'` | canvas background |

Throws when the argument is not a `casedropReliability()` result, when
`summary` is empty, or when none of the four metric names is present.

`EdgeReliabilityPlotOptions` is the exported option type.

Tests: `tests/diagnostic-plots.test.ts`.

---

## Group divergence — Jensen-Shannon

Ported from Dynalytics Desktop (`src/analysis/jsd.ts`, plus the coverage guard
in `src/views/jsd.ts`). These have no R counterpart; they are pinned by the
closed-form assertions in `tests/desktop-verbs.test.ts`.

This is a **separate public verb** from the private `jsdBits` split criterion
used inside `ladyna/transitiontrees` — that one is an internal impurity measure
and is not exported.

### `jsd(P, Q)`

Jensen-Shannon divergence between two discrete distributions given as parallel
probability vectors over the same state ordering:

`JSD = ½·KL(P‖M) + ½·KL(Q‖M)`, with `M = (P+Q)/2`, **log base 2** — so the
result lies in `[0, 1]`. `0` for identical distributions, `1` for disjoint
supports. `0·log 0` is treated as `0`, and states with zero mass in both
vectors are skipped. The result is clamped to `[0, 1]` as numerical safety.

Both `number[]` and `Float64Array` are accepted (`ProbVector`).

*Available from:* root, analysis.

### `positionwiseJSD(blocks, stateLabels, options?)`

Pairwise JSD between groups at **every sequence position**. Each block is
`{ name, sequences }` where a sequence may carry `null` padding. At each
position `t` the verb builds one categorical distribution per group over
`stateLabels` (nulls and values absent from `stateLabels` are excluded from
both the distribution and the valid-N), then computes JSD for every group pair.

Returns `null` when there are fewer than two groups, or when every sequence is
empty — the source's guard, kept.

| option | default | meaning |
|---|---|---|
| `minN` | `5` | per-group observation count required for a position to count as "full coverage" |

`JSDResult` fields:

| field | meaning |
|---|---|
| `positions` | `0 … maxLen-1` |
| `pairLabels` | `"g1 ↔ g2"`, one per pair (length `C(k,2)`) |
| `perPair` | label → per-position JSD; `NaN` where either group has no observations |
| `mean` | mean over the **finite** pairs at each position; `NaN` if none |
| `meanAllPairs` | mean over **all** pairs; `NaN` unless every pair is finite there |
| `validN` | group → per-position valid observation count |
| `minValidN` | per-position minimum of `validN` across groups |
| `fullCoverageEnd` | last position where every group has `>= minN` observations; `-1` if none |
| `minN`, `maxLen` | the threshold applied, and the longest sequence length |
| `pairs` | tidy `JSDPairRow[]`: one row per (position, pair) with `jsd`, `n1`, `n2` |
| `positionSummary` | tidy `JSDPositionRow[]`: one row per position with `meanJSD`, `meanAllPairs`, `minValidN`, `fullCoverage` |

`mean` and `meanAllPairs` differ deliberately: once a short group runs out,
`mean` would otherwise degenerate to "the mean of the one surviving pair", so
`meanAllPairs` is the curve to plot past `fullCoverageEnd`.

Exported types: `JSDBlock`, `JSDOptions`, `JSDResult`, `JSDPairRow`,
`JSDPositionRow`, `ProbVector`.

*Available from:* root, analysis.

---

## Reliability-metric goodness

Ported from Dynalytics Desktop `src/views/compare-properties.ts`. Rescales the
22 `RELIABILITY_METRICS` onto a common `[0, 1]` scale — `1` = good (similar),
`0` = bad (dissimilar) — so metrics from different families share one ranking
or colour scale. All thresholds are **absolute**: a Spearman of 0.9 scores the
same regardless of the rest of the table.

Per-category transforms (the decay constants are substantive tuning, copied
exactly from the source):

| category | transform | note |
|---|---|---|
| `Correlations` | `clamp((v+1)/2)` | `[-1,1]` → `[0,1]` linearly |
| `Similarities`, `Pattern` | `clamp(v)` | already in `[0,1]` |
| `Deviations` (`cv_ratio`) | `exp(-2·|v-1|)` | best at 1, symmetric decay |
| `Deviations` (others) | `exp(-5v)` | 0 is perfect; `v=0.1→0.61`, `v=0.5→0.08` |
| `Dissimilarities` (`braycurtis`) | `1 - clamp(v)` | already in `[0,1]` |
| `Dissimilarities` (others) | `exp(-3v)` | 0 is perfect, unbounded above |

A non-finite value, or an unrecognised category/metric key, returns the neutral
`0.5`. The `exp()` branches are **not** clamped — deviations and
dissimilarities are non-negative by construction, so a negative input exceeds
`1`. That is the source's behaviour and is kept.

### `goodness(value, metric)`

Goodness for one metric named by its `RELIABILITY_METRICS` key (`'pearson'`,
`'cv_ratio'`, `'braycurtis'`, …). The category is resolved from that list.

### `goodnessOf(value, key, category)`

The underlying transform with the category supplied explicitly — use it when
scoring a metric that is not in `RELIABILITY_METRICS`.

### `goodnessScores(values)`

Rescales a whole metric bundle — e.g. one row of `compareWeightMatrices()` —
returning a tidy `GoodnessRow[]`: one row per metric in `RELIABILITY_METRICS`
order, with `metric`, `label`, `category`, `value`, `goodness`. Metrics absent
from `values` report `value: NaN` and the neutral `goodness: 0.5`.

*Available from:* root, analysis.
