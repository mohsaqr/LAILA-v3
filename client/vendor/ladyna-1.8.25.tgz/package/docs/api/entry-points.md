# Entry points & bundle variants

ladyna publishes 15 subpaths (`package.json` `exports`). Which one you import
from decides both **what you can reach** and **what ends up in your bundle**.
The machine-generated [export availability matrix](exports.md) is the
authoritative per-function answer; this page explains the structure.

## The module subpaths

| Subpath | Surface | Docs |
|---|---|---|
| `ladyna` | Broad consumer aggregate (520 runtime exports). A few low-level helpers and R-style aliases remain module-only; LSA painters are renamed `plotLSA*` (see [lagdynamics](lagdynamics.md)) | all pages |
| `ladyna/core` | Model layer: factories, `Matrix`, preparation, groups, RNG, colors, drawing geometry, `plotNetwork` | [core.md](core.md) |
| `ladyna/analysis` | TNA analysis verbs + HON/Nestimate family + `plotSimplicial` (its only painter) | [analysis.md](analysis.md), [hon.md](hon.md), [topology.md](topology.md) |
| `ladyna/sequences` | TraMineR sequence indicators (`seqindic` + 28 indicator family) | [sequences.md](sequences.md) |
| `ladyna/stats` | Correlations, p-value adjustment | [stats.md](stats.md) |
| `ladyna/htna` | Heterogeneous TNA + `plotHTNA` / `plotMCML` | [htna.md](htna.md) |
| `ladyna/transitiontrees` | Prediction suffix trees + 12 painters | [transitiontrees.md](transitiontrees.md) |
| `ladyna/lagdynamics` | Lag sequential analysis + 7 painters (original names) | [lagdynamics.md](lagdynamics.md) |
| `ladyna/processmining` | Event logs, process maps, conformance, discovery + painters | [processmining.md](processmining.md) |
| `ladyna/association` | Apriori/Eclat/FP-growth/WARM, significance, clustering, evaluation + advanced visualizations | [association.md](association.md) |

## The bundle variants: `light`, `full`, `wasm`

These exist for the notebook/WASM ecosystem (carm-tna, tnaw). They are
**curated subsets**, not supersets:

| Variant | What it is |
|---|---|
| `ladyna/light` | ladyna surface **minus the 10 WASM-kernel names** (see below), for bundles that pair with `ladyna/wasm`. 257 exports. No `export *` — the surface is pinned, and the sibling repo test `carm-tna/tests/light-boundary.test.ts` enforces which modules it may import. |
| `ladyna/full`, `ladyna/full/web` | light's surface **plus** pure-TS implementations of the 10 WASM names and extra stats (anova/kruskal/tukey families, chi-square, multinomial fit…). 259 exports. `/web` differs only in the WASM loader. |
| `ladyna/wasm`, `ladyna/wasm/web` | light's surface plus the 10 kernels backed by the Rust/WASM build (loads a `.wasm` artifact at init — call `initWasm()`/`initTnaw()` first; `isWasmEnabled()`/`isTnawReady()` report readiness). |

**The 10 WASM-kernel names** (excluded from `light`, provided by `wasm`/`full`):
`bootstrapTna`, `centralities`, `permutationTest`, `estimateCS`,
`compareWeightMatrices`, `markovOrderTest`, `passageTime`, `markovStability`,
`casedropReliability`, `reliabilityAnalysis`.

### What light/full do NOT carry (import from root or the module subpath)

Verified against the built library (see [exports.md](exports.md)):

- **All of `ladyna/transitiontrees`** — the tree verbs and all 12 `plot*` painters.
- **All of `ladyna/lagdynamics`** — `lsa`, engines, inference, and all 7 LSA painters
  (so no, LSA plots are *not* on light/full; use `ladyna` or `ladyna/lagdynamics`).
- **All of `ladyna/association`** — import it from root or the dedicated module
  subpath; it is pure TypeScript but intentionally excluded from curated notebook bundles.
- **The `seqindic` indicator family** (`ladyna/sequences`) — root and the
  subpath only. The codyna-subset sequence verbs (`sequenceIndices`,
  `discoverPatterns`, descriptives…) *are* on `light` (not `full`).
- **The drawing geometry** — `networkEdgeGeometry`, `networkArrowPolygon`,
  `networkSelfLoopGeometry` (root and `ladyna/core` only).
- Assorted root-only verbs — check the matrix when in doubt.

### What light/full DO carry

The core model layer, the non-WASM analysis verbs, `plotNetwork`, the HTNA +
MCML painters, the whole process-mining module, and the color utilities.

### light ⊄ full oddity

`light` and `full` are not strict subsets of each other: `light` additionally
carries the Nestimate-ports exploration surface (hypergraph measures,
persistent homology, q-analysis, `clusterMmm`, sequence descriptives…) that
`full` omits, while `full` adds the stats families listed above. When a name
is missing where you expected it, consult [exports.md](exports.md) — that
file is generated (`tools/generate-export-matrix.mjs`) and cannot drift.

## Rules of thumb

- **Application / analysis code**: import from `ladyna` (root) for the broad,
  collision-free consumer surface. Use the matrix before assuming a low-level
  helper or R-style alias is also present there.
- **Notebook bundles pairing with WASM kernels**: `ladyna/light` + `ladyna/wasm`.
- **Tree-shaken single-module consumers**: the module subpath
  (`ladyna/lagdynamics`, `ladyna/processmining`, …) with the original local names.
