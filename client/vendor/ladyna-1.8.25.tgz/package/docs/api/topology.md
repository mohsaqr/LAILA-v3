# ladyna topology — simplicial complexes, persistent homology, hypergraphs

Topological data analysis on transition networks, ported from R **Nestimate**
(source tree, 0.8.5). Builds simplicial complexes and hypergraphs from a TNA
model (or any weight matrix), and measures their higher-order structure:
Betti numbers, Q-analysis, persistent homology with landscapes and bottleneck
distances, and hypergraph centralities.

**Available from**: root `ladyna`, `ladyna/analysis`, and `ladyna/light` — **not**
on `ladyna/full` (see [entry-points.md](entry-points.md) for the light/full
asymmetry).

**Visualization**: `plotSimplicial()` renders any complex — clique- or
pathway-mode — as the cograph "blob view" (see [below](#visualization)).
Runnable demos: `demo/nestimate-ports.html` (complex + degree + q-analysis +
Betti + persistent-homology panels) and the **blob view in `demo/index.html`**
(the main demo's interactive higher-order panel, with k-gram order controls
and combined/dismantled layouts).

```typescript
import {
  buildSimplicial, buildSimplicialKgrams, simplicialEvidence,
  simplicialDegree, qAnalysis,
  bettiNumbers, eulerCharacteristic, plotSimplicial,
  persistentHomology, persistenceLandscape, bottleneckDistance,
  buildHypergraph, hypergraphMeasures, hypergraphCentrality,
  cliqueExpansion, bipartiteGroups,
} from 'ladyna';
```

**Statistics travel with the complex.** A *pathway*-mode complex carries an
additive `meta` channel (`SimplexMeta[]`, parallel to `simplices`) holding each
pathway's direction, count, and HYPA anomaly statistics.
[`buildSimplicialKgrams()`](#buildsimplicialkgramssequences-options) is the
one-call pipeline that produces such a complex from raw sequences,
[`simplicialEvidence()`](#simplicialevidencesc) is the tidy table beside the
figure, and `plotSimplicial()` reads the same channel to colour, rank and
caption its blobs. Topology verbs ignore `meta` entirely — every number a
complex reports is unchanged by its presence.

All examples below were executed against the built library:

```typescript
import { tna, buildSimplicial, bettiNumbers, eulerCharacteristic, qAnalysis } from 'ladyna';

const model = tna([['a','b','c','a'], ['b','a','c','b'], ['c','a','b','c']]);
const sc = buildSimplicial(model, { threshold: 0.2 });
// sc.nNodes = 3, sc.simplices.length = 7, sc.dimension = 2
bettiNumbers(sc);        // [1, 0, 0]  (connected, no holes, no voids)
eulerCharacteristic(sc); // 1
qAnalysis(sc);           // { qVector, maxQ, structureVector }
```

## Simplicial complexes

### buildSimplicial(x, options?)

```typescript
buildSimplicial(x: SimplicialInput | PathwayLikeInput, options?: SimplicialOptions): SimplicialComplex
```

Build a simplicial complex from a TNA model or weight matrix. Clique mode
(default): symmetrize + threshold the adjacency, enumerate maximal cliques,
expand to all faces. Options (defaults): `type: 'clique' | 'pathway'`
(`'clique'`); `threshold` (0, clique-mode minimum absolute edge weight);
`maxDim` (10, a k-simplex has k+1 nodes); `inclusive` (true — include
weight ≥ threshold, matching R); `labels` (for raw matrices).
Returns `{ nodes, simplices, nNodes, nSimplices, dimension, fVector, density, meanDim, type }`,
plus `meta` in pathway mode only (see below).

### buildSimplicialPathway(input, options?)

Pathway-mode construction — port of `Nestimate::.build_simplicial_pathway`.
Accepts HON-style (`{ edges, firstOrderStates }`, higher-order edges only),
HYPA-style (`{ scores, nodes }`, filtered by `anomaly: 'over' | 'under' | 'all'`),
MOGen-style (`{ transitions, states }`), or raw `{ paths, … }` inputs; each
`path` is `"A -> B -> C"`. Options add `maxPathways` and `anomaly` to
`SimplicialOptions`. **Exported from `ladyna/analysis` only** — from root/light,
reach it as `buildSimplicial(x, { type: 'pathway' })`.

Pathway complexes are what the blob view was designed for: each higher-order
pathway becomes one blob enclosing the states it visits. The complex itself
stores **sorted, deduplicated** vertex tuples, so neither direction nor
repeats survive into `simplices` — that is what the `meta` channel is for.

```typescript
import { buildSimplicialPathway } from 'ladyna/analysis';
import { plotSimplicial } from 'ladyna';

const sc = buildSimplicialPathway({
  paths: [{ path: 'plan -> search -> read' }, { path: 'read -> note -> adapt' }],
  nodes: ['plan', 'search', 'read', 'note', 'adapt'],
});
document.body.innerHTML = plotSimplicial(sc, {
  title: 'Higher-order pathways',
  minDim: 2,                    // pathways only, skip bare edges
});
```

Every input row's statistics flow through, whichever producer shaped them:
HON `edges` contribute `count`, HYPA `scores` contribute `observed`, `ratio`,
`anomaly`, `pAdjustedOver`/`pAdjustedUnder`, and generic `paths` rows
(`PathwayRowInput`) may carry any of `count` / `observed`, `ratio`, `anomaly`,
`pAdjusted` / `pAdjustedOver` / `pAdjustedUnder`, `order`. Nothing is required
beyond `path`.

### The `meta` channel — `SimplexMeta`

```typescript
interface SimplexMeta {
  path: string;                                 // "A -> B -> C", verbatim
  parts: readonly string[];                     // ordered, repeats preserved
  order: number;                                // pathway length in states
  rank: number;                                 // 1-based position in the input list
  count?: number;                               // raw occurrences
  ratio?: number;                               // HYPA observed / expected
  anomaly?: 'over' | 'under' | 'normal';        // HYPA class
  pAdjusted?: number;                           // min of the two adjusted tails
  target?: string;                              // last state of the path
}
```

`sc.meta` is `(SimplexMeta | null)[]`, **parallel to `sc.simplices`** — same
length, same order — and is present **only** in pathway mode (a clique- or
VR-mode complex has no `meta` key at all).

A complex is closed under subsets, so most entries are closure faces
corresponding to no input pathway: those are `null`. An entry is non-null
exactly when its sorted vertex tuple equals the deduplicated tuple of some
input pathway — normally the top-dimensional simplex that pathway inserted,
but also matched when a shorter pathway happens to coincide with a face. When
two pathways collapse onto the same tuple (`"A -> B -> C"` and `"C -> B -> A"`),
the **first** one in the already-filtered, already-ordered input list wins.

`rank` is what restores the caller's ordering: the complex interleaves each
pathway's closure faces, so index order in `meta` is *not* the input order.
`simplicialEvidence()` sorts by `rank`, and `plotSimplicial({ sort: 'rank' })`
selects by it.

The channel is strictly additive. `bettiNumbers`, `eulerCharacteristic`,
`qAnalysis`, `simplicialDegree`, `persistentHomology` and every other topology
verb ignore it, and `simplices`, `fVector`, `density`, `meanDim`, `dimension`
and `nSimplices` are byte-identical whether it is attached or not
(pinned by `tests/simplicial-meta.test.ts`).

### buildSimplicialKgrams(sequences, options?)

```typescript
buildSimplicialKgrams(
  sequences: string[][] | SequenceData | TNA,
  options?: SimplicialKgramsOptions,
): SimplicialComplex
```

The k-gram pathway pipeline as one verb — sequences in, a fully annotated
pathway complex out. It composes existing verbs rather than reimplementing
them: `kgramCounts()` for the counting, `buildHypa()` for the hypergeometric
test, `buildSimplicialPathway()` for the complex.

1. Pool k-grams across every requested `order` (`kgramCounts`).
2. Drop k-grams below `minCount`.
3. Optionally run `buildHypa` once per order at **k = order − 1** (HYPA's `k`
   is the *source-tuple* length, so a path of `order` states is scored at
   `order − 1`) and join its scores onto the pathways by path key.
4. Filter to one anomaly class.
5. Sort, then cap.
6. Build the complex with full `meta`.

| Option | Default | Meaning |
|---|---|---|
| `orders` | `[3, 4]` | pathway lengths in states; each rounded and clamped to 2…20, de-duplicated |
| `minCount` | 2 | drop k-grams observed fewer times |
| `hypa` | `false` | `true`, or `{ alpha?: 0.05, pAdjustMethod?: 'BH' \| 'bonferroni' \| 'holm' \| 'none' }` |
| `anomaly` | `'all'` | `'over'` / `'under'` restrict to that HYPA class; `'all'` is a **no-op** |
| `sort` | `'count'` | `'count'` (desc) · `'p'` (best adjusted p, asc) · `'anomaly'` (over, under, normal) · `'order'` (asc) |
| `maxPathways` | — | keep at most this many, applied **after** sorting |
| `maxDim` | 10 | forwarded to the complex |

**HYPA is implied** whenever `anomaly !== 'all'` or `sort` is `'p'` or
`'anomaly'` — those questions cannot be answered without it, and silently
ignoring the request was the exact bug consumers kept hitting.

**`anomaly: 'all'` differs from `SimplicialOptions.anomaly`.** Here the
universe is k-grams, so `'all'` genuinely keeps everything (normal pathways
included). On `buildSimplicial(x, { type: 'pathway' })` the universe is
already HYPA scores, and `'all'` there means "every *non-normal* anomaly".

Every ordering breaks ties on count (descending) then on the path string
(ascending), so the result — and therefore the rank window
`plotSimplicial({ range })` slices — is fully determined by the data.

Throws when no k-gram survives `minCount`, when no pathway matches the
requested `anomaly`, or when the input has no usable trajectory; the message
names the filter that emptied the set. An `order` whose HYPA run fails (the
sequences are shorter than the order) simply leaves that order's pathways
unannotated instead of aborting.

```typescript
import { buildSimplicialKgrams, simplicialEvidence, plotSimplicial } from 'ladyna';

const sc = buildSimplicialKgrams(sequences, {
  orders: [3, 4], minCount: 3, hypa: true, sort: 'p', maxPathways: 12,
});
console.table(simplicialEvidence(sc));
document.body.innerHTML = plotSimplicial(sc, { colorBy: 'anomaly', sort: 'rank' });
```

### simplicialEvidence(sc)

```typescript
simplicialEvidence(sc: SimplicialComplex): SimplicialEvidenceRow[]
```

The tidy table that belongs beside the blob figure — one row per pathway the
complex carries statistics for:
`{ rank, path, order, count, ratio, pAdjusted, anomaly, target }`, with `null`
wherever the source carried no such statistic. Rows come back sorted by
`rank`, i.e. in the order the complex was built (for a
`buildSimplicialKgrams()` complex, the `sort` you asked for).

Reads only `sc.meta`, so a clique- or VR-mode complex yields `[]` rather than
throwing.

```typescript
simplicialEvidence(buildSimplicialKgrams(sequences, { hypa: true, sort: 'p' }));
// [ { rank: 1, path: 'submit -> read -> plan -> write', order: 4, count: 50,
//     ratio: 0.566, pAdjusted: 0.00055, anomaly: 'under', target: 'write' }, … ]
```

### simplicialDegree(sc, options?)

```typescript
simplicialDegree(sc: SimplicialComplex, options?: { normalized?: boolean }): SimplicialDegreeRow[]
```

Per-node simplex participation, one tidy row per node:
`{ index, node, byDim, total }` — e.g. `{ index: 0, node: 'a', byDim: [1, 2, 1], total: 3 }`
(the node sits in one 0-simplex, two 1-simplices, one 2-simplex).
`normalized: true` divides each d-count by C(n−1, d).

### qAnalysis(sc)

Atkin Q-analysis: `{ qVector, maxQ, structureVector }` — number of
q-connected components at each dimension level.

### bettiNumbers(sc) / eulerCharacteristic(sc)

`bettiNumbers` returns `number[]` — β₀ (components), β₁ (loops), β₂ (voids)…
computed by boundary-matrix rank over ℤ/2. `eulerCharacteristic` returns the
alternating f-vector sum (equals the alternating Betti sum).

## Persistent homology

### persistentHomology(x, options?)

```typescript
persistentHomology(x: SimplicialInput, options?: PersistentHomologyOptions): PersistentHomologyResult
```

Sweep the edge-weight threshold across `nSteps` levels (default 20) and track
the birth/death of topological features up to `maxDim` (default 3;
`type = 'clique'`, `maxScale?`, `labels?`). Returns
`{ bettiCurve, persistence, thresholds, mode }` — `persistence` is the list
of `{ dimension, birth, death }` pairs.

### persistenceLandscape(ph, options?)

```typescript
persistenceLandscape(ph: PersistentHomologyResult | PersistencePair[], options?: { kMax?: number; dimension?: number }): PersistenceLandscape
```

Functional summary of one diagram dimension (default `dimension: 1`,
`kMax: 5` layers). Returns `{ landscape, dimension, kMax, tGrid }`. Throws on
non-positive-integer `kMax` / negative `dimension`.

### bottleneckDistance(d1, d2, options?)

```typescript
bottleneckDistance(d1: BottleneckInput, d2: BottleneckInput, options?: { tol?: number; dimension?: number[] }): Record<string, number>
```

Bottleneck distance between two persistence diagrams (each a
`PersistentHomologyResult` or pair list), computed per dimension via binary
search + bipartite matching; returns `{ [dimension]: distance }`.
`tol` defaults to `√ε`.

## Visualization

### plotSimplicial(sc, options?)

```typescript
plotSimplicial(sc: SimplicialComplex, options?: SimplicialPlotOptions): string
```

Self-contained SVG "blob view" — a port of cograph's `plot_simplicial()`
(`R/plot-simplicial.R` + `R/blob-helpers.R`). Every node sits once on a
circle; each simplex of dimension ≥ `minDim` becomes a smooth blob enclosing
its vertices (2 nodes → oval, 3 → triangle, k → k-gon), so higher-order
structure shows up as overlapping regions. Geometry follows cograph exactly:
a padded circle-cloud around each member node → convex hull → edge upsampling
→ Laplacian smoothing. Blobs carry a `<title>` listing their members and
dimension; the SVG is responsive (`viewBox` + `max-width:100%`).

| Option | Default | Meaning |
|---|---|---|
| `width` / `height` | 880 / 600 | canvas |
| `title` / `subtitle` | — | headings; rendered only when provided |
| `background` | `'#ffffff'` | canvas fill |
| `colors` | cograph's 10 pastels | blob fill palette (cycled) |
| `minDim` | 1 | lowest simplex dimension drawn as a blob (0-simplices are always nodes, never blobs). Use 2 to show pathways/triangles only |
| `maxSimplices` | 10 | cap on blobs, largest-first |
| `targets` | — | node labels painted orange. Redundant on a complex with `meta`, whose pathway targets paint automatically |
| `nodeRadius` | 18, auto-shrunk | node disc radius |
| `showLabels` | true | node labels |
| `pad` | `ring + nodeRadius` | blob inflation around each node |
| `smoothIters` | 80 | Laplacian smoothing iterations per blob outline |
| `mode` | `'combined'` | `'dismantled'` renders a grid of cropped one-simplex panels instead |

**Metadata-aware options.** These read the `meta` channel and degrade cleanly
on a complex that has none:

| Option | Default | Meaning |
|---|---|---|
| `colorBy` | `'palette'` | `'anomaly'` paints semantic HYPA fills — `#dc2626` over, `#2563eb` under, `#9ca3af` normal. Simplices with no `meta` are grey. In **both** modes, a simplex whose `meta.anomaly` is not `'normal'` gets a stronger, semantically-coloured outline (`stroke-width` 2.4 vs 1.5) |
| `sort` | `'size'` | how eligible simplices are **ranked** before selection: `'size'` (largest first, the historic default) · `'count'` · `'p'` · `'anomaly'` · `'rank'` (the order the complex was built in). The meta-driven keys fall back to `'size'` when the complex carries no metadata |
| `range` | — | 1-based **inclusive** rank window, e.g. `[6, 12]`. **Takes precedence over `maxSimplices`** when both are passed |
| `layoutStates` | — | pin the layout circle to this full label set so a state keeps its coordinates across differently-filtered complexes. Complex nodes absent from the list are appended after it (silent degrade, no throw); labels present here but absent from the complex are drawn as faint (50% opacity, slate `#6b7280`) member-less markers |

Ranking decides **which** simplices are drawn; the drawing order is always
largest-blob-first, so big regions sit underneath and small ones stay legible.
This is what CarmNote does: sort the universe, slice a rank window, then draw
largest-first.

With `meta`, a blob's `<title>` gains the statistics —
`"A, B → C\norder 3 · n=12 · ratio=1.82 · over (p̂=0.003)"` — and falls back to
the historic `"A · B · C (dim 2)"` without it.

**`mode: 'dismantled'`** renders one small panel per selected simplex inside a
**single** SVG (so one export carries them all), each cropped around its own
blob and captioned `"A, B → C · n=12 · order 3"` from `meta`, or
`"a, b, c · dim 2"` without it. Panels reuse the shared layout coordinates, so
`layoutStates` pinning holds across panels too. Geometry follows CarmNote's
panel grid: 240 px cells, a 30 px caption strip, at most 4 columns; the canvas
size is grid-determined, so `width` / `height` do not apply in this mode.

```typescript
import { tna, buildSimplicial, plotSimplicial } from 'ladyna';

const sc = buildSimplicial(tna(sequences), { threshold: 0.15 });
document.body.innerHTML = plotSimplicial(sc, { minDim: 2, maxSimplices: 5 });
```

```typescript
// Statistics-aware pathway view: rank by significance, colour by anomaly,
// show ranks 1–9, and keep the layout pinned to the model's full alphabet.
import { buildSimplicialKgrams, plotSimplicial } from 'ladyna';

const sc = buildSimplicialKgrams(sequences, { orders: [3, 4], hypa: true, sort: 'p' });
document.body.innerHTML = plotSimplicial(sc, {
  colorBy: 'anomaly',
  sort: 'rank',
  range: [1, 9],
  layoutStates: model.labels,
});
```

Throws `plotSimplicial: complex has no nodes` on an empty complex. Tests:
`tests/simplicial-plot.test.ts` (structure) and `tests/simplicial-meta.test.ts`
(the metadata options). Available from root `ladyna`, `ladyna/analysis`,
`ladyna/light`, and `ladyna/full`.

**Relation to the demo.** `demo/index.html`'s blob panel is an *interactive*
build of the same visual, implemented in D3 inside `demo/main.ts`.
`plotSimplicial()` is the library-owned static painter and now covers what the
notebook renderers hand-rolled — semantic anomaly colouring, meta-driven
ranking and rank windows, pinned layouts, and the dismantled panel grid — so
prefer it in application code and reach for the demo's approach only when you
need live interactivity.

## Hypergraphs

### buildHypergraph(net, options?)

```typescript
buildHypergraph(net: SimplicialInput | SimplicialComplex, options?: BuildHypergraphOptions): Hypergraph
```

Clique-based hypergraph from a network (or an existing complex). Options
(defaults): `p` (1 — Bernoulli keep-probability for hyperedges; sampling uses
`seed`, default 42, reproducible), `method: 'clique'` (only implemented
method — anything else throws), `includePairwise` (true), `maxSize` (3,
maximum hyperedge cardinality), `threshold` (0), `labels`. Returns
`{ hyperedges, incidence, nodes, nNodes, nHyperedges, sizeDistribution, params }`.

### hypergraphMeasures(hg)

Summary measures: `{ hyperdegree, nodeStrength, maxEdgeSize, coDegree, … }`
(per-node participation, strengths, co-membership counts).

### hypergraphCentrality(hg, options?)

```typescript
hypergraphCentrality(hg: Hypergraph, options?: { type?: string[]; maxIter?: number; tol?: number; normalize?: boolean }): HypergraphCentralityResult
```

Eigenvector-style centralities on the hypergraph; `type` defaults to
`['clique', 'Z', 'H']` (clique-expansion eigenvector, Z-eigenvector,
H-eigenvector), power iteration with `maxIter = 1000`, `tol = 1e-8`,
`normalize = true`. Returns one `number[]` per requested type.

### cliqueExpansion(hg, options?)

```typescript
cliqueExpansion(hg: Hypergraph, options?: { weighted?: boolean }): CliqueExpansionResult
```

Project the hypergraph to an ordinary weighted graph:
`W[i][j] = Σₑ B[i,e]·B[j,e]` with zero diagonal (`weighted` default true).
Returns `{ weights: Matrix, nodes, params }` — feed it back into graph verbs.

### bipartiteGroups(data, player, group, options?)

```typescript
bipartiteGroups(data: BipartiteRow[], player: string, group: string, options?: { weight?: string }): Hypergraph
```

Build a hypergraph straight from long-format rows: each `group` value becomes
a hyperedge over its `player` members (optional per-row `weight` column).

## Types

`SimplicialInput`, `PathwayLikeInput`, `PathwayRowInput`, `SimplicialOptions`,
`SimplicialComplex`, `SimplexMeta`, `SimplicialEvidenceRow`,
`SimplicialKgramsOptions`, `SimplicialKgramsHypaOptions`,
`SimplicialDegreeOptions`, `SimplicialDegreeRow`,
`QAnalysis`, `PersistentHomologyOptions`, `PersistentHomologyResult`,
`PersistencePair`, `PersistenceLandscapeOptions`, `PersistenceLandscape`,
`BottleneckInput`, `BottleneckOptions`, `BuildHypergraphOptions`,
`Hypergraph`, `HypergraphMeasures`, `HypergraphCentralityOptions`,
`HypergraphCentralityResult`, `CliqueExpansionOptions`,
`CliqueExpansionResult`, `BipartiteGroupsOptions`, `BipartiteRow`.
