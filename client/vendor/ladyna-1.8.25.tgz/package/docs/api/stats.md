# ladyna/stats — statistical utilities

The `ladyna/stats` subpath collects the statistics that the analysis layer is built
on: correlation and association measures, p-value adjustment (R's `p.adjust`),
distribution functions (F, t, chi-square, normal, and the studentized range),
omnibus group tests (ANOVA, Welch's ANOVA, Kruskal–Wallis, chi-square), post-hoc
tests (Tukey HSD, Games–Howell, pairwise Welch, Dunn), effect sizes, and a
one-call covariate report. Everything is zero-dependency and pinned against R
ground truth (`tests/group-tests.test.ts`, `tests/ptukey-r.test.ts`, and the
119-dataset Monte Carlo sweep noted in the source).

**Availability.** Every export below is importable from `ladyna/stats`. Most are
also re-exported from the root `ladyna`; a subset additionally appears in
`ladyna/light` and `ladyna/full` (see `docs/api/exports.md` for the authoritative
matrix). The one exception on the root: `pnorm` is exported **only** from
`ladyna/stats`. Availability is noted per function below as
*Available from:* root / stats / light / full.

Related helpers that live in **`ladyna/core`**, not here: `pearsonCorr` (used
internally by `spearmanCorr`), `arrayMean`, `arrayStd`, `arrayQuantile`. They
are documented with the core module.

## Import

```ts
// ESM
import {
  spearmanCorr, kendallTau, distanceCorr, rvCoefficient, pAdjust,
  anova, kruskal, chisqTest, welchAnova, leveneBF,
  tukeyHSD, gamesHowell, welchPairs, dunnTest, postHoc, analyseCovariate,
  describeGroups, effectSizes, hedgesG, quantile7,
  pf, pt2, pchisq, pnorm, ptukey, ptukeyUpper, qtukey, prange,
} from 'ladyna/stats';

// CommonJS
const stats = require('ladyna/stats');
```

---

## Correlation

Association measures used by the stability and reliability analyses. `NaN` is
returned for degenerate inputs (fewer than 2 observations, or a zero-variance
denominator below `1e-14`).

### `rankArray(arr: Float64Array): Float64Array`

Ranks values 1-based with average (mid-rank) ties — R's `rank()` with the
default `ties.method = "average"`. Used internally by `spearmanCorr`.

*Available from:* root, stats, light, full.

### `spearmanCorr(a: Float64Array, b: Float64Array): number`

Spearman rank correlation = Pearson correlation on ranks. Matches R's
`cor(a, b, method = "spearman")`. Takes `Float64Array` (centrality vectors).

*Available from:* root, stats, light, full.

### `spearmanCorrArr(x: number[], y: number[]): number`

Spearman rank correlation for plain `number[]` arrays (used by the reliability
metrics). Same result as `spearmanCorr` on the same data.

*Available from:* root, stats, light, full.

### `kendallTau(x: number[], y: number[]): number`

Kendall's tau-b, with the tie correction:
`tau_b = (C − D) / sqrt((n0 − Tx)(n0 − Ty))`. Matches R's
`cor(x, y, method = "kendall")`. O(n²) pair enumeration.

*Available from:* root, stats, light, full.

### `distanceCorr(x: number[], y: number[]): number`

Distance correlation matching R's `tna:::distance_correlation`: double-centred
distance matrices, biased (n²-normalized) estimator, returning
`v_xy / sqrt(v_x · v_y)` — which **can be negative**, unlike the classical
unbiased dCor.

*Available from:* root, stats, light, full.

### `rvCoefficient(a, b): number`

RV coefficient matching R's `tna:::rv_coefficient`, computed on column-centred
matrices via the tcrossprod formula
`RV = tr(XX'·YY') / sqrt(tr(XX'·XX')·tr(YY'·YY'))`. Arguments are any objects
with `.rows` and `.get(i, j)` — the ladyna `Matrix` qualifies. Both must be
square with the same dimension.

*Available from:* root, stats, light, full.

### Example (run against the built library)

```js
const s = require('ladyna/stats');
const { Matrix } = require('ladyna/core');

const x = new Float64Array([1, 2, 3, 4, 5]);
const y = new Float64Array([2, 1, 4, 3, 5]);
s.spearmanCorr(x, y);                       // 0.8
s.spearmanCorrArr([1,2,3,4,5], [2,1,4,3,5]); // 0.8
s.kendallTau([1,2,3,4,5], [2,1,4,3,5]);      // 0.6
s.distanceCorr([1,2,3,4,5], [2,1,4,3,5]);    // 0.7368421052631579
Array.from(s.rankArray(new Float64Array([10, 20, 20, 5])));  // [ 2, 3.5, 3.5, 1 ]

const a = Matrix.from2D([[0.1,0.6,0.3],[0.4,0.2,0.4],[0.5,0.3,0.2]]);
const b = Matrix.from2D([[0.2,0.5,0.3],[0.3,0.3,0.4],[0.4,0.4,0.2]]);
s.rvCoefficient(a, b);                       // 0.8232127859153062
```

---

## P-value adjustment

### `pAdjust(pvals: number[], method: PAdjustMethod): number[]`

Adjust p-values for multiple comparisons. Matches R's `p.adjust()` for the
supported methods. Returns a **new** array in the original order; the input is
not mutated. With `method: 'none'` or fewer than 2 p-values, a copy of the
input is returned unchanged.

Accepted method names (the exact `PAdjustMethod` union, from the source):

| method | R equivalent | notes |
|---|---|---|
| `'none'` | `p.adjust(method = "none")` | no adjustment |
| `'bonferroni'` | `"bonferroni"` | `min(p·n, 1)` |
| `'holm'` | `"holm"` | step-down, cumulative max |
| `'hochberg'` | `"hochberg"` | step-up, cumulative min |
| `'hommel'` | `"hommel"` | R's quadratic algorithm verbatim |
| `'BY'` | `"BY"` | Benjamini–Yekutieli (BH × harmonic number) |
| `'fdr'` | `"fdr"` | alias of BH, as in R |
| `'BH'` | `"BH"` | Benjamini–Hochberg |

An unrecognized method string falls through to a copy of the input (no
adjustment); TypeScript's union type prevents this at compile time.

*Available from:* root, stats, light, full.

### Example (run against the built library)

```js
const { pAdjust } = require('ladyna/stats');
const p = [0.001, 0.008, 0.039, 0.041, 0.042, 0.06, 0.074, 0.205];

pAdjust(p, 'holm');
// [ 0.008, 0.056, 0.234, 0.234, 0.234, 0.234, 0.234, 0.234 ]
pAdjust(p, 'BH');
// [ 0.008, 0.032, 0.0672, 0.0672, 0.0672, 0.08, 0.0846, 0.205 ]
pAdjust(p, 'bonferroni');
// [ 0.008, 0.064, 0.312, 0.328, 0.336, 0.48, 0.592, 1 ]
pAdjust(p, 'hommel');
// [ 0.008, 0.056, 0.111, 0.111, 0.111, 0.12, 0.148, 0.205 ]
// (values rounded to 4 decimals for display)
```

---

## Distribution functions

Hand-rolled tail probabilities — no lookup tables, no dependencies. `pf`, `pt2`,
and `pchisq` use the regularized incomplete beta/gamma functions; `ptukey`
computes the studentized-range double integral from its definition with
Gauss–Legendre quadrature (pinned against R's `ptukey` over a grid in
`tests/ptukey-r.test.ts`).

### `pf(f: number, df1: number, df2: number): number`

Upper tail of the F distribution — the ANOVA p-value. Equals R's
`pf(f, df1, df2, lower.tail = FALSE)`. Returns 1 for non-positive or
non-finite `f`.

*Available from:* root, stats, full.

### `pt2(t: number, df: number): number`

**Two-sided** p of Student's t on `df` degrees of freedom:
`P(|T| > |t|)` = R's `2 * pt(abs(t), df, lower.tail = FALSE)`. Returns 1 for
non-finite `t` or non-positive `df`.

*Available from:* root, stats, full.

### `pchisq(q: number, df: number): number`

**Upper** tail of chi-square on `df` — the p-value of a chi-square or
Kruskal–Wallis statistic. Equals R's `pchisq(q, df, lower.tail = FALSE)`.
Note the tail direction: this is the p-value directly, not R's default
lower-tail CDF.

*Available from:* root, stats, full.

### `pnorm(x: number): number`

Standard normal CDF (lower tail), accurate to ~1e-15 via the
continued-fraction erfc. Equals R's `pnorm(x)`.

*Available from:* **stats only** (not re-exported from the root).

### `ptukey(q: number, k: number, df: number): number`

`P(Q ≤ q)` for the studentized range with `k` groups (≥ 2) and `df` error
degrees of freedom (> 0). Equals R's `ptukey(q, k, df)`. `df = Infinity` (or
`df > 25000`) collapses to the range distribution itself (`prange`). Returns
`NaN` for invalid `k` or `df`.

*Available from:* root, stats.

### `ptukeyUpper(q: number, k: number, df: number): number`

Upper tail `1 − ptukey(q, k, df)`, clamped to [0, 1] — the Tukey/Games–Howell
p-value. Equals R's `ptukey(q, k, df, lower.tail = FALSE)`.

*Available from:* root, stats.

### `qtukey(p: number, k: number, df: number): number`

Quantile of the studentized range — the critical value behind a Tukey /
Games–Howell confidence interval. Equals R's `qtukey(p, k, df)` to ~1e-6
(bisection on `ptukey`; deliberately not a secant, see the source comment).
Returns `NaN` unless `0 < p < 1`.

*Available from:* root, stats.

### `prange(w: number, k: number): number`

CDF of the range of `k` iid standard normals — `ptukey` at `df = Inf`. Pinned
against R's `ptukey(..., df = Inf)` to 9e-9.

*Available from:* root, stats.

### Example (run against the built library)

```js
const s = require('ladyna/stats');
s.pf(4.5, 2, 15);          // 0.029451005721173408
s.pt2(2.1, 10);            // 0.06207724420221601
s.pchisq(6.0, 2);          // 0.04978706836786395
s.pnorm(1.96);             // 0.9750021070359539
s.ptukey(3.5, 3, 12);      // 0.9300045192694695
s.ptukeyUpper(3.5, 3, 12); // 0.06999548073053052
s.qtukey(0.95, 3, 12);     // 3.7729285955429077
s.prange(3.5, 3);          // 0.964442962700734
```

---

## Omnibus group tests

The statistics a clustering has to answer to. Groups are passed as
`number[][]` (one inner array per group); empty groups are filtered out.
Each returns `null` when the test is undefined (fewer than 2 usable groups,
`N ≤ k`, a constant group for Welch, a degenerate table for chi-square).

### `anova(groups: number[][]): AnovaResult | null`

One-way ANOVA across k groups — R's `aov(y ~ g)` / `oneway.test(var.equal =
TRUE)`. Returns `{ F, df1, df2, p, eta2 }`; `eta2 = SS_between / SS_total` is
reported alongside p by design.

*Available from:* root, stats, full.

### `welchAnova(groups: readonly number[][]): WelchAnovaResult | null`

Welch's ANOVA — R's `oneway.test(var.equal = FALSE)`. The omnibus that does not
assume equal variances (and the one that belongs with Games–Howell). Groups
with fewer than 2 values are dropped; a zero-variance group returns `null`.

*Available from:* root, stats.

### `kruskal(groups: number[][]): KruskalResult | null`

Kruskal–Wallis H with the tie correction — R's `kruskal.test`. Returns
`{ H, df, p }` with `p` from the chi-square approximation.

*Available from:* root, stats, full.

### `chisqTest(table: number[][], stdres?): ChisqResult | null`

Chi-square test of independence on a group × level contingency table — R's
`chisq.test` (no Yates continuity correction is applied, so on a 2 × 2 table it
corresponds to `chisq.test(correct = FALSE)`) — plus Cramér's V and the per-cell standardized
adjusted residuals. All-zero rows/columns are dropped before testing (with
`dropped: true` in the result and df from the reduced table); `expectedMin`
reports the smallest expected count so the caller can see when the chi-square
approximation is suspect (< 5). The optional `stdres` argument defaults to
ladyna's `stdResiduals` (from `ladyna/analysis`).

*Available from:* root, stats, full.

### `pairwiseWelch(names, groups, adjust, pAdjust): WelchPair[]`

```ts
pairwiseWelch(
  names: string[], groups: number[][],
  adjust: string,                              // p-adjust method, '' → 'holm'
  pAdjust: (p: number[], m: string) => number[],
): WelchPair[]
```

Pairwise Welch t-tests between groups, multiplicity-adjusted — exactly R's
`pairwise.t.test(x, g, pool.sd = FALSE, p.adjust.method = "holm")`. The
adjuster function is passed in explicitly (use `pAdjust` from this module).
Pairs where either group has fewer than 2 values are skipped. Prefer
`welchPairs` (below) for the ergonomic version with CIs and effect sizes.

*Available from:* root, stats, full.

### `pairwiseChisq(names, table, adjust, pAdjust, stdres?): ChisqPair[]`

Pairwise chi-square between groups: each pair is tested on its 2 × levels
sub-table via `chisqTest` (so empty columns within a pair are dropped
correctly), then multiplicity-adjusted (`''` → `'BH'`).

*Available from:* root, stats, full.

### Example (run against the built library)

```js
const s = require('ladyna/stats');
const g = [
  [23.1, 25.4, 21.9, 24.8, 22.5, 26.0],
  [28.2, 30.1, 27.5, 29.9, 31.2, 28.8],
  [24.0, 26.3, 25.1, 27.7, 23.8, 25.5],
];
s.anova(g);
// { F: 20.0804400977995, df1: 2, df2: 15,
//   p: 0.000057339055691108545, eta2: 0.728068153611574 }
s.kruskal(g);
// { H: 11.801169590643283, df: 2, p: 0.002737843272588414 }
s.welchAnova(g);
// { F: 19.77690519671684, df1: 2, df2: 9.932589904947719,
//   p: 0.0003438665188592644 }

const ct = s.chisqTest([[20, 12, 8], [10, 18, 12]]);
// ct.X2 = 5.333333333333333, ct.df = 2,
// ct.p = 0.06948345122280153, ct.cramerV = 0.2581988897471611
```

---

## Descriptives, effect sizes, post-hoc

### `describeGroups(names: readonly string[], groups: readonly number[][]): Describe[]`

Per-group descriptives: n, mean, sd, se, median, q1, q3, iqr, min, max, and the
t-based 95% CI **of the mean** (`ciLower`/`ciUpper` — not a data range).
Quantiles use `quantile7`. Statistics needing n ≥ 2 are `NaN` for singletons.

*Available from:* root, stats.

### `quantile7(sorted: readonly number[], p: number): number`

R's `quantile(type = 7)` — the R default. **The input must already be sorted
ascending.** Returns `NaN` for an empty array.

*Available from:* root, stats.

### `leveneBF(groups: readonly number[][]): { F, df1, df2, p } | null`

Levene's test in the Brown–Forsythe form (median-centred absolute deviations,
then a one-way ANOVA) — R's `car::leveneTest` default. Answers "is the
equal-variance assumption safe?"; `analyseCovariate` uses it to pick the
post-hoc default.

*Available from:* root, stats.

### `effectSizes(groups, anova, kruskal): EffectSizes`

```ts
effectSizes(
  groups: readonly number[][],
  _anova: AnovaResult | null,        // accepted for signature symmetry; unused
  kw: KruskalResult | null,
): EffectSizes
```

Omnibus effect sizes: `eta2` (biased upward), `omega2` (bias-corrected, can be
negative), and `epsilon2` = H / (N − 1) for Kruskal–Wallis (R's
`effectsize::rank_epsilon_squared`; `null` when `kw` is `null`).

*Available from:* root, stats.

### `hedgesG(x: readonly number[], y: readonly number[]): number`

Hedges' g for one pair — Cohen's d with the **exact** small-sample correction
`J(m) = Γ(m/2) / (√(m/2) · Γ((m−1)/2))`, matching R's `effectsize::hedges_g`
(not the `1 − 3/(4m−1)` approximation). Positive when `mean(x) > mean(y)`.
`NaN` if either group has fewer than 2 values.

*Available from:* root, stats.

### `tukeyHSD(names, groups, level = 0.05): PostHocPair[]`

Tukey's HSD — R's `TukeyHSD(aov(y ~ g))`. One pooled MSE, studentized-range
p-values and CIs at `1 − level`. `diff` is oriented `mean(b) − mean(a)` as in
R's "b-a" rows; `statistic` is q; `pAdj === p` (Tukey's p is already
familywise). Exact familywise alpha only under equal variances.

*Available from:* root, stats.

### `gamesHowell(names, groups, level = 0.05): PostHocPair[]`

Games–Howell — R's `rstatix::games_howell_test`. Tukey's studentized range,
but each pair gets its own standard error and Welch–Satterthwaite df: no
pooled MSE, no equal-variance assumption. The right default when group sizes
and spreads differ. `pAdj === p` (familywise by construction).

*Available from:* root, stats.

### `welchPairs(names, groups, adjust: PAdjustMethod = 'holm'): PostHocPair[]`

Pairwise Welch t (statistic t, Welch–Satterthwaite df, 95% CI, Hedges' g),
then `pAdjust` — R's `pairwise.t.test(pool.sd = FALSE)`. Simpler and more
conservative than Games–Howell (no studentized range).

*Available from:* root, stats.

### `dunnTest(names, groups, adjust: PAdjustMethod = 'holm'): PostHocPair[]`

Dunn's test — the post-hoc that belongs with a Kruskal–Wallis omnibus. Reuses
the same pooled mid-ranks and the same tie correction as `kruskal` (which is
why pairwise Mann–Whitney is *not* the same test). `statistic` is z, `diff` is
the difference in **mean rank**, `df` and the CIs are `null`, and p is
two-sided normal. Returns `[]` for N < 3.

*Available from:* root, stats.

### `postHoc(method, names, groups, adjust = 'holm', level = 0.05): PostHocPair[]`

```ts
postHoc(
  method: PostHocMethod,             // 'tukey' | 'gamesHowell' | 'welch' | 'dunn'
  names: readonly string[], groups: readonly number[][],
  adjust: PAdjustMethod = 'holm',    // used by 'welch' and 'dunn'
  level = 0.05,                      // used by 'tukey' and 'gamesHowell'
): PostHocPair[]
```

Dispatcher over the four post-hoc tests above; any unknown `method` value
falls through to `welchPairs`.

*Available from:* root, stats.

### `analyseCovariate(covariate, names, groups, options?): CovariateReport`

```ts
analyseCovariate(
  covariate: string,                          // label carried into the report
  names: readonly string[], groups: readonly number[][],
  options?: {
    method?: PostHocMethod | 'auto';          // default 'auto'
    adjust?: PAdjustMethod;                   // default 'holm'
    level?: number;                           // default 0.05
  },
): CovariateReport
```

A whole numeric covariate, end to end: descriptives, all three omnibus tests
(classic ANOVA, Welch's ANOVA, Kruskal–Wallis), effect sizes, Levene
(Brown–Forsythe) heteroscedasticity check, and a post-hoc. With
`method: 'auto'` (the default), Levene rejecting at .05 selects
`'gamesHowell'`, otherwise `'tukey'` — a default the caller can always
override.

*Available from:* root, stats.

### Example (run against the built library)

```js
const s = require('ladyna/stats');
const names = ['A', 'B', 'C'];
const groups = [
  [23.1, 25.4, 21.9, 24.8, 22.5, 26.0],
  [28.2, 30.1, 27.5, 29.9, 31.2, 28.8],
  [24.0, 26.3, 25.1, 27.7, 23.8, 25.5],
];

for (const r of s.tukeyHSD(names, groups)) {
  console.log(r.a + '-' + r.b, r.diff.toFixed(4), 'q=' + r.statistic.toFixed(4),
              'p=' + r.p.toFixed(6), 'g=' + r.effect.toFixed(4));
}
// A-B 5.3333 q=8.6666 p=0.000054 g=3.2197
// A-C 1.4500 q=2.3562 p=0.250082 g=0.8500
// B-C -3.8833 q=6.3104 p=0.001248 g=-2.5320

const rep = s.analyseCovariate('score', names, groups);
rep.method;                  // 'tukey'  (Levene p = 0.6077 → homoscedastic)
rep.heteroscedastic;         // false
rep.omnibus.anova.p;         // 0.000057339055691108545
rep.omnibus.welch.p;         // 0.0003438665188592644
rep.effects;                 // { eta2: 0.7281, omega2: 0.6795, epsilon2: 0.6942 } (rounded)
rep.describe[0];             // { group: 'A', n: 6, mean: 23.95, sd: 1.6766, ... }
rep.postHoc[0].p;            // 0.000054  (A-B, Tukey)
```

---

## Numeric column descriptives (codynaj lineage)

Ported verbatim from `codynaj` when the codyna package was retired
(2026-08-22), with its R-parity test fixtures (`tests/describe-r-groundtruth`).

### `quantileType7(values, prob)`

```ts
function quantileType7(values: number[], prob: number): number
```

Sample quantile with R's default algorithm (type 7): `h = (n-1)p`, linear
interpolation between order statistics. Non-finite values dropped; `NaN` on
empty input. Matches `quantile(x, prob, type = 7)`.

### `describeNumeric(columns)`

```ts
function describeNumeric(columns: NamedColumn[]): NumericSummary[]
// NumericSummary = { name, n, mean, sd, min, q1, median, q3, max }
```

One tidy row per named column. Quantiles are R type-7; `sd` is the sample sd
(n−1, R's `sd()`, `NaN` when n < 2); non-finite values dropped per column.

---

## Types

All exported from `ladyna/stats` (type-only; erased at runtime).

### `PAdjustMethod`

```ts
type PAdjustMethod = 'none' | 'bonferroni' | 'holm' | 'hochberg' | 'hommel' | 'BY' | 'fdr' | 'BH';
```

### Omnibus results

```ts
interface AnovaResult   { F: number; df1: number; df2: number; p: number; eta2: number }
interface WelchAnovaResult { F: number; df1: number; df2: number; p: number }
interface KruskalResult { H: number; df: number; p: number }
interface ChisqResult {
  X2: number; df: number; p: number; cramerV: number; n: number;
  expectedMin: number;        // smallest expected cell count (approximation check)
  residuals: number[][];      // standardized adjusted residuals of the (reduced) table
  dropped: boolean;           // true when all-zero rows/columns were removed
}
```

### Pairwise results

```ts
interface WelchPair { a: string; b: string; diff: number; t: number; df: number; p: number; pAdj?: number }
interface ChisqPair { a: string; b: string; X2: number; df: number; p: number; cramerV: number; pAdj?: number }

interface PostHocPair {
  a: string;
  b: string;
  diff: number;               // mean(b) − mean(a); mean-rank difference for Dunn
  statistic: number;          // q (Tukey/Games–Howell), t (Welch), z (Dunn)
  df: number | null;          // null for Dunn
  p: number;
  pAdj: number;               // === p for Tukey/Games–Howell (already familywise)
  ciLower: number | null;     // null for Dunn
  ciUpper: number | null;
  effect: number;             // Hedges' g for the pair
}

type PostHocMethod = 'tukey' | 'gamesHowell' | 'welch' | 'dunn';
```

### Descriptives and reports

```ts
interface Describe {
  group: string;
  n: number; mean: number; sd: number; se: number;
  median: number; q1: number; q3: number; iqr: number;
  min: number; max: number;
  ciLower: number;            // 95% CI of the MEAN (t-based), not a data range
  ciUpper: number;
}

interface EffectSizes {
  eta2: number;               // SS_between / SS_total (biased upward)
  omega2: number;             // bias-corrected; can be negative
  epsilon2: number | null;    // H / (N − 1); null when no Kruskal–Wallis result
}

interface OmnibusChoice {
  anova: AnovaResult | null;
  welch: WelchAnovaResult | null;
  kruskal: KruskalResult | null;
}

interface CovariateReport {
  covariate: string;
  describe: Describe[];
  omnibus: OmnibusChoice;
  effects: EffectSizes;
  postHoc: PostHocPair[];
  method: PostHocMethod;      // the method actually used (after 'auto' resolution)
  heteroscedastic: boolean;   // Levene (Brown–Forsythe) rejected at .05
}
```

---

## Column-wise data transforms

Ported from Dynalytics Desktop `src/views/corrnet.ts` `applyFreqTransform`.
These operate on a **data matrix** (rows = observations, columns = variables) —
a different thing from `applyScaling` / `rankScale` in `ladyna/core`, which
rescale a square network weight `Matrix`.

### `transformColumns(data, options)`

`data` is any `DataMatrix` — rows of `number[]` or `Float64Array`. The input is
never mutated; a fresh `Float64Array[]` is always returned.

| `transform` | behaviour |
|---|---|
| `'none'` | identity |
| `'standardize'` | z-score per column, sd using the **n−1** denominator |
| `'normalize'` | min–max onto `[0, 1]` per column |
| `'rank'` | 1-based ranks per column; ties get the **average** (fractional) rank |
| `'log'` | `log(x + 1)` — natural log, i.e. log1p |

Pass `columns` to name the variables; it defaults to `V1 … Vp` and is used for
the tidy `rows`.

Returns `{ transform, columns, matrix, rows }`, where `rows` is
`ColumnTransformRow[]`: one row per observation with `row` (0-based index) and
`values` (column name → value).

Average-tie ranking matches R's `rank(x, ties.method = "average")`: for a tie
block spanning sorted positions `i … j-1` every member gets `(i + j + 1) / 2`,
so `10, 20, 20, 20, 30` ranks as `1, 3, 3, 3, 5` and the ranks always sum to
`n(n+1)/2`.

Faithful-port notes, kept rather than "fixed":

- `'standardize'` leaves a column untouched when `sd <= 0` — which includes the
  `n = 1` case, where `sd` is `NaN` and the guard is false.
- `'normalize'` leaves a column untouched when `max === min`.
- `'log'` is unguarded: inputs below `-1` yield `NaN`, exactly `-1` yields
  `-Infinity`.
- Column width is taken from the first row.
- Unlike the source, `'none'` returns a fresh copy rather than the input
  reference — a container-identity difference only, never a numeric one.

Exported types: `ColumnTransform`, `ColumnTransformOptions`,
`ColumnTransformRow`, `ColumnTransformResult`, `DataMatrix`.

*Available from:* root, stats.
