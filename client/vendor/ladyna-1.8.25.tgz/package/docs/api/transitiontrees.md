# ladyna/transitiontrees — prediction suffix trees

Variable-order Markov modeling of sequence data as **prediction suffix trees**
(context trees): each node is a history ("context") of up to `maxDepth` recent
states, holding the observed next-state counts and a smoothed next-state
probability distribution. The module covers fitting, five smoothing methods,
four pruning criteria, prediction and scoring, pathway mining, gap imputation,
cross-validated tuning, permutation comparison, bootstrap stability, multi-group
inference, and twelve dependency-free SVG painters.

**R reference: `transitiontrees` 0.1.2.** Deterministic outputs are validated
against fixtures generated from that package
(`tests/transitiontrees-r-groundtruth.test.ts`). Seeded stochastic verbs
(`generateTreeSequences`, `compareTrees`, `tuneTree`, `bootstrapPathways`,
`compareGroups`, `imputeSequences` with `method: 'probability'`) use ladyna's
portable `SeededRNG`, so a given seed **replays identically across JavaScript
runtimes but does not reproduce R's random-number stream**. R equivalence for
the stochastic verbs is established through the replay hooks
(`BootstrapPathwaysOptions.indices`, `CompareGroupsOptions.labelPermutations`),
which feed R's realized draws into the estimator.

> **Available from: root `ladyna` and `ladyna/transitiontrees` only.** This module
> is **not** part of the `ladyna/light` or `ladyna/full` browser bundles (see
> [`docs/api/exports.md`](exports.md)); in a bundle-constrained environment
> import the `ladyna/transitiontrees` subpath directly. One exception inside the
> module: `factorLevels` is exported from `ladyna/transitiontrees` only, not
> re-exported from the root.

## Import

```typescript
// Root package (Node, Deno, Bun, bundlers):
import { contextTree, pruneTree, treePathways, plotTree } from 'ladyna';

// Dedicated subpath (same runtime exports, plus factorLevels):
import { contextTree, suffixChain, compareGroups } from 'ladyna/transitiontrees';
```

62 runtime exports; every one is documented below. Types are collected in
[Types](#types).

## End-to-end example

Fit a tree on toy sequences, inspect it, predict, and render an SVG. Runnable
as-is; the output shown is the actual output of this script.

```typescript
import {
  contextTree, treePathways, predictNext, treeModelFit, plotTree, nTreeNodes,
} from 'ladyna';

const sequences = [
  ['plan', 'discuss', 'execute', 'reflect', 'plan', 'discuss', 'execute'],
  ['plan', 'execute', 'reflect', 'plan', 'discuss', 'execute', 'reflect'],
  ['discuss', 'plan', 'discuss', 'execute', 'execute', 'reflect', 'plan'],
  ['plan', 'discuss', 'execute', 'execute', 'reflect', 'plan', 'discuss'],
  ['reflect', 'plan', 'discuss', 'execute', 'reflect', 'plan', 'execute'],
];

const tree = contextTree(sequences, { maxDepth: 3, minCount: 2 });
console.log('nodes:', nTreeNodes(tree));
console.log('alphabet:', tree.alphabet);
console.log('maxDepth (fitted):', tree.maxDepth);

console.table(treePathways(tree, { minCount: 3 }).slice(0, 5));

const p = predictNext(tree, ['plan', 'discuss']);
console.log('P(next | plan -> discuss):', [...p].map(v => v.toFixed(4)));

console.log('fit:', treeModelFit(tree));

const svg = plotTree(tree, { maxNodes: 12 });
console.log('svg starts with <svg:', svg.startsWith('<svg'), '· length', svg.length);
```

```text
nodes: 16
alphabet: [ 'discuss', 'execute', 'plan', 'reflect' ]
maxDepth (fitted): 3
┌─────────┬───────────┬───────┬───────┬────────────┬────────────────────┬────────────────────┬───────────────────┐
│ (index) │ pathway   │ depth │ count │ likelyNext │ nextProbability    │ divergence         │ changesPrediction │
├─────────┼───────────┼───────┼───────┼────────────┼────────────────────┼────────────────────┼───────────────────┤
│ 0       │ '(start)' │ 0     │ 35    │ 'execute'  │ 0.2857142857142857 │ NaN                │ null              │
│ 1       │ 'plan'    │ 1     │ 9     │ 'discuss'  │ 0.7756666666666667 │ 1.2710854225323855 │ true              │
│ 2       │ 'execute' │ 1     │ 8     │ 'reflect'  │ 0.748              │ 1.3593164259285373 │ true              │
│ 3       │ 'discuss' │ 1     │ 7     │ 'execute'  │ 0.8547142857142856 │ 1.1930445246359762 │ false             │
│ 4       │ 'reflect' │ 1     │ 6     │ 'plan'     │ 0.997              │ 1.7739724839782356 │ true              │
└─────────┴───────────┴───────┴───────┴────────────┴────────────────────┴────────────────────┴───────────────────┘
P(next | plan -> discuss): [ '0.0010', '0.9970', '0.0010', '0.0010' ]
fit: {
  value: -17.242955510220785,
  nObservations: 35,
  degreesOfFreedom: 48,
  aic: 130.48591102044156,
  bic: 205.14261797193342,
  perplexity: 1.6366572044403416
}
svg starts with <svg: true · length 6708
```

## Demo gallery

The runnable companion is [`demo/transitiontrees/`](../../demo/transitiontrees/index.html)
— nine browser pages plus the full visualization gallery, no build step needed:

| Page | Covers |
|---|---|
| [`index.html`](../../demo/transitiontrees/index.html) | Gallery hub |
| [`basic.html`](../../demo/transitiontrees/basic.html) | Fitting, node tables, subtrees |
| [`smoothing-pruning.html`](../../demo/transitiontrees/smoothing-pruning.html) | Five smoothers, four pruning criteria, suffix chains |
| [`prediction-scoring.html`](../../demo/transitiontrees/prediction-scoring.html) | Prediction, scoring, likelihood, generation |
| [`mining-imputation.html`](../../demo/transitiontrees/mining-imputation.html) | Pathway mining, sequence mining, gap imputation |
| [`tuning.html`](../../demo/transitiontrees/tuning.html) | Cross-validated hyperparameter search |
| [`comparison-bootstrap.html`](../../demo/transitiontrees/comparison-bootstrap.html) | Tree distance, permutation test, bootstrap stability |
| [`groups.html`](../../demo/transitiontrees/groups.html) | Grouped fitting and behavioral/usage comparison |
| [`forward-trajectories.html`](../../demo/transitiontrees/forward-trajectories.html) | Forward prefix trajectory flow tree |
| [`visualization.html`](../../demo/transitiontrees/visualization.html) | All twelve painters, light and dark |

---

## Fitting

### contextTree(input, options?)

```typescript
contextTree(input: ContextTreeInput, options: ContextTreeOptions = {}): ContextTree
```

Fits a prediction suffix tree. R: `context_tree()`.

- `input` — `SequenceData` (`Array<Array<string | null>>`), a `TNA` model, or a
  `TNAData` object. A `TNA` must carry its sequence data (`tna.data`); an
  aggregated matrix-only model throws.
- `options.maxDepth` (default `5`) — deepest context length (integer ≥ 0).
- `options.minCount` (default `5`) — minimum weighted count for a context at
  depth ≥ 1 to become a node (integer ≥ 1).
- `options.smoothing` (default `'floor'`) — a `SmoothingSpec`; see
  [resolveSmoothing](#resolvesmoothingspec).
- `options.alphabet` — explicit state set; defaults to the input's `labels`
  (for TNA input) or `sort(unique(states))` under ICU collation, matching R.
- `options.weights` — one non-negative finite weight per **input** row.
  All-equal weights collapse to `null` (unweighted).

Cleaning matches R's `.CT_MISSING`: `null`, `''`, `'%'` (TraMineR void), and
`'*'` (TraMineR missing) are non-observations; a row with no observation at all
is dropped. If some depth produces no surviving context, `maxDepth` on the
result is the deepest fitted depth, which may be lower than requested.

The result's `nodes` maps context keys (`"b -> a"` means the last two states
were `b` then `a`, most recent last) to `{ depth, counts, probability, count }`.
**Iterate contexts with [`nodeContexts(tree)`](#nodecontextstree), never
`Object.keys(tree.nodes)`** — JavaScript hoists integer-like keys, which
reorders numeric-coded alphabets relative to R.

### prepareTreeInput(data, options)

```typescript
prepareTreeInput(data: LongEventRow[], options: PrepareTreeInputOptions): PreparedTreeInput
```

Reshapes one-row-per-event long data into sequence rows, with optional session
splitting. R: `prepare_tree_input()`.

- `options.action` (required) — column holding the state/action.
- `options.actor` — one column name or several (joined with `-`) identifying
  the actor; omitted means a single pooled actor.
- `options.time` — timestamp column (`number` in `unixTimeUnit`, `Date`, or a
  `Date.parse`-able string).
- `options.order` — explicit ordering column (fallback: input order).
- `options.session` — explicit session column; otherwise sessions are split
  where the actor changes or the time gap exceeds `timeThreshold`.
- `options.timeThreshold` (default `900` seconds) — session-break gap.
- `options.unixTimeUnit` (default `'seconds'`) — `'seconds' | 'milliseconds' | 'microseconds'`.
- `options.metadata` — columns copied (first row per session) into `metadata`.

Returns `{ sequences, sessionIds, metadata }` with rows null-padded to equal
length — ready for `contextTree()`.

### subtree(tree, pathway)

```typescript
subtree(tree: ContextTree, pathway: Pathway): ContextTree
```

The tree restricted to `pathway` and all of its descendants. The result carries
`localRoot` so the painters root the layout there. Throws if `pathway` is not a
node. R: `subtree()`.

### nTreeNodes(tree)

```typescript
nTreeNodes(tree: ContextTree): number
```

Number of contexts in the tree (root included). R: `n_nodes()`.

### Constants

```typescript
ROOT_CONTEXT   // '<root>'   — internal key of the root node
ROOT_PATHWAY   // '(start)'  — how the root is spelled in tables and plots
PATH_SEPARATOR // ' -> '     — joins states inside a context key
```

Pathway arguments accept `'(start)'`, `'(root)'`, `'<root>'`, an empty array,
or a `' -> '`-joined string / string array for deeper contexts.

### matchContext(tree, history)

```typescript
matchContext(tree: ContextTree, history: readonly (string | null)[]): string
```

Longest-suffix rule: the deepest fitted context that is a suffix of `history`
(nulls and `''` skipped), falling back to `ROOT_CONTEXT`. This is the backoff
used by every prediction verb.

### parentContext(context)

```typescript
parentContext(context: string): string | null
```

One-shorter context (drop the oldest state): parent of `'b -> a'` is `'a'`,
parent of `'a'` is `ROOT_CONTEXT`, parent of `ROOT_CONTEXT` is `null`.

### isObserved(state)

```typescript
isObserved(state: string | null | undefined): state is string
```

`true` when `state` is a real observation — i.e. not `null`, `undefined`, `''`,
`'%'`, or `'*'` (R `.CT_MISSING` plus `NA`).

### survivingRows(data)

```typescript
survivingRows(data: SequenceData): number[]
```

Indices of the input rows that survive `contextTree()`'s cleaning (rows with at
least one observation). Use this to align per-sequence covariates (weights,
block) with a fitted tree, whose `data`/`weights` only contain survivors.

### nodeContexts(tree)

```typescript
nodeContexts(tree: { nodes: Record<string, unknown>; nodeKeys?: string[] }): string[]
```

Context keys in R's insertion order (`names(tree$nodes)`). Always use this
instead of `Object.keys(tree.nodes)` — with a numeric-coded alphabet JS hoists
integer-like keys to the front and every derived table reorders.

### factorLevels(values)

```typescript
factorLevels(values: readonly (string | number)[]): string[]
```

R `factor()` level order for a vector — the group order used by
`contextTreeGroups()`. **Exported from `ladyna/transitiontrees` only** (not
re-exported from the root).

## Smoothing & pruning

### resolveSmoothing(spec?)

```typescript
resolveSmoothing(spec: SmoothingSpec = 'floor'): ResolvedSmoothing
```

Normalizes a smoothing spec (string shorthand or object) into a fully
parameterized form, validating ranges. The five methods and their defaults:

| Method | Spec | Defaults |
|---|---|---|
| Floor | `{ method: 'floor', ymin?, rule? }` | `ymin: 0.001`, `rule: 'interpolate'` |
| Laplace | `{ method: 'laplace', alpha? }` | `alpha: 1` |
| Kneser–Ney | `{ method: 'kneser_ney', discount? }` | `discount: 0.75` |
| Witten–Bell | `{ method: 'witten_bell' }` | — |
| Jelinek–Mercer | `{ method: 'jelinek_mercer', lambda? }` | `lambda: 0.5` |

`floor` with `rule: 'interpolate'` requires `ymin < 1/alphabetSize` (throws
otherwise) and only rescales when a zero cell exists; `rule: 'cap'` clamps to
`ymin` and renormalizes. Kneser–Ney, Witten–Bell, and Jelinek–Mercer back off
to the nearest fitted ancestor's distribution (uniform at the root).

### smoothCounts(counts, smoothing, parentProbability)

```typescript
smoothCounts(
  counts: Float64Array,
  smoothing: ResolvedSmoothing,
  parentProbability: Float64Array | null,
): Float64Array
```

The single-node smoothing kernel: turns raw next-state counts into a
probability vector. A zero-count node returns the parent (or uniform)
distribution unchanged. Exposed for testing and custom pipelines; `contextTree`
and `smoothTree` call it for you.

### smoothTree(tree, smoothingSpec?)

```typescript
smoothTree(tree: ContextTree, smoothingSpec: SmoothingSpec = 'floor'): ContextTree
```

Re-smooths an already-fitted tree with a different method, recomputing every
node's `probability` from its stored `counts` top-down (so backoff methods see
the freshly smoothed parents). Counts, structure, and metadata are untouched.
R: `smooth_tree()`.

### pruneTree(tree, options?)

```typescript
pruneTree(tree: ContextTree, options: PruneTreeOptions = {}): ContextTree
```

Iteratively removes uninformative leaves until every remaining leaf earns its
depth. R: `prune_tree()`.

- `options.criterion` (default `'G2'`) — `'G2' | 'KL' | 'AIC' | 'BIC'`:
  - `G2` — keep a leaf whose G² against its parent's distribution exceeds the
    χ² critical value at `alpha` with `alphabetSize − 1` df;
  - `KL` — keep when KL(child ‖ parent) exceeds `threshold`;
  - `AIC` / `BIC` — keep when the penalized child likelihood beats the parent.
- `options.alpha` (default `0.05`) — G² significance level, in (0, 1).
- `options.threshold` (default `0.005`) — KL cutoff, ≥ 0.

Returns a new tree with `pruned: true` and `pruning: { criterion, alpha, threshold }`.

### compareSmoothing(input, options?)

```typescript
compareSmoothing(
  input: ContextTree | Array<Array<string | null>>,
  options: Omit<ContextTreeOptions, 'smoothing'> & { smoothing?: SmoothingMethod[] } = {},
): CompareSmoothingRow[]
```

One row per smoothing method (default: all five) — `{ smoothing, nNodes,
perplexity }`. Given raw sequences it refits per method; given a fitted tree it
re-smooths it. R: `compare_smoothing()`.

### comparePruning(tree, options?)

```typescript
comparePruning(
  tree: ContextTree,
  options: { criteria?: PruningCriterion[]; alpha?: number; threshold?: number } = {},
): ComparePruningRow[]
```

One row per pruning criterion (default: all four) — `{ criterion, nNodes,
reductionPercent }`. `reductionPercent` uses R's `round()` (half-to-even) to
one decimal. R: `compare_pruning()`.

### suffixChain(tree, pathway, options?)

```typescript
suffixChain(
  tree: ContextTree,
  pathway: string | readonly string[],
  options: { alpha?: number } = {},
): SuffixChainRow[]
```

The memory-length diagnostic behind pruning (R
`transitiontrees:::.suffix_chain`). Walks the pathway's suffixes from the full
context down to the root and G²-tests each against its one-shorter parent.
Returns one row per (chain link × alphabet state) with `L` (memory length),
`context`, `label`, `state`, `probability`, `count`, `g2`, `diverges`, and a
`status` classification:

- `informative` — its own G² clears the χ²(`alpha`, k−1) cutoff;
- `pruned` — it **and every deeper link** fail to diverge (the redundant tail —
  R's `cumprod(!diverges) == 1`, not a per-link threshold);
- `retained` — below the cutoff itself, but kept as a bridge because a deeper
  link diverges;
- `root` — the root, which has no parent to test.

`options.alpha` defaults to `0.05`. Throws if the requested pathway is not a
fitted context, or if its suffix chain is not contiguous in the tree.

## Prediction & scoring

### predictNext(tree, history)

```typescript
predictNext(tree: ContextTree, history: readonly (string | null)[]): Float64Array
```

Next-state probability vector (alphabet order) for a single history, using the
longest fitted suffix (`matchContext`).

### predictTree(tree, histories, options?)

```typescript
predictTree(tree, histories, options: PredictTreeOptions & { type: 'class' }): string[]
predictTree(tree, histories, options?: PredictTreeOptions): Float64Array[]
```

Vectorized prediction over many histories. `options.type` (default
`'probability'`) — `'probability'` returns one `Float64Array` per history,
`'class'` returns the modal next state per history. R: `predict()`.

### queryPathway(tree, pathway, options?)

```typescript
queryPathway(tree, pathway, options: QueryPathwayOptions & { nextState: string }): number
queryPathway(tree, pathway, options?: QueryPathwayOptions): Float64Array
```

Look up the next-state distribution after `pathway`. With `nextState` returns
that single probability (throws if the state is not in the alphabet). With
`exact: true` an unfitted pathway yields `NaN`s instead of backing off to the
longest fitted suffix. R: `query_pathway()`.

### pathwayExists(tree, pathway)

```typescript
pathwayExists(tree: ContextTree, pathway: Pathway): boolean
```

Whether `pathway` is a fitted context node.

### scorePositions(tree, newData, options?)

```typescript
scorePositions(
  tree: ContextTree,
  newData: readonly (readonly (string | null)[])[],
  options: { worst?: number } = {},
): ScorePositionRow[]
```

Per-position held-out scoring: for every observed position, the matched
context, assigned probability, and log-likelihood (−∞ when the model assigned
zero). Positions whose state is outside the alphabet are skipped. `worst: n`
returns only the n lowest-probability (most surprising) positions.
`sequenceId` and `position` are 1-based, matching R. R: `score_positions()`.

### scoreSequences(tree, newData)

```typescript
scoreSequences(tree, newData: readonly (readonly (string | null)[])[]): ScoreSequenceRow[]
```

Per-sequence rollup of `scorePositions`: `{ sequenceId, nScored,
logLikelihood, perplexity }`. R: `score_sequences()`.

### treeLogLikelihood(tree, newData?)

```typescript
treeLogLikelihood(
  tree: ContextTree,
  newData?: readonly (readonly (string | null)[])[],
): TreeLogLikelihood
```

Without `newData`: in-sample log-likelihood, attributing each observation to
its **deepest** fitted context (child counts are subtracted from ancestors so
nothing is counted twice). With `newData`: sum over `scorePositions`.
`degreesOfFreedom` is `nNodes × (alphabetSize − 1)`. R: `logLik()`.

### treePerplexity(tree, newData?)

```typescript
treePerplexity(tree: ContextTree, newData?): number
```

`exp(−logLik / n)`; `NaN` when nothing was scored. R: `perplexity()`.

### treeModelFit(tree, newData?)

```typescript
treeModelFit(tree: ContextTree, newData?): TreeModelFit
```

`treeLogLikelihood` plus `aic`, `bic`, and `perplexity`. All `NaN` when
nothing was scored. R: `model_fit()`.

### generateTreeSequences(tree, options?)

```typescript
generateTreeSequences(tree: ContextTree, options: GenerateTreeOptions = {}): string[][]
```

Simulates sequences from the tree, always predicting from the longest fitted
suffix. `n` (default `5`), `length` (default `10`), `start` (optional first
state per sequence, must have length `n`), `seed` (default `1`). Seeded and
replayable across JS runtimes; **does not reproduce R's stream**.
R: `simulate()`.

## Mining & imputation

### treePathways(tree, options?)

```typescript
treePathways(tree: ContextTree, options: TreePathwaysOptions = {}): PathwayRow[]
```

The tree as a tidy table — one row per context: `pathway` (`'(start)'` for the
root), `depth`, `count`, `likelyNext`, `nextProbability`, `divergence` (KL in
bits from the parent's distribution; `NaN` at the root), `changesPrediction`
(modal state differs from parent's; `null` at the root).

- `options.minCount` (default `1`), `options.sortBy` (default `'count'`,
  or `'divergence'` / `'depth'`), `options.decreasing` (default `true`).

R: `as.data.frame()` / `pathways()`.

### commonPathways(tree, options?)

```typescript
commonPathways(tree: ContextTree, options: CommonPathwaysOptions = {}): PathwayRow[]
```

Top pathways by count. `top` (default `10`), `depth` (keep only that depth),
`minCount`. R: `common_pathways()`.

### divergentPathways(tree, options?)

```typescript
divergentPathways(tree: ContextTree, options: DivergentPathwaysOptions = {}): PathwayRow[]
```

Top pathways by KL divergence from the parent (root excluded). `top` (default
`10`), `minCount`, `flipsOnly` (only contexts whose modal prediction differs
from the parent's). R: `divergent_pathways()`.

### sharpPathways(tree, options?)

```typescript
sharpPathways(tree: ContextTree, options: { top?: number; minCount?: number } = {}): PathwayRow[]
```

Top pathways by modal next-state probability — the most deterministic contexts.
`top` default `10`. R: `sharp_pathways()`.

### treeDependence(tree, options?)

```typescript
treeDependence(
  tree: ContextTree,
  options: {
    base?: number;
    sortBy?: 'divergence' | 'entropyDrop' | 'entropy' | 'count' | 'depth';
    top?: number;
  } = {},
): TreeDependenceRow[]
```

Sequential-dependence diagnostics per non-root context: KL divergence from the
parent, entropy before/after conditioning, `entropyDrop`, and modal-prediction
flip. `base` (default `2`, must be positive and ≠ 1) sets the logarithm base;
`sortBy` defaults to `'divergence'`. R: `dependence()`.

### mineContexts(tree, state, options?)

```typescript
mineContexts(tree: ContextTree, state: string, options: MineContextsOptions = {}): MineContextRow[]
```

Every context's probability of a **given next state**, sorted by probability
then count — "after which histories does `state` follow?". `minProbability`
(default `0`), `maxProbability` (default `1`), `minCount` (default `1`).
Throws if `state` is not in the alphabet. R: `mine_contexts()`.

### mineSequences(tree, newData, options?)

```typescript
mineSequences(tree, newData, options: MineSequencesOptions = {}): ScoreSequenceRow[]
```

The `n` (default `10`) most `'surprising'` (highest perplexity, default) or
most `'expected'` sequences in `newData` under the tree. R: `mine_sequences()`.

### imputeSequences(tree, newData, options?)

```typescript
imputeSequences(tree, newData: NullableSequenceData, options?): Array<Array<string | null>>
imputeSequences(tree, newData: NullableSequence, options?): Array<string | null>
// options: { method?: 'modal' | 'probability'; seed?: number }
```

Fills **internal** gaps (`null` / `''`) left to right using the tree's
predictions; trailing gaps are left unchanged. `method: 'modal'` (default)
takes the most likely state; `'probability'` draws from the predicted
distribution using `seed` (default `1`; replayable, not R's stream). Accepts a
single sequence or many. R: `impute()`.

## Tuning

### tuneTree(data, options?)

```typescript
tuneTree(data: Array<Array<string | null>>, options: TuneTreeOptions = {}): TuneTreeResult
```

K-fold cross-validated grid search over the full hyperparameter cross product.
R: `tune_tree()`.

- `options.maxDepth` (default `[2, 3, 4, 5]`)
- `options.minCount` (default `[3, 5, 10]`)
- `options.smoothing` (default `['floor']`) — `SmoothingSpec[]`
- `options.prune` (default `[false, true]`) — pruning uses `G2` with
  `options.alpha` (default `0.05`)
- `options.folds` (default `5`, integer ≥ 2; throws if `data.length < folds`)
- `options.seed` (default `1`) — fold assignment (replayable, not R's stream)
- `options.alphabet` — shared alphabet (default: sorted unique states)

Returns `{ rows, best }`: one `TuneTreeRow` per combination — pooled held-out
`logLikelihood`, `nScored`, `perplexity`, `nNodesAverage`, `foldsFailed` —
sorted by perplexity (ascending, `NaN` last). `best` is the first row with
`foldsFailed === 0` and finite perplexity, or `null`. Render with
[`plotTuning`](#plottuningresult-options).

## Comparison & bootstrap

### treeDistanceBreakdown(treeA, treeB)

```typescript
treeDistanceBreakdown(treeA: ContextTree, treeB: ContextTree): TreeDistanceRow[]
```

Per-context comparison over the union of both trees' contexts (a context
missing from one tree backs off to its longest fitted suffix there): counts in
each tree, KL in both directions, and the symmetrized mean. Throws on
incompatible alphabets. R: `tree_distance(..., breakdown = TRUE)`.

### treeDistance(treeA, treeB, options?)

```typescript
treeDistance(treeA: ContextTree, treeB: ContextTree, options: { symmetric?: boolean } = {}): number
```

Count-weighted mean divergence over the breakdown (`symmetric` default
`true`). Zero-weight contexts are masked out before the weighted sum, matching
R — otherwise an infinite divergence at zero weight would poison the scalar
with `NaN`. R: `tree_distance()`.

### compareTrees(treeA, treeB, options?)

```typescript
compareTrees(treeA: ContextTree, treeB: ContextTree, options: CompareTreesOptions = {}): TreeComparison
```

Permutation test of the tree distance: pools both trees' sequences, reshuffles
the split `iterations` times (default `200`), and refits each side with its own
template settings (including pruning, when the template was pruned). Returns
`{ distance, nullDistribution, pValue, pathways }` with the add-one p-value
`(1 + #{null ≥ observed}) / (iterations + 1)` and the per-context breakdown
sorted by symmetric divergence. `seed` default `1` (replayable, not R's
stream); `symmetric` default `true`. Throws on incompatible alphabets or
weighted trees. Render with [`plotComparison`](#plotcomparisonresult-options).
R: `compare_trees()`.

### bootstrapPathways(tree, options?)

```typescript
bootstrapPathways(tree: ContextTree, options: BootstrapPathwaysOptions = {}): BootstrapPathwaysResult
```

Case-resampling bootstrap of pathway stability. Resamples the tree's sequences
with replacement and recomputes each context's raw statistics per iteration.
R: `bootstrap_pathways()`. Throws for weighted trees.

- `iterations` (default `1000`, integer ≥ 2), `seed` (default `1`).
- `statistic` (default `'count'`) — which statistic drives the stability rate:
  `'count' | 'nextProbability' | 'divergence'`.
- `consistencyRange` (default `[0.5, 1.5]`) — a resample is "consistent" when
  its statistic lands within `observed × range`.
- `stabilityThreshold` (default `0.95`) — `stable` when
  `pStability < 1 − stabilityThreshold`.
- `informativeThreshold` (default `0.8`) — `informative` when the share of
  resamples whose G² clears the χ² critical value (at `alpha`, default `0.05`)
  reaches this rate.
- `ciLevel` (default `0.05`) — **total tail mass**: CIs are the
  `[ciLevel/2, 1 − ciLevel/2]` resample quantiles (so `0.05` ⇒ 95% CI).
- `keepResamples` (default `true`) — set `false` to drop the raw resample
  matrices (`result.resamples` becomes `null`;
  [`plotPathwayResamples`](#plotpathwayresamplesresult-options) will then throw).
- `indices` — **replay hook for R equivalence**: one row of zero-based
  sequence indices per iteration, captured from R's `sample()`. R's RNG cannot
  be matched by any seed here; supplying R's realized indices compares the
  estimator instead of the sampler.

Returns empirical per-pathway rows, a `summary` (means, SDs, CIs, stability /
informativeness / flip-consistency rates, sorted most-trustworthy-first), the
resample matrices, and all resolved settings including `g2CriticalValue`.

## Groups

### contextTreeGroups(data, groups, options?)

```typescript
contextTreeGroups(
  data: Array<Array<string | null>>,
  groups: readonly (string | number)[],
  options: ContextTreeOptions & { block?: Array<string | number>; groupVariable?: string } = {},
): ContextTreeGroup
```

Fits one tree per group (group order = R `factor()` levels, see
[`factorLevels`](#factorlevelsvalues)) over a shared alphabet. `groups`,
`block`, and `weights` must each have one value per sequence. `block` (for
stratified permutation in `compareGroups`) is re-indexed to the pooled
group-then-surviving-row order, matching R's `.ct_fit_grouped`.
R: `context_tree(..., group = ...)`.

### smoothTreeGroup(group, smoothing?)

```typescript
smoothTreeGroup(group: ContextTreeGroup, smoothing: SmoothingSpec = 'floor'): ContextTreeGroup
```

`smoothTree` applied to every member tree, preserving group order and metadata.
R: `smooth_tree()` S3 method for groups.

### pruneTreeGroup(group, options?)

```typescript
pruneTreeGroup(group: ContextTreeGroup, options: PruneTreeOptions = {}): ContextTreeGroup
```

`pruneTree` over every member tree. R: `prune_tree()` group method.

### treeModelFitGroup(group, newData?)

```typescript
treeModelFitGroup(
  group: ContextTreeGroup,
  newData?: Array<Array<string | null>>,
): Array<TreeModelFit & { group: string }>
```

One fit row per group with a leading `group` column, as R returns.
R: `model_fit()` group method.

### nTreeNodesGroup(group)

```typescript
nTreeNodesGroup(group: ContextTreeGroup): Record<string, number>
```

Node counts keyed by group name (R returns a named integer vector).
R: `n_nodes()` group method.

### groupPathways(group, options?)

```typescript
groupPathways(group: ContextTreeGroup, options: TreePathwaysOptions = {}): Array<PathwayRow & { group: string }>
```

Every member's pathway table, stacked, with a leading `group` column.
R: `as.data.frame()` group method.

### compareGroups(group, options?)

```typescript
compareGroups(group: ContextTreeGroup, options: CompareGroupsOptions = {}): GroupComparison
```

Permutation inference over ≥ 2 groups along two axes — **behavioral** (does the
next-state distribution after a context differ? per-context Jensen–Shannon
divergence in bits, plus a count-weighted omnibus) and **usage** (is the
context visited at different rates? per-context 2×k G² against depth-matched
opportunities, plus a sum-G² omnibus). R: `compare_groups()`.

- `iterations` (default `999`), `seed` (default `1`; replayable, not R's
  stream), `minCount` (default `1`) — drop pathways below this pooled count.
- `block` (default: the group's own `block`) — stratified permutation: labels
  are shuffled **within** each block.
- `labelPermutations` — **replay hook for R equivalence**: one permuted
  group-label vector per iteration, captured from R. Labels rather than
  indices, because R permutes the assignment directly, and a stratified
  shuffle cannot be expressed as an index permutation.

Returns per-pathway rows (counts and modal next state per group, `flips`,
JSD/usage statistics with permutation and BH-adjusted p-values), the two
omnibus rows, a pairwise `treeDistance` matrix, and the resolved settings.
Throws for weighted trees or fewer than two groups.

## Visualization

Twelve painters. Each returns a **self-contained SVG string** — no D3, no DOM,
no external assets — sized by `viewBox` with `width="100%"`, with a `<style>`
block and CSS variables scoped inside the SVG. All accept the shared
`SVGPlotOptions`:

```typescript
interface SVGPlotOptions {
  width?: number;    // per-painter default, typically 900–980
  height?: number;   // per-painter default, several grow with row count
  title?: string;    // heading drawn inside the SVG
  theme?: 'dark' | 'light';  // default 'light' (white background)
}
```

Insert the returned string with `element.innerHTML = svg` or save it as an
`.svg` file. See
[`demo/transitiontrees/visualization.html`](../../demo/transitiontrees/visualization.html)
for every painter in both themes.

Four painters validate their input and **throw** instead of drawing an empty
frame: [`plotPruning`](#plotpruningtree-pathway-pruned-options) (pathway not in
the source tree), [`plotTrajectories`](#plottrajectoriestree-options) (no
prefix meets `minCount`),
[`plotPathwayResamples`](#plotpathwayresamplesresult-options) (bootstrap run
with `keepResamples: false`), and
[`plotGroupDifference`](#plotgroupdifferencetrees-options) (fewer than two
valid groups).

### plotTree(tree, options?)

```typescript
plotTree(tree: ContextTree, options: TreePlotOptions = {}): string
```

The tree itself. `style` (default `'horizontal'`): `'horizontal'` phylogram,
`'dendrogram'` (radial), or `'icicle'` (count-proportional partition).
`showLabels` (default `true`); `maxNodes` caps the horizontal style to the
highest-count contexts — count monotonicity makes the kept set ancestor-closed,
so it is always a connected subtree. Node size/edge width encode counts, node
color encodes the most recent state. Also renders a `subtree()` from its
`localRoot`.

### plotPathways(tree, options?)

```typescript
plotPathways(tree: ContextTree, options: PathwayPlotOptions = {}): string
```

Next-state probability heatmap: one row per pathway, one column per state, the
modal cell in bold, `› ` marking prediction flips. `top` (default `12`),
`sortBy` (default `'count'`), `minCount`.

### plotDivergence(tree, options?)

```typescript
plotDivergence(tree: ContextTree, options: PathwayPlotOptions = {}): string
```

Lollipop chart of KL divergence from the shorter-history prediction, orange
dots marking contexts that flip the modal prediction. `top` (default `12`),
`minCount`.

### plotDistributions(tree, options?)

```typescript
plotDistributions(tree: ContextTree, options: PathwayPlotOptions = {}): string
```

Stacked 100% probability bars, one per context, with a state legend. `top`
(default `8`), `sortBy` (default `'count'`), `minCount`.

### plotPruning(tree, pathway, pruned, options?)

```typescript
plotPruning(tree: ContextTree, pathway: string, pruned: ContextTree, options: SVGPlotOptions = {}): string
```

Suffix-memory diagnostic: the pathway's full suffix chain from `tree`, each
link's distribution drawn bright when the node survives in `pruned` and dimmed
when pruned away. **Throws** if `pathway` is not a node of the source tree.
Compute the underlying statistics with [`suffixChain`](#suffixchaintree-pathway-options).

### plotPredictive(tree, data, options?)

```typescript
plotPredictive(
  tree: ContextTree,
  data: readonly (readonly (string | null)[])[],
  options: SVGPlotOptions & { type?: 'logloss' | 'ecdf' | 'position' } = {},
): string
```

Held-out predictive performance from `scorePositions`. `type` (default
`'logloss'`): per-position log loss in bits with the uniform-prediction
baseline dashed; `'ecdf'` of assigned probability; `'position'` — one
confidence polyline per sequence.

### plotTrajectories(tree, options?)

```typescript
plotTrajectories(
  tree: ContextTree,
  options: SVGPlotOptions & {
    measure?: 'frequency' | 'predictability';
    minCount?: number;
    maxDepth?: number;
  } = {},
): string
```

Forward prefix trajectory flow tree over the **training data**: prefixes
occurring at least `minCount` (default `4`) times, ribbon width encoding flow,
node color encoding sequence frequency (`measure: 'frequency'`, default) or the
tree's conditional probability of that move (`'predictability'`). `maxDepth`
defaults to the longest sequence. **Throws** when no forward prefix reaches
`minCount`.

### plotBootstrap(result, options?)

```typescript
plotBootstrap(result: BootstrapPathwaysResult, options: SVGPlotOptions & { top?: number } = {}): string
```

Forest plot of bootstrap G² CIs against the χ² critical value, colored by the
stable/informative classification. `top` (default `14`).

### plotPathwayResamples(result, options?)

```typescript
plotPathwayResamples(
  result: BootstrapPathwaysResult,
  options: SVGPlotOptions & {
    statistic?: 'count' | 'nextProbability' | 'divergence' | 'g2';
    top?: number;
  } = {},
): string
```

Small-multiple histograms of the raw resample distributions per pathway.
`statistic` (default `'divergence'`), `top` (default `6`). **Throws** when
`result.resamples` is `null` (bootstrap run with `keepResamples: false`).

### plotComparison(result, options?)

```typescript
plotComparison(result: TreeComparison, options: SVGPlotOptions = {}): string
```

Permutation null distribution from `compareTrees` as a histogram, the observed
distance as an orange line, p-value in the title.

### plotTuning(result, options?)

```typescript
plotTuning(result: TuneTreeResult, options: SVGPlotOptions = {}): string
```

Cross-validated perplexity from `tuneTree` versus maximum depth, one line per
smoothing × minCount × pruning combination, the best configuration starred.

### plotGroupDifference(trees, options?)

```typescript
plotGroupDifference(
  trees: Record<string, ContextTree>,
  options: SVGPlotOptions & { depth?: number; groups?: [string, string] } = {},
): string
```

Signed heatmap of next-state probability differences (second group − first)
for all contexts at `depth` (default `1`). `groups` picks the pair (default:
the first two keys of `trees`); pass `group.trees` from `contextTreeGroups()`.
**Throws** unless exactly two valid groups resolve.

## Types

All 57 type exports, available from `ladyna/transitiontrees`.

**Fitting**

- `ContextTreeInput` — `SequenceData | TNA | TNAData`.
- `ContextTreeOptions` — `{ maxDepth?, minCount?, smoothing?, alphabet?, weights? }`.
- `ContextTree` — the fitted model: `nodes`, `nodeKeys` (R's insertion order —
  iterate with `nodeContexts`), `edges`, `alphabet`, `maxDepth`, `minCount`,
  `nSequences`, `nObservations`, `smoothing`, `pruned`, `pruning`, `data`
  (cleaned surviving sequences), `weights`, optional `localRoot` (set by
  `subtree`).
- `ContextTreeNode` — `{ depth, counts: Float64Array, probability: Float64Array, count }`.
- `ContextTreeEdge` — `{ parent, child, symbol }`.
- `Pathway` — `string | string[]`; `History` — alias of `Sequence`.

**Smoothing & pruning**

- `SmoothingMethod` — `'floor' | 'laplace' | 'kneser_ney' | 'witten_bell' | 'jelinek_mercer'`.
- `SmoothingSpec` — a `SmoothingMethod` or a parameterized object;
  `FloorRule` — `'interpolate' | 'cap'`; `ResolvedSmoothing` — fully
  parameterized form.
- `PruningCriterion` — `'G2' | 'KL' | 'AIC' | 'BIC'`;
  `PruneTreeOptions` — `{ criterion?, alpha?, threshold? }`;
  `ContextTreePruning` — the record stored on a pruned tree.
- `CompareSmoothingRow`, `ComparePruningRow` — rows of the two workflow tables.
- `SuffixChainRow`, `SuffixLinkStatus` (`'informative' | 'pruned' | 'retained' | 'root'`)
  — `suffixChain` output.

**Prediction & scoring**

- `QueryPathwayOptions` — `{ nextState?, exact? }`;
  `PredictTreeOptions` — `{ type?: 'probability' | 'class' }`;
  `GenerateTreeOptions` — `{ n?, length?, start?, seed? }`.
- `ScorePositionRow`, `ScoreSequenceRow` — scoring rows.
- `TreeLogLikelihood` — `{ value, nObservations, degreesOfFreedom }`;
  `TreeModelFit` — extends it with `aic`, `bic`, `perplexity`.

**Mining & pathways**

- `PathwayRow` — the shared pathway-table row;
  `TreePathwaysOptions`, `CommonPathwaysOptions`, `DivergentPathwaysOptions` —
  their option bags.
- `TreeDependenceRow` — `treeDependence` row.
- `MineContextRow`, `MineContextsOptions`, `MineSequencesOptions` — mining.

**Tuning, comparison & bootstrap**

- `TuneTreeOptions`, `TuneTreeRow`, `TuneTreeResult` — `tuneTree`.
- `TreeDistanceRow`, `CompareTreesOptions`, `TreeComparison` — comparison.
- `BootstrapPathwayStatistic` — `'count' | 'nextProbability' | 'divergence'`;
  `BootstrapPathwaysOptions` (including the `indices` replay hook),
  `EmpiricalPathwayRow`, `BootstrapPathwayRow`, `BootstrapResamples`,
  `BootstrapPathwaysResult` — bootstrap.

**Long input & groups**

- `LongEventRow`, `PrepareTreeInputOptions`, `PreparedTreeInput` —
  `prepareTreeInput`.
- `ContextTreeGroup` — `{ trees, groupNames, groupVariable?, block? }`.
- `CompareGroupsOptions` (including the `labelPermutations` replay hook),
  `GroupPathwayRow`, `GroupOmnibusRow`, `GroupComparison` — `compareGroups`.

**Visualization**

- `SVGPlotOptions` — `{ width?, height?, title?, theme?: 'dark' | 'light' }`
  (default theme `'light'`).
- `TreePlotOptions` — extends `SVGPlotOptions` with
  `{ style?: TreePlotStyle, showLabels?, maxNodes? }`;
  `TreePlotStyle` — `'horizontal' | 'dendrogram' | 'icicle'`.
- `PathwayPlotOptions` — extends `SVGPlotOptions` with
  `{ top?, sortBy?, minCount? }`.
