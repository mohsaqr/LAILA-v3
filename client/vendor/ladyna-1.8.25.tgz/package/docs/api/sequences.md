# ladyna/sequences — TraMineR sequence indicators

Sequence-level analysis on **wide-format state sequences** (rows = cases,
columns = time points), as opposed to `src/analysis/`, which operates on TNA
models. The module has two provenances, kept under their own references:

- **R `TraMineR` 2.2.13** — `seqindic()` with all 28 longitudinal indicators,
  the standalone indicator verbs (`seqivardur`, `seqsubsn`, `seqST`,
  `seqipos`), the precarity family (`seqidegrad`, `seqibad`, `seqprecarity`,
  `seqinsecurity`), dissimilarity (`seqdist`, `seqcost`), and discrepancy
  analysis (`dissvar`, `disscenter`, `dissassoc`). R-parity is pinned by
  fixture tests at **1e-12** (`tests/seqindic-r-groundtruth.test.ts` 42/42,
  `tests/seqdist-r-groundtruth.test.ts` 75/75). Two documented exceptions:
  `dissassoc`'s Bartlett statistic and its permutation p-values (see
  [`dissassoc()`](#dissassoc)).
- **R `WeightedCluster` 1.8.1** — `clusterQuality()`
  (`wcClusterQuality`) and `aggregateCases()` (`wcAggregateCases`), pinned by
  `tests/cluster-quality-r-groundtruth.test.ts`.
- **R `codyna`** — the 24 structural indices (`sequenceIndices`), pattern
  discovery (`discoverPatterns`), format conversion (`convert`), the
  preparation pipeline (`prepareSequenceData`, `rle`, `extractLast`,
  `chiSqUpperTail`, `sequenceTransitions`), and the descriptives
  (`sequenceStateDistribution`, `sequenceStateFrequencies`, `meanTimeInState`,
  `modalSequence`, `entropyProfile`, `sequenceFrequencies`). These were
  absorbed from the standalone `codynaj` package and validate against R
  `codyna`, **not** TraMineR — their conventions (notably entropy) differ by
  design.

Three entropy conventions coexist deliberately, each matching its own
reference: `seqindic`'s `Entr` uses natural log normalised by ln(a);
`entropyProfile` uses log2 normalised by log2(a); `sequenceIndices` counts
missing as a state. Do not unify them.

`with.missing = TRUE` (missing treated as a state) is not supported anywhere
in this module.

## Import

```js
import { seqindic, seqdist, clusterQuality /* … */ } from 'ladyna';
// or the dedicated subpath:
import { seqindic } from 'ladyna/sequences';
```

**Available from:** every runtime export below is importable from the package
root (`ladyna`) and from `ladyna/sequences`. **None of them is on `ladyna/full`**,
and `ladyna/light` carries only the codyna-era subset (`prepareSequenceData`,
`rle`, `extractLast`, `convert`, `chiSqUpperTail`, `sequenceIndices`,
`sequenceTransitions`, `discoverPatterns`, `patternOutcome`,
`countPatternInSequence`, `fisherExact2x2`, `sequenceStateDistribution`,
`sequenceStateFrequencies`, `meanTimeInState`, `modalSequence`,
`entropyProfile`, `sequenceFrequencies`). The TraMineR tier (`seqindic` and
everything after it in this document) is root + `ladyna/sequences` **only** —
see `docs/api/exports.md` for the authoritative matrix.

### Input data

All TraMineR-tier verbs accept either raw wide data or prepared data:

```ts
type WideData = (string | null | undefined)[][];   // null/undefined/'' = missing
data: WideData | PreparedSequenceData
```

Passing raw data runs `prepareSequenceData()` internally (alphabet = sorted
unique states, 1-based integer codes, `NaN` for missing). Prepare once and
reuse when calling several verbs on the same data.

---

## seqindic()

```ts
function seqindic(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: SeqIndicOptions = {},
): Partial<SeqIndicRow>[]
```

Port of `TraMineR::seqindic` — one row per sequence, one column per requested
indicator, all 28 TraMineR indicators. Returns an array of plain objects
keyed by the R column names.

### Options (`SeqIndicOptions`)

| option  | type                                | default | meaning |
|---------|-------------------------------------|---------|---------|
| `indic` | `(SeqIndicName \| SeqIndicGroup)[]` | `['all', 'ranked']`, plus `'binary'` when `ipos` is given | Indicators and/or groups to compute (R's `indic` vocabulary, lowercase). |
| `w`     | `number`                            | `0.5`   | Volatility weight for `Volat` (share-of-states-visited vs transition share). |
| `ipos`  | `SeqIposOptions`                    | —       | Positive/negative state model; **required** by the binary indicators (R's `ipos.args`). |
| `prec`  | `SeqPrecOptions`                    | alphabet order | State hierarchy for the ranked indicators (R's `prec.args`). Without it, alphabet order is used. |

### Indicator groups (`SeqIndicGroup`)

| group        | indicators |
|--------------|------------|
| `basic`      | `lgth nonm dlgth visited visitp recu trans transp meand meand2` |
| `diversity`  | `visitp entr dustd dustd2` |
| `complexity` | `transp nsubs volat cplx turb turbn turb2 turb2n` |
| `binary`     | `ppos nvolat vpos integr` — requires `ipos` |
| `ranked`     | `degrad bad prec insec` — takes `prec`; alphabet order otherwise |
| `all`        | `basic` + `diversity` + `complexity` (R's meaning — does **not** include binary/ranked) |

Selecting any binary indicator without a non-empty `ipos` throws, exactly as
R errors.

### The 28 indicators

`indic` names are lowercase; the output column is TraMineR's own `seqindic`
column name, so R comparison is column-for-column.

| `indic`  | column    | group(s)          | meaning (R equivalent) |
|----------|-----------|-------------------|------------------------|
| `lgth`   | `Lgth`    | basic             | Sequence length up to the last observed element — `seqlength(with.missing = TRUE)`, not the padded width. |
| `nonm`   | `NonM`    | basic             | Number of non-missing observations. |
| `dlgth`  | `Dlgth`   | basic             | Number of spells — length of the DSS (`seqdss`). |
| `visited`| `Visited` | basic             | Number of distinct states visited. |
| `visitp` | `Visitp`  | basic, diversity  | Proportion of the alphabet visited (`Visited / a`). |
| `recu`   | `Recu`    | basic             | Recurrence: mean visits per visited state (`Dlgth / Visited`). |
| `trans`  | `Trans`   | basic             | Number of state changes (`Dlgth − 1`, floor 0). |
| `transp` | `Transp`  | basic, complexity | Share of realised transitions (`Trans / (Lgth − 1)`; 0 for a one-observation sequence, as R reports). |
| `meand`  | `MeanD`   | basic             | Mean spell duration (`seqivardur` type 1). |
| `meand2` | `MeanD2`  | basic             | Type-2 mean spell duration: unvisited states count as spells of duration 0 (`seqivardur(type = 2)`). |
| `entr`   | `Entr`    | diversity         | Longitudinal Shannon entropy, natural log normalised by ln(a) (`seqient`). |
| `dustd`  | `Dustd`   | diversity         | **Population** sd of spell durations. |
| `dustd2` | `Dustd2`  | diversity         | Type-2 sd of spell durations (duration-0 spells for unvisited states). |
| `nsubs`  | `Nsubs`   | complexity        | Number of distinct subsequences of the DSS — Elzinga (`seqsubsn`). |
| `volat`  | `Volat`   | complexity        | Objective volatility: `w`·visited-share + `(1 − w)`·`Transp` (`seqivolatility`). |
| `cplx`   | `Cplx`    | complexity        | Complexity index `sqrt(Transp · Entr)` (`seqici`). |
| `turb`   | `Turb`    | complexity        | Turbulence `log2(phi · (s²max + 1)/(s² + 1))`, type-1 duration variance (`seqST`). |
| `turbn`  | `Turbn`   | complexity        | Normalised turbulence — divided by the turbulence of the alphabet cycled to the **dataset's** max length, so a row's value depends on the other rows. |
| `turb2`  | `Turb2`   | complexity        | Turbulence with type-2 duration variance (`seqST(type = 2)`). |
| `turb2n` | `Turb2n`  | complexity        | Normalised `Turb2`. |
| `ppos`   | `Ppos`    | binary            | Share of positive positions (`seqipos(index = 'share', dss = FALSE)`). |
| `nvolat` | `Nvolat`  | binary            | Share of positive DSS elements, on the DSS of the **original** sequence. |
| `vpos`   | `Vpos`    | binary            | Volatility of the positive/negative-recoded sequence. R recodes missing to VOID there, truncating the DSS scan to the first `NonM` positions — reproduced, since it is what R returns. |
| `integr` | `Integr`  | binary            | Position-integrated share of positive positions (`seqintegr`). |
| `degrad` | `Degrad`  | ranked            | Degradation index — `seqidegrad`, see below. |
| `bad`    | `Bad`     | ranked            | Badness — `seqibad`, see below. |
| `prec`   | `Prec`    | ranked            | Precarity — `seqprecarity` type 1, see below. |
| `insec`  | `Insec`   | ranked            | Insecurity — `seqprecarity` type 2 (`spow = 0`), see below. |

### Example (run against the built library)

```js
const { seqindic } = require('ladyna');

const data = [
  ['plan', 'discuss', 'discuss', 'execute', 'execute', 'reflect'],
  ['plan', 'plan', 'execute', 'execute', 'execute', 'execute'],
  ['discuss', 'execute', 'plan', 'discuss', 'execute', null],
  ['reflect', 'reflect', 'reflect', 'reflect', 'reflect', 'reflect'],
];

console.log(seqindic(data, { indic: ['basic'] })[0]);
```

```
{
  Lgth: 6,
  NonM: 6,
  Dlgth: 4,
  Visited: 4,
  Visitp: 1,
  Recu: 1,
  Trans: 3,
  Transp: 0.6,
  MeanD: 1.5,
  MeanD2: 1.5
}
```

Complexity plus the binary indicators (which need `ipos`):

```js
console.log(seqindic(data, {
  indic: ['complexity', 'binary'],
  ipos: { posStates: ['execute', 'reflect'] },
})[0]);
```

```
{
  Transp: 0.6,
  Nsubs: 16,
  Volat: 0.8,
  Cplx: 0.7586097483003674,
  Turb: 4.485426827170242,
  Turb2: 4.678071905112637,
  Turbn: 0.710312724373673,
  Turb2n: 0.7135211810197084,
  Ppos: 0.5,
  Nvolat: 0.5,
  Vpos: 0.6,
  Integr: 0.7142857142857143
}
```

Ranked indicators with an explicit hierarchy (least → most precarious):

```js
console.log(seqindic(data, {
  indic: ['ranked'],
  prec: { stateOrder: ['reflect', 'execute', 'discuss', 'plan'] },
}));
```

```
[
  {
    Degrad: -0.31746031746031744,
    Bad: 0.3492063492063492,
    Prec: 0.2,
    Insec: 0.6078160975067166
  },
  {
    Degrad: -0.5714285714285715,
    Bad: 0.42857142857142855,
    Prec: 0.2,
    Insec: 0.0649387260167883
  },
  {
    Degrad: -0.11111111111111108,
    Bad: 0.5777777777777777,
    Prec: 0.7949491363932142,
    Insec: 0.8945547548287285
  },
  { Degrad: 0, Bad: 0, Prec: 0, Insec: 0 }
]
```

### `SeqIposOptions` (R's `ipos.args`)

At least one of `posStates` / `negStates` is required.

| option      | type       | default | meaning |
|-------------|------------|---------|---------|
| `posStates` | `string[]` | complement of `negStates` | States counted as positive. |
| `negStates` | `string[]` | complement of `posStates` | States counted as negative. |
| `pow`       | `number`   | `1`     | Integration exponent for `Integr`. |
| `w`         | `number`   | `0.5`   | Volatility weight for `Vpos` (independent of the top-level `w`). |
| `dss`       | `boolean`  | `false` | Compute `Vpos`/`Integr` on the DSS instead of the raw sequence. |

### `SeqPrecOptions` (R's `prec.args`)

The union of what `seqidegrad`, `seqibad` and `seqprecarity` accept
(`PrecarityIndexOptions` without `type`, with `pow: number | boolean`); each
verb receives only the arguments it understands, matching R's filtering of
`prec.args` by formals. See the precarity family below for the fields.

---

## Standalone indicator verbs

Each is one TraMineR function; `seqindic` dispatches to them internally.

### seqivardur()

```ts
function seqivardur(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: { type?: 1 | 2 } = {},        // default type: 1
): SeqIvardurResult                       // { variance, vmax, meand } — number[] each
```

`TraMineR::seqivardur` — within-sequence variance of spell durations
(population). Type 1 uses the observed spells; type 2 adds one zero-length
spell per unvisited state, so the maximum accounts for the alphabet.

```js
console.log(seqivardur(data, { type: 2 }));
```

```
{
  variance: [ 0.25, 2.75, 0.1388888888888889, 6.75 ],
  vmax: [ 1, 4.25, 0.20408163265306123, 6.75 ],
  meand: [ 1.5, 1.5, 0.8333333333333334, 1.5 ]
}
```

### seqsubsn()

```ts
function seqsubsn(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: { dss?: boolean } = {},        // default dss: true
): number[]
```

`TraMineR::seqsubsn` — Elzinga's number of distinct subsequences, of the DSS
by default (`dss: false` counts on the raw observed sequence).

```js
console.log(seqsubsn(data));   // [ 16, 4, 28, 2 ]
```

### seqST()

```ts
function seqST(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: { type?: 1 | 2; norm?: boolean } = {},   // defaults: type 1, norm false
): number[]
```

`TraMineR::seqST` — Elzinga's turbulence. `norm: true` divides by the
turbulence of the alphabet cycled to the **dataset's** maximum length, so the
normalised value of one row depends on the longest row present.

```js
console.log(seqST(data));
// [ 4.485426827170242, 3.321928094887362, 4.807354922057604, 1 ]
console.log(seqST(data, { norm: true }));
// [ 0.710312724373673, 0.4731974454383393, 0.7759200756309999, 0 ]
```

### seqipos()

```ts
type SeqIposIndex = 'share' | 'integr' | 'volatility';

function seqipos(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: SeqIposOptions & { index?: SeqIposIndex } = {},   // default index: 'share'
): number[]
```

`TraMineR::seqipos` — positive-state indices on the p/n recoding of each
sequence: `share` (proportion of positive elements — of the DSS by default
for this index), `integr` (positional integration of positive elements), or
`volatility`. One of `posStates`/`negStates` is required.

```js
console.log(seqipos(data, { posStates: ['execute', 'reflect'] }));
// [ 0.5, 0.5, 0.4, 1 ]
console.log(seqipos(data, { posStates: ['execute', 'reflect'], index: 'integr' }));
// [ 0.7142857142857143, 0.8571428571428571, 0.4666666666666667, 1 ]
```

---

## Precarity family (ranked indicators)

Ports of `seqprecstart`, `states.check`, `seqidegrad.private`, `seqibad` and
`seqprecarity.private` from TraMineR 2.2.13 (Ritschard, Bussi & O'Reilly).
All take the shared `PrecarityOptions` state model:

| option       | type         | default        | meaning |
|--------------|--------------|----------------|---------|
| `stateOrder` | `string[]`   | alphabet order | States from least to most precarious. States left out are **non-comparable** (their positions are overwritten in place by the preceding state before spells are taken). |
| `stateEquiv` | `string[][]` | —              | Groups of equivalent states, e.g. `[['A','B']]`. |
| `stprec`     | `number[]`   | derived from `stateOrder` | Explicit state precarity, one per alphabet state; **negative = non-comparable**. Overrides `stateOrder` (R re-derives the order, replaces negatives with the mean of the rest, min–max normalises). |

Faithfully reproduced R quirks: `seqprecstart` runs twice on the
`prec`/`insec` path, so negative-coded non-comparability survives only for
`Degrad`; the transition-weight matrix is shrunk by `borderEffect` when any
rate exceeds `1 − 0.1/borderEffect`, transformed by `weightType`, then divided
row-wise by its own diagonal.

### seqidegrad()

```ts
type DegradMethod   = 'FREQ' | 'TRATE' | 'TRATEDSS' | 'RANK'
                    | 'FREQ+' | 'TRATE+' | 'TRATEDSS+' | 'RANK+' | 'ONE';
type DegradWeightType = 'ADD' | 'INV' | 'LOGINV';
type DegradPenalized  = 'NEG' | 'POS' | 'BOTH' | 'NO';

function seqidegrad(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: DegradOptions = {},
): number[]
```

`TraMineR::seqidegrad` — degradation index: signed, transition-weighted,
spell-integrated count of moves down/up the state hierarchy.
`DegradOptions` extends `PrecarityOptions` with:

| option         | type                          | default  |
|----------------|-------------------------------|----------|
| `penalized`    | `DegradPenalized \| boolean`  | `'BOTH'` (`true` = `'BOTH'`, `false` = `'NO'`) |
| `method`       | `DegradMethod`                | `'RANK'` |
| `weightType`   | `DegradWeightType`            | `'ADD'`  |
| `pow`          | `number \| boolean`           | `1` (`false` disables spell integration — R's logical `pow`) |
| `borderEffect` | `number`                      | `10` (must be > 1 for `FREQ`/`TRATE`/`TRATEDSS`) |

### seqibad()

```ts
function seqibad(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: BadOptions = {},              // PrecarityOptions & { pow?: number }, pow default 1
): number[]
```

`TraMineR::seqibad` — badness: position-integrated mean state precarity.

### seqprecarity()

```ts
function seqprecarity(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: PrecarityIndexOptions = {},
): number[]
```

`TraMineR::seqprecarity` — precarity (`type: 1`, the `Prec` column) or, with
`type: 2`, the insecurity index exactly as `seqindic` computes `Insec`
(`seqprecarity.private(type = 2)`, whose `spow` defaults to 0 — the public R
verb `seqinsecurity` defaults `spow = pow` instead, see below).
`PrecarityIndexOptions` extends `DegradOptions` with:

| option       | type       | default (type 1 / type 2) | meaning |
|--------------|------------|---------------------------|---------|
| `type`       | `1 \| 2`   | `1`                       | 1 = precarity, 2 = insecurity. |
| `correction` | `number[]` | computed via `seqidegrad.private` | Pre-computed degradation correction, one per sequence. |
| `otto`       | `number`   | `0.2`                     | Weight of the starting-state precarity (type 1). |
| `a`          | `number`   | `1` / `0.5`               | Complexity exponent (ignored for type 2). |
| `b`          | `number`   | `1.2` / `1 − a`           | Correction exponent (ignored for type 2). |
| `method`     | `DegradMethod` | `'TRATEDSS'` / `'RANK'` | Correction method. |
| `spow`       | `number`   | `0`                       | Start-integration exponent (type 2). |
| `pow`        | `number`   | `1`                       | Spell-integration exponent. |
| `bound`      | `boolean`  | `false`                   | Clamp type-2 values to the precarity range of the visited states. |

Type 1: `otto·stprec[first] + (1 − otto)·C^a·(1 + corr)^b` (correction
without spell integration). Type 2: `stprec[first]·integr₁ + (C + corr)`
(correction with spell integration).

### seqinsecurity()

```ts
function seqinsecurity(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: Omit<PrecarityIndexOptions, 'type' | 'otto' | 'a' | 'b'> = {},
): number[]
```

`TraMineR::seqinsecurity` — the public insecurity verb: the same computation
as `seqprecarity({ type: 2 })` but with R's public defaults `method: 'RANK'`,
`pow: 1`, `spow: pow`, `bound: false`. Because `spow` defaults to `pow` here
(not 0), its output differs from the `Insec` column unless you pass
`spow: 0`.

```js
const prec = { stateOrder: ['reflect', 'execute', 'discuss', 'plan'] };
console.log(seqidegrad(data, prec));
// [ -0.31746031746031744, -0.5714285714285715, -0.11111111111111108, 0 ]
console.log(seqibad(data, prec));
// [ 0.3492063492063492, 0.42857142857142855, 0.5777777777777777, 0 ]
console.log(seqprecarity(data, prec));
// [ 0.2, 0.2, 0.7949491363932142, 0 ]
console.log(seqinsecurity(data, prec));
// [ 0.4887684784590976, -0.12553746445940217, 0.8056658659398396, 0 ]
```

---

## Dissimilarity

### seqcost()

```ts
type SeqCostMethod = 'CONSTANT' | 'TRATE' | 'INDELS' | 'INDELSLOG';

function seqcost(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: { method?: SeqCostMethod; cval?: number } = {},   // defaults: 'CONSTANT', 2
): SeqCostResult   // { indel: number | number[]; sm: number[][]; states: string[]; method }
```

`TraMineR::seqcost` — derive substitution and indel costs from the data:

- `CONSTANT` — `sub = cval` off-diagonal; `indel = cval / 2`
- `TRATE` — `sub(i,j) = cval − p(i→j) − p(j→i)`; `indel = max(sm) / 2`
- `INDELS` — `indel_i = 1 / f_i`; `sub(i,j) = indel_i + indel_j`
- `INDELSLOG` — `indel_i = log(2 / (1 + f_i))`; `sub(i,j) = indel_i + indel_j`

```js
console.log(seqcost(data, { method: 'TRATE' }));
```

```
{
  indel: 1,
  sm: [
    [ 0, 1.25, 1.5, 2 ],
    [ 1.25, 0, 1.5833333333333333, 1.8333333333333333 ],
    [ 1.5, 1.5833333333333333, 0, 2 ],
    [ 2, 1.8333333333333333, 2, 0 ]
  ],
  states: [ 'discuss', 'execute', 'plan', 'reflect' ],
  method: 'TRATE'
}
```

### seqdist()

```ts
type SeqDistMethod = 'OM' | 'LCS' | 'LCP' | 'RLCP' | 'HAM' | 'DHD';
type SeqDistNorm   = 'none' | 'auto' | 'maxlength' | 'gmean' | 'maxdist' | 'YujianBo';

function seqdist(
  data: (string | null | undefined)[][] | PreparedSequenceData,
  options: SeqDistOptions = {},
): number[][]      // full symmetric matrix, zero diagonal (R full.matrix = TRUE)
```

`TraMineR::seqdist`, tier 1 — six methods covering the overwhelming majority
of published practice:

| method | distance |
|--------|----------|
| `OM`   | Optimal matching (Needleman–Wunsch) with substitution matrix + indel. **Default.** |
| `LCS`  | Longest common subsequence: `n + m − 2·|LCS|` (identical to OM with indel 1, constant sub 2). |
| `LCP`  | Longest common prefix: `n + m − 2·|LCP|`. |
| `RLCP` | Longest common suffix (LCP on reversed sequences). |
| `HAM`  | Hamming: positionwise substitution cost; equal lengths required. |
| `DHD`  | Dynamic Hamming: HAM with position-specific costs. |

Deliberately not ported: OMloc, OMslen, OMstran, NMS, NMSMST, SVRspell, and
the FEATURES cost model.

`SeqDistOptions`:

| option | type | default | meaning |
|--------|------|---------|---------|
| `method` | `SeqDistMethod` | `'OM'` | Distance method. |
| `sm` | `SeqCostMethod \| number[][]` | `'CONSTANT'` | Substitution costs: a cost-method name (fed to `seqcost`) or an explicit matrix. |
| `indel` | `number \| number[]` | implied by the cost method | Indel cost (scalar or per-state). |
| `cval` | `number` | `2` (`1` for HAM/DHD) | Substitution scale for CONSTANT/TRATE. TraMineR's CONSTANT scale is method-dependent: HAM/DHD have no indel and use 1, making the distance a plain mismatch count. |
| `norm` | `SeqDistNorm` | `'none'` | Normalisation. `'auto'` resolves to `'maxlength'` for alignment methods and `'gmean'` for LCS/LCP/RLCP — TraMineR's own mapping. |
| `timeVaryingCosts` | `number[][][]` | — | One substitution matrix per position, for DHD. |

```js
console.log(seqdist(data, { method: 'OM', sm: 'TRATE' }));
```

```
[
  [ 0, 4.5, 5, 9.666666666666666 ],
  [ 4.5, 0, 5.333333333333333, 11.333333333333332 ],
  [ 5, 5.333333333333333, 0, 10.666666666666666 ],
  [ 9.666666666666666, 11.333333333333332, 10.666666666666666, 0 ]
]
```

---

## Discrepancy analysis and case aggregation

Everything here operates on a dissimilarity matrix (typically from
`seqdist`). The trick: for a set of cases the "sum of squares" is the sum of
pairwise distances divided by the set size, so all of it is defined on any
dissimilarity, metric or not.

### dissvar()

```ts
function dissvar(distance: number[][], members?: readonly number[]): number
```

`TraMineR::dissvar` — discrepancy (pseudo-variance) of a set of cases: sum of
pairwise distances / n². `members` restricts to a subset of row indices
(default: all).

### disscenter()

```ts
function disscenter(distance: number[][], group?: readonly (string | number)[]): number[]
```

`TraMineR::disscenter` — distance from each case to the (implicit) centre of
its group: `mean_j∈g d(i,j) − discrepancy(g)`. Without `group`, one group of
all cases.

### dissassoc()

```ts
function dissassoc(
  distance: number[][],
  group: readonly (string | number)[],
  options: {
    iterations?: number;                                   // default 0
    replayLabels?: Array<readonly (string | number)[]>;    // permuted labels from R
  } = {},
): DissassocResult
```

`TraMineR::dissassoc` — dissimilarity ANOVA. Five statistics: Pseudo F,
Pseudo Fbf (Brown–Forsythe), Pseudo R2, Bartlett, Levene, plus the
discrepancy decomposition (`anova: { total, within, between, n, k }`).

Two documented non-equivalences:

- **Bartlett is NOT R-equivalent.** R's `dissassoc` delegates to compiled C
  whose exact Bartlett form could not be recovered; the textbook definition
  implemented here disagrees with R on the fixture data. The other four
  statistics are pinned exactly.
- **P-values are permutation-based and not R-comparable without a replay
  hook**: R shuffles labels with its own `sample()`. Supply `replayLabels` —
  one permuted label vector per iteration, captured from R — to compare
  p-values. Without it, the `t0` statistics are still exact; with neither
  `replayLabels` nor iterations run, `pValue` is `NaN`.

```js
const D = seqdist(data, { method: 'LCS' });
console.log(dissvar(D));          // 3.1875
console.log(disscenter(D));       // [ 2.0625, 3.0625, 2.5625, 5.0625 ]
const res = dissassoc(D, ['a', 'a', 'b', 'b']);
console.log(res.anova);           // { total: 12.75, within: 8.5, between: 4.25, n: 4, k: 2 }
console.log(res.stats[0]);        // { name: 'Pseudo F', t0: 1, pValue: NaN }
```

### aggregateCases()

```ts
function aggregateCases(
  data: readonly (readonly (string | null | undefined)[])[],
  weights?: readonly number[],
): AggregatedCases
```

`WeightedCluster::wcAggregateCases` — collapse identical sequences, carrying
multiplicity as a weight; the standard way to keep the O(n²) `seqdist` matrix
tractable on heavily duplicated data. Representatives come back in **sorted
sequence order** (as R does), not first-appearance order; `disaggIndex` maps
every original row back to its representative.

```js
console.log(aggregateCases([['A','B'], ['A','A'], ['A','B'], ['B','B'], ['A','A']]));
```

```
{
  aggIndex: [ 1, 0, 3 ],
  aggWeights: [ 2, 2, 1 ],
  disaggIndex: [ 1, 0, 1, 2, 0 ],
  disaggWeights: [ 1, 1, 1, 1, 1 ]
}
```

---

## Cluster quality

### clusterQuality()

```ts
function clusterQuality(distance: number[][], clustering: number[]): ClusterQuality
```

`WeightedCluster::wcClusterQuality` (WeightedCluster 1.8.1) — the ten indices
used to choose k, in R's own order: `PBC` (point-biserial correlation), `HG`
(Hubert's Gamma), `HGSD` (Hubert's Somers' D), `ASW` (average silhouette
width), `ASWw` (weighted ASW), `CH` (Calinski–Harabasz pseudo-F), `R2`,
`CHsq`/`R2sq` (on squared distances), and `HC` (Hubert's C — the only index
where **lower** is better). WeightedCluster's empirically pinned conventions
are reproduced, including silhouette width 1 (not 0) for a singleton cluster.

```js
const D = seqdist(data, { method: 'LCS' });
console.log(clusterQuality(D, [1, 1, 1, 2]));
```

```
{
  PBC: 0.8276900944256503,
  HG: 1,
  HGSD: 1,
  ASW: 0.590719696969697,
  ASWw: 0.7271464646464647,
  CH: 2.25,
  R2: 0.5294117647058824,
  CHsq: 4.477272727272728,
  R2sq: 0.6912280701754386,
  HC: 0
}
```

---

## Preparation and conversion (codyna tier)

### prepareSequenceData()

```ts
function prepareSequenceData(data: (string | null | undefined)[][]): PreparedSequenceData
```

Extracts the sorted unique alphabet and converts each cell to a 1-based
integer code (`NaN` for null/undefined/empty-string). The input form for
every other verb in the module.

```js
console.log(prepareSequenceData([['A', 'B', null], ['B', 'B', 'C']]));
// { sequences: [ [ 1, 2, NaN ], [ 2, 2, 3 ] ], alphabet: [ 'A', 'B', 'C' ] }
```

### rle()

```ts
function rle(arr: number[]): RLEResult   // { values: number[]; lengths: number[] }
```

Run-length encoding matching R's `rle()`: each `NaN` is its own run (as R's
`NA != NA` behaves).

```js
console.log(rle([1, 1, 2, 2, 2, NaN, NaN, 1]));
// { values: [ 1, 2, NaN, NaN, 1 ], lengths: [ 2, 3, 1, 1, 1 ] }
```

### extractLast()

```ts
function extractLast(
  sequences: number[][],
  alphabet: string[],
): { sequences: number[][]; alphabet: string[]; group: string[] }
```

Matches R codyna's `extract_last()`: pulls the last non-missing observation of
each sequence out as a group label, removes those values from the sequences,
and remaps the alphabet. Takes prepared (integer-coded) input.

```js
const prep = prepareSequenceData([['A', 'B', 'pass'], ['B', 'A', 'fail']]);
console.log(extractLast(prep.sequences, prep.alphabet));
// { sequences: [ [ 1, 2, NaN ], [ 2, 1, NaN ] ], alphabet: [ 'A', 'B' ], group: [ 'pass', 'fail' ] }
```

### convert()

```ts
function convert(
  data: (string | null | undefined)[][],
  format: 'frequency' | 'onehot' | 'edgelist' | 'reverse' = 'frequency',
): FrequencyResult | EdgeListEntry[] | ReverseEdgeListEntry[]
```

Convert wide-format data: `'frequency'` (per-sequence state counts),
`'onehot'` (0/1 presence), `'edgelist'` (`{ id, from, to }` per transition),
`'reverse'` (`{ id, state, previous }`).

```js
console.log(convert([['A', 'B', 'B'], ['B', 'C', null]], 'edgelist'));
```

```
[
  { id: 1, from: 'A', to: 'B' },
  { id: 1, from: 'B', to: 'B' },
  { id: 2, from: 'B', to: 'C' }
]
```

### chiSqUpperTail()

```ts
function chiSqUpperTail(x: number, df: number): number
```

Chi-squared upper-tail p-value, `P(X > x)` for `X ~ χ²(df)` — matches R's
`pchisq(x, df, lower.tail = FALSE)`. Used by `discoverPatterns`' group tests.

```js
console.log(chiSqUpperTail(3.84, 1));   // 0.05004352124870506
```

---

## Structural indices and pattern discovery (codyna tier)

### sequenceIndices()

```ts
function sequenceIndices(
  data: (string | null | undefined)[][],
  options?: IndicesOptions,   // { favorable?: string[]; omega?: number = 1.0 }
): IndexResult[]
```

The 24 per-sequence structural indices from R codyna's
`sequence_indices_()` — a **different set from `seqindic`'s 28**, sharing no
names with them; both are kept under their own references. One `IndexResult`
per sequence with: `validN`, `validProportion`, `uniqueStates`,
`meanSpellDuration`, `maxSpellDuration`, `longitudinalEntropy` (counts
missing as a state — codyna's convention), `simpsonDiversity`,
`selfLoopTendency`, `transitionRate`, `transitionComplexity`,
`initialStatePersistence`, `initialStateProportion`,
`initialStateInfluenceDecay`, `cyclicFeedbackStrength`, `firstState`,
`lastState`, `dominantState`, `dominantProportion`, `dominantMaxSpell`,
`emergentState`, `emergentStatePersistence`, `emergentStateProportion`,
`complexityIndex`, and — when `favorable` is given — `integrativePotential`
(weighted by `omega`).

```js
const si = sequenceIndices(data, { favorable: ['execute'] });
console.log(si[0].longitudinalEntropy, si[0].dominantState, si[0].integrativePotential);
// 0.8261650471771163 discuss 0.42857142857142855
```

### sequenceTransitions()

```ts
function sequenceTransitions(sequences: number[][], a: number): number[][][]
```

Per-sequence transition count arrays over **prepared** (integer-coded)
sequences: `trans[i][from][to]` for each sequence `i`, with `a` = alphabet
size. Missing-adjacent pairs are skipped.

```js
const p = prepareSequenceData([['A', 'B', 'A'], ['B', 'B', 'A']]);
console.log(JSON.stringify(sequenceTransitions(p.sequences, p.alphabet.length)));
// [[[0,1],[1,0]],[[0,0],[1,1]]]
```

### discoverPatterns()

```ts
function discoverPatterns(
  data: (string | null | undefined)[][],
  options?: DiscoverOptions,
): PatternResult    // { patterns: PatternEntry[]; _raw: RawPatterns[] }
```

R codyna's `discover_patterns()` — n-gram (`type: 'ngram'`, default), gapped
(`'gapped'`), repeated (`'repeated'`), or literal `pattern` search.
Each `PatternEntry` carries `pattern`, `length`, `frequency`, `proportion`
(within its length group), `count`, `support`, `lift`, and, with groups,
`groupCounts` / `chisq` / `pValue`. `PatternResult.total` is the number of
patterns the filters kept, before `topN` truncation.

#### Options (`DiscoverOptions`)

| Option | Default | Meaning |
|---|---|---|
| `type` | `'ngram'` | `'ngram'`, `'gapped'`, `'repeated'` |
| `pattern` | — | Literal pattern search (`*` = one-position wildcard); overrides `type` |
| `len` | `[2, 3, 4, 5]` | n-gram / repeat lengths |
| `gap` | `[1, 2, 3]` | Gap widths for `type: 'gapped'` |
| `minFreq` | `2` | Minimum total occurrences |
| `minSupport` | `0.01` | Minimum share of sequences containing the pattern |
| `start` | — | Keep patterns whose **first state token** is one of these |
| `end` | — | Keep patterns whose **last state token** is one of these |
| `contain` | — | Keep patterns matching any of these, as **literal substrings** |
| `containRegex` | `false` | Treat `contain` entries as raw regular expressions |
| `group` | `null` | Per-sequence group labels → `groupCounts` / `chisq` / `pValue` |
| `groupTest` | `'uniform'` | Expected-count model for the group test — see below |
| `sortBy` | `'frequency'` | `'frequency'`, `'support'`, `'lift'`, `'proportion'`, `'p'` |
| `topN` | — | Keep the first N patterns after filtering + sorting |

**`start` / `end` compare whole state TOKENS**, split on `->`. R codyna's
`filter_patterns()` uses `startsWith()` / `endsWith()` on the joined
`"A->B->C"` string, so `start = "plan"` there also matches a pattern
beginning with `planning`. ladyna deliberately does not reproduce that — see
the 2026-08-22 entry in `R-EQUIVALENCE-FIXES.md`.

**`contain` is literal by default.** Regex metacharacters are escaped, so a
state label like `A(1)` matches as itself. R codyna passes the joined
`contain` vector straight to `grepl(..., perl = TRUE)` with no escaping; set
`containRegex: true` to get that behaviour back (useful for alternations and
anchors, e.g. `contain: ['^A|^B'], containRegex: true`).

**`sortBy: 'p'` requires `group`.** Without group labels there are no
p-values, and the sort falls back to `'frequency'`. All other keys sort
descending; `'p'` sorts ascending (most significant first), breaking ties by
descending frequency.

**`groupTest` — read this before interpreting a grouped result.**
`'uniform'` (the default, and what R codyna hard-codes in `chisq_test()`)
expects `count / nGroups` sequences in **every** group, **ignoring how many
sequences each group actually contains**. On an imbalanced design — say 80
sequences in one group and 20 in another — a pattern distributed exactly in
proportion to group size (64 / 16) is scored as a large departure from the
50/50 expectation, so p-values are systematically too small. Use
`groupTest: 'independence'` for imbalanced designs: it weights the expected
count by group share, `expected_g = count × n_g / N`, which is the standard
test of independence between pattern presence and group. `'uniform'` remains
the default for R parity.

```js
// Imbalanced groups — do not use the default here.
discoverPatterns(data, { group, groupTest: 'independence', sortBy: 'p', topN: 10 });
```

```js
console.log(discoverPatterns(data, { type: 'ngram', len: [2], minFreq: 2 }).patterns[0]);
```

```
{
  pattern: 'reflect->reflect',
  length: 2,
  frequency: 5,
  proportion: 0.35714285714285715,
  count: 1,
  support: 0.25,
  lift: 1
}
```

---

### patternOutcome()

```ts
function patternOutcome(
  sequences: (string | null | undefined)[][],
  patterns: PatternResult | string[],
  outcome: (string | number | boolean | null | undefined)[],
  options?: PatternOutcomeOptions,
): PatternOutcomeResult
```

The statistics tier on top of `discoverPatterns()`: which patterns are
associated with a per-sequence outcome, and how strongly. Dependency-free and
fully deterministic (no RNG). `patterns` accepts a `discoverPatterns()` result
or a bare `string[]`; `outcome` is one value per sequence, aligned with
`sequences`.

This is **ladyna's own surface, not an R port.** codyna's `analyze_outcome()`
returns a raw `glm`/`glmerMod` object, needs `lme4`, and has no odds-ratio
table, no exact test and no omnibus chi-square. The implementation is lifted
from the CarmNote TNA notebook's outcome cell.

**Outcome scale is auto-detected**: exactly two distinct values → `'binary'`
(so a numeric 0/1 outcome is binary, not continuous); otherwise all-numeric →
`'continuous'`; otherwise `'categorical'`. Force it with `outcomeType`.
Sequences whose outcome is `null` / `undefined` / non-finite are dropped
listwise; `result.n` and `result.nDropped` report the split.

| Option | Default | Meaning |
|---|---|---|
| `encoding` | `'presence'` | `'presence'` (0/1 per sequence) or `'frequency'` (occurrence count) |
| `method` | `'univariate'` | `'univariate'`, `'multivariable'`, or `'both'` |
| `adjust` | `'BH'` | `'BH'`, `'holm'`, `'bonferroni'`, `'none'` — via `pAdjust()` |
| `reference` | lowest level | Reference level for a binary / categorical outcome |
| `outcomeType` | auto | Force `'binary'`, `'categorical'` or `'continuous'` |
| `maxIter` | `50` | IRLS iteration cap (logistic multivariable) |
| `tol` | `1e-8` | IRLS convergence tolerance on \|Δ log-likelihood\| |

#### Univariate rows (`result.rows`)

One tidy row per pattern — or per (pattern, level) for a K>2 categorical
outcome. Columns that do not apply to a row are `undefined`, the way an R
data.frame carries `NA`.

- **Binary** (`term: 'slope'`): the 2×2 cells `a` / `b` / `c` / `d`, the
  odds ratio and its Wald CI (`oddsRatio`, `ciLow`, `ciHigh`), the log odds
  (`estimate`), Woolf `se`, `statistic` (z) and `p`. When the smallest
  expected cell drops below 5, `test` flips to `'fisher'` and `p` comes from a
  two-tailed Fisher exact test instead of the Wald z.
- **Categorical K>2**: one `term: 'omnibus'` row per pattern carrying the
  2×K chi-square (`statistic`, `df = K-1`, `p`), plus one `term: 'level'`
  row per outcome level with a one-vs-rest odds ratio.
- **Continuous** (`term: 'slope'`): a per-pattern OLS `y ~ 1 + pattern` —
  `intercept`, slope `estimate`, `se`, `statistic` (t), `df`, `p`, `r2`,
  `r2Adjusted`, `sigma`, `aic`, `bic`.

`pAdjusted` is the `adjust` correction applied **within each `term` family**:
`'slope'` rows across patterns, `'omnibus'` rows across patterns, and
`'level'` rows across all (pattern × level) pairs.

#### Multivariable model (`result.model`)

`method: 'multivariable'` (or `'both'`) fits all patterns jointly: IRLS
logistic for a binary outcome, closed-form OLS for a continuous one. A
categorical K>2 outcome is rejected. The summary carries `coefficients`
(intercept first), `n`, `nParams`, `logLik`, `r2` (McFadden for logistic, R²
for Gaussian), `aic`, `bic`, `iterations`, `converged` and `singular`.
A rank-deficient design sets `singular: true` and returns `NaN` estimates
rather than throwing; a separable design saturates safely (η is capped at
±30, the IRLS weight floored at `1e-10`) and shows up as a runaway
coefficient with `r2` near 1.

**Two conventions inherited from the notebook, stated so nobody is surprised.**
The Haldane–Anscombe 0.5 correction is added to **all four cells
unconditionally**, not only when a cell is zero — every odds ratio and Wald
CI here is the corrected one. And every 95% interval uses the fixed normal
multiplier 1.96, in the Gaussian model too.

```js
const found = discoverPatterns(data, { len: [2], minFreq: 2, topN: 5 });
const res = patternOutcome(data, found, pass, { method: 'both', adjust: 'BH' });
res.rows[0];
// { pattern: 'plan->code', term: 'slope', kind: 'binary', n: 32,
//   a: 12, b: 4, c: 4, d: 12, oddsRatio: 7.716, ciLow: 1.68, ciHigh: 35.4,
//   p: 0.00858, pAdjusted: 0.00858, test: 'wald', ... }
res.model.r2;   // McFadden pseudo-R²
```

### patternOutcomeCounts()

```ts
function patternOutcomeCounts(
  sequences: (string | null | undefined)[][],
  patterns: PatternResult | string[],
  outcome: (string | number | boolean | null | undefined)[],
  options?: PatternOutcomeCountsOptions,
): PatternOutcomeCountRow[]
```

The contingency counts behind [`patternOutcome()`](#patternoutcome), as a tidy
table: one row per pattern, one count per outcome level. Same matcher
(`countPatternInSequence`) and the same listwise deletion of missing outcomes,
so the two verbs always describe the same observations — nothing is
recomputed differently.

| Option | Default | Meaning |
|---|---|---|
| `encoding` | `'presence'` | `'presence'` counts SEQUENCES in which the pattern occurs at least once; `'frequency'` sums the occurrences |
| `levels` | every distinct value, sorted | explicit level order (and subset) |

```js
const found  = discoverPatterns(data, { len: [2], minFreq: 2, topN: 8 });
const counts = patternOutcomeCounts(data, found, pass);
counts[0];
// { pattern: 'plan->code', counts: { fail: 3, pass: 11 } }
```

Every level is present in every row, zeros included, so the rows drop straight
into [`plotPatternOutcome()`](#plotpatternoutcome). Throws on no patterns, an
`outcome` whose length does not match `sequences`, or an all-missing outcome.

`PatternOutcomeCountRow` and `PatternOutcomeCountsOptions` are the exported
types.

### countPatternInSequence()

```ts
function countPatternInSequence(pattern: string, sequence: Cell[]): number
```

How many times a `"->"`-joined pattern occurs in one sequence. A run of `*`
is a wildcard covering that many consecutive positions (`A->*->B` needs
three). Occurrences are counted at every offset, so overlapping hits both
count: `"A->A"` occurs three times in `A A A A`. A missing cell never
matches, wildcards included — the same rule `discoverPatterns` applies to
`NaN`. This is the predictor builder `patternOutcome()` uses; it is exported
because it is the only way to reproduce its encoding by hand.

### fisherExact2x2()

```ts
function fisherExact2x2(a: number, b: number, c: number, d: number): number
```

Two-tailed Fisher exact test on a 2×2 table (sum of all hypergeometric
probabilities no greater than the observed one). Matches
`stats::fisher.test()` to ~1e-12. `patternOutcome()` calls it automatically
when an expected cell falls below 5.

---

## Descriptive statistics (codyna tier)

All take wide-format `(string | null)[][]` data and ignore nulls.

### sequenceStateDistribution()

```ts
function sequenceStateDistribution(data: (string | null)[][]): {
  proportions: number[][];   // [position][state]
  counts: number[][];
  states: string[];
  nPositions: number;
}
```

State proportions at each time position (TraMineR `seqstatd`-style).

### sequenceStateFrequencies()

```ts
function sequenceStateFrequencies(data: (string | null)[][]): {
  counts: number[]; proportions: number[]; states: string[]; total: number;
}
```

Overall state frequencies across the whole dataset (`seqstatf`-style).

```js
console.log(sequenceStateFrequencies(data).counts);   // [ 4, 8, 4, 7 ]
```

### meanTimeInState()

```ts
function meanTimeInState(data: (string | null)[][]): {
  meanTime: number[]; sdTime: number[]; states: string[];
}
```

Mean number of positions spent in each state per sequence (`seqmeant`-style);
`sdTime` uses the sample sd (n − 1), matching R's `sd()`.

### modalSequence()

```ts
function modalSequence(data: (string | null)[][]): {
  states: string[]; proportions: number[];
}
```

Modal state at each position (`seqmodst`-style); ties break alphabetically.

```js
console.log(modalSequence(data).states);
// [ 'plan', 'discuss', 'discuss', 'execute', 'execute', 'reflect' ]
```

### entropyProfile()

```ts
function entropyProfile(data: (string | null)[][]): {
  entropy: number[]; nPositions: number;
}
```

Cross-sectional Shannon entropy at each position, log2 normalised by
log2(nStates) so values sit in [0, 1]. (Note: a different convention from
`seqindic`'s longitudinal `Entr` — intentional, each matches its reference.)

```js
console.log(entropyProfile(data).entropy);
// [ 0.75, 1, 1, 0.75, 0.4056390622295664, 0.4591479170272448 ]
```

### sequenceFrequencies()

```ts
function sequenceFrequencies(
  data: (string | null)[][],
  options?: { top?: number },     // default: all
): { sequence: string[]; count: number; proportion: number }[]
```

Most frequent complete sequences (trailing nulls stripped), ranked by count
descending, ties broken deterministically.

---

## Pattern association & outcome regression (codynaj lineage)

Three verbs ported verbatim from `codynaj` when the codyna package was
retired (2026-08-22). Their contract is R parity, carried over with the
codynaj test fixtures (R 4.5.2 reference values, `tests/associate-r-groundtruth`
and `tests/regress-r-groundtruth`). All take `NamedColumn[]` predictors —
`{ name, values }` pairs, e.g. a pattern-presence design matrix — and are also
exported from the `ladyna` root and `ladyna/light`.

### `associatePatterns(patterns, outcome, options?)`

```ts
function associatePatterns(
  patterns: NamedColumn[], outcome: number[],
  options?: { method?: 'auto' | 'welch' | 'oddsRatio' },
): PatternAssociation[]
```

Screens every pattern against one outcome, one tidy row per pattern. A
pattern is "present" when its value is > 0 (0/1 vectors and raw counts both
work). Numeric outcome → Welch two-sample t-test rows (R `t.test` parity,
Welch–Satterthwaite df); binary 0/1 outcome → Haldane–Anscombe-corrected
odds-ratio rows (Wald z, 95% CI with `qnorm(0.975)`). `'auto'` (default)
picks oddsRatio when the outcome is all 0/1.

### `fitLinear(outcome, predictors)`

```ts
function fitLinear(outcome: number[], predictors: NamedColumn[]): LinearFit
```

OLS with an automatic `(Intercept)`. Coefficient p-values use the exact t
distribution on n−k residual df — matches R's `summary(lm(y ~ ...))`
(estimates, se, t, p, R², adjusted R², residual sigma). Throws on a
singular (collinear) design.

### `fitLogistic(outcome, predictors, options?)`

```ts
function fitLogistic(
  outcome: number[], predictors: NamedColumn[],
  options?: { maxIter?: number; tol?: number },
): LogisticFit
```

Logistic regression via IRLS replicating R's `glm.fit` exactly
(`mustart = (y + 0.5)/2`, relative-deviance stopping rule, maxit 25,
epsilon 1e-8), so coefficients match R's `summary(glm(..., family=binomial))`
at defaults — plus deviance, null deviance, AIC, McFadden pseudo-R²,
convergence flag. Outcome must be 0/1.

---

## Internal row primitives

The per-row primitives in `src/sequences/rows.ts` (`spellsOf`,
`nDistinctSubsequences`, `integrationOf`, `spellIntegration`,
`transitionRates`, `observedCodes`, `observedLength`) are **not exported**
from `ladyna/sequences` — they are internal building blocks shared by
`seqindic` and the precarity family.

---

## Types

All exported from `ladyna/sequences` (and the package root).

### Preparation / conversion / discovery (codyna tier)

| type | meaning |
|------|---------|
| `PreparedSequenceData` | `{ sequences: number[][]; alphabet: string[] }` — 1-based integer codes, `NaN` = missing. (codyna's `SequenceData`, renamed so the package-root `SequenceData = Sequence[]` stays unambiguous.) |
| `ConvertResult` | `FrequencyResult \| EdgeListResult` — union of `convert()` results. |
| `FrequencyResult` | `{ ids: number[]; states: string[]; matrix: number[][] }` — count or 0/1 matrix. |
| `EdgeListEntry` | `{ id: number; from: string; to: string }`. |
| `EdgeListResult` | `EdgeListEntry[]`. |
| `ReverseEdgeListEntry` | `{ id: number; state: string; previous: string }`. |
| `ReverseEdgeListResult` | `ReverseEdgeListEntry[]`. |
| `RLEResult` | `{ values: number[]; lengths: number[] }`. |
| `IndexResult` | One row of `sequenceIndices()` — the 24 structural indices. |
| `IndicesOptions` | `{ favorable?: string[]; omega?: number }`. |
| `PatternEntry` | One discovered pattern (see `discoverPatterns`). |
| `DiscoverOptions` | Options for `discoverPatterns()`. |
| `PatternSortKey` | `'frequency' \| 'support' \| 'lift' \| 'proportion' \| 'p'`. |
| `PatternGroupTest` | `'uniform' \| 'independence'` — expected-count model for the group test. |
| `PatternResult` | `{ patterns: PatternEntry[]; total: number; _raw }` — `total` is the pre-`topN` count. |
| `RawPatterns` | Internal raw pattern matrices (`{ matrix, unique, length }`). Reachable as `PatternResult._raw`, which is **internal**: shape and presence may change. |

### Pattern → outcome statistics

| type | meaning |
|------|---------|
| `PatternOutcomeOptions` | Options for `patternOutcome()`. |
| `PatternOutcomeResult` | The full result — `{ kind, encoding, method, adjust, n, nDropped, patterns, levels, reference, target, rows, model? }`. |
| `PatternOutcomeRow` | One tidy row per pattern (or per pattern × level). |
| `PatternOutcomeModel` | Summary of a joint (multivariable) fit. |
| `PatternOutcomeCoefficient` | One coefficient of a joint fit. |
| `PatternOutcomeEncoding` | `'presence' \| 'frequency'`. |
| `PatternOutcomeMethod` | `'univariate' \| 'multivariable' \| 'both'`. |
| `PatternOutcomeKind` | `'binary' \| 'categorical' \| 'continuous'`. |
| `PatternOutcomeAdjust` | `'BH' \| 'holm' \| 'bonferroni' \| 'none'`. |
| `PatternOutcomeTerm` | `'slope' \| 'omnibus' \| 'level'` — the adjustment family a row belongs to. |

### seqindic family

| type | meaning |
|------|---------|
| `SeqIndicRow` | The full 28-column result row (binary columns optional). |
| `SeqIndicOptions` | `{ indic?, w?, ipos?, prec? }` — see `seqindic()`. |
| `SeqIndicName` | Union of the 28 lowercase indicator names. |
| `SeqIndicGroup` | `'all' \| 'basic' \| 'diversity' \| 'complexity' \| 'binary' \| 'ranked'`. |
| `SeqIposOptions` | R's `ipos.args`: `{ posStates?, negStates?, pow?, w?, dss? }`. |
| `SeqIposIndex` | `'share' \| 'integr' \| 'volatility'`. |
| `SeqPrecOptions` | R's `prec.args`: `Omit<PrecarityIndexOptions, 'type' \| 'pow'> & { pow?: number \| boolean }`. |
| `SeqIvardurResult` | `{ variance: number[]; vmax: number[]; meand: number[] }`. |

### Precarity family

| type | meaning |
|------|---------|
| `PrecarityOptions` | Shared state model: `{ stateOrder?, stateEquiv?, stprec? }`. |
| `DegradOptions` | `PrecarityOptions` + `{ penalized?, method?, weightType?, pow?, borderEffect? }`. |
| `BadOptions` | `PrecarityOptions` + `{ pow?: number }`. |
| `PrecarityIndexOptions` | `DegradOptions` + `{ type?, correction?, otto?, a?, b?, spow?, bound? }` (with `pow?: number`). |
| `DegradMethod` | `'FREQ' \| 'TRATE' \| 'TRATEDSS' \| 'RANK' \| 'FREQ+' \| 'TRATE+' \| 'TRATEDSS+' \| 'RANK+' \| 'ONE'`. |
| `DegradWeightType` | `'ADD' \| 'INV' \| 'LOGINV'`. |
| `DegradPenalized` | `'NEG' \| 'POS' \| 'BOTH' \| 'NO'`. |

### Dissimilarity / discrepancy / clustering

| type | meaning |
|------|---------|
| `SeqCostMethod` | `'CONSTANT' \| 'TRATE' \| 'INDELS' \| 'INDELSLOG'`. |
| `SeqDistMethod` | `'OM' \| 'LCS' \| 'LCP' \| 'RLCP' \| 'HAM' \| 'DHD'`. |
| `SeqDistNorm` | `'none' \| 'auto' \| 'maxlength' \| 'gmean' \| 'maxdist' \| 'YujianBo'`. |
| `SeqCostResult` | `{ indel: number \| number[]; sm: number[][]; states: string[]; method: SeqCostMethod }`. |
| `SeqDistOptions` | `{ method?, sm?, indel?, cval?, norm?, timeVaryingCosts? }`. |
| `ClusterQuality` | The ten `wcClusterQuality` indices (`PBC HG HGSD ASW ASWw CH R2 CHsq R2sq HC`). |
| `AggregatedCases` | `{ aggIndex, aggWeights, disaggIndex, disaggWeights }`. |
| `DissassocStat` | `{ name: string; t0: number; pValue: number }`. |
| `DissassocResult` | `{ stats: DissassocStat[]; anova: { total, within, between, n, k }; iterations: number }`. |

---

## Trimming

Ported from Dynalytics Desktop `src/views/sequences.ts`. Shortens sequences
before plotting or downstream analysis, without touching the model.

### `trimSequences(data, options)`

| `mode` | behaviour |
|---|---|
| `'none'` | returns `data` unchanged (the same array reference) |
| `'fixed'` | truncates every sequence to `n` positions (default `10`) |
| `'percentile'` | truncates every sequence to the `percentile`-th percentile (default `95`) of the effective lengths |
| `'dominant'` | per sequence: strips trailing nulls, then shortens the trailing run of one repeated state to `dominantN` copies (default `1`, floored at 1) |

The percentile index is `ceil(percentile/100 · n) - 1` over the **sorted**
effective lengths, floored at `0` — so `percentile: 100` keeps the longest
sequence intact and `percentile: 50` cuts at the median length.

"Effective length" is the index of the last non-null position plus one:
trailing `null` padding is excluded when *measuring* lengths.

Faithful-port notes, kept rather than "fixed":

- `'fixed'` and `'percentile'` only `slice(0, maxLen)` — they do **not** strip
  trailing nulls from the result; `'dominant'` does (it returns the effective
  prefix).
- A `'dominant'` sequence that is entirely null passes through unchanged.
- `'fixed'` with `n <= 0` yields empty sequences; the source does not guard it.

Exported types: `TrimMode`, `TrimOptions`.

*Available from:* root, sequences.

---

## Per-sequence frequency matrix

### `sequenceFrequencyMatrix(sequences, options?)`

Rows = sequences, columns = states. Reconciles the two Dynalytics Desktop forks
of this computation (`src/analysis/glasso.ts` `computeFrequencyMatrix`, which
takes a caller-supplied label set and a `normalize` flag, and
`src/analysis/recipe.ts` `computeSequenceFreqData`, which derives sorted unique
states and counts only).

This is a **different verb** from `sequenceStateFrequencies` /
`sequenceStateDistribution` above: those collapse the whole corpus into one
count per state, whereas here every sequence keeps its own row.

| option | default | meaning |
|---|---|---|
| `states` | sorted unique non-null states in `sequences` | column ordering; states in the data but absent here are ignored entirely (not counted, not in the row total) |
| `normalize` | `false` | divide each row by its total, giving within-sequence proportions |

Returns `{ states, matrix, rows, normalized }` where `matrix` is a
`Float64Array[]` (one per sequence) and `rows` is the tidy
`FrequencyMatrixRow[]`: one row per sequence with `sequence` (the 0-based
index), `total` (the counted, non-null positions) and `values` (state → value).

With `normalize: false` each row sums to that sequence's non-null length; with
`normalize: true` each non-empty row sums to 1. A sequence with a zero total
keeps a row of zeros even when normalizing (the source's `total > 0` guard),
so such a row sums to `0`, not `1`.

Exported types: `FrequencyMatrixOptions`, `FrequencyMatrixRow`,
`FrequencyMatrixResult`.

*Available from:* root, sequences.

---

## Painters (self-contained SVG)

Five renderers that turn sequence data into a **single SVG string** — no DOM,
no d3, no runtime dependency. Same conventions as `plotNetwork()` and
`plotSimplicial()`: one `<svg>` with a `viewBox` and `max-width:100%`, escaped
text, a `<title>` per mark in place of a hover tooltip, and a thrown error
(never a silent empty canvas) on empty input.

These are **rendering only** — there is no R-parity requirement on pixels. The
geometry, palettes and cut-offs are ported verbatim from the renderers that
previously owned this drawing downstream: Dynalytics Desktop's
`src/views/sequences.ts` and `src/views/mosaic.ts`, the carm-tna notebook's
`notebook-render/seq-plots.js`, and this repo's `demo/main.ts`. The d3 pieces
those renderers leaned on (`d3.ticks`, `d3.scaleBand`, `d3.interpolateRdBu`,
`d3.scaleDiverging`) are hand-rolled here and verified to agree with d3
exactly.

The default state palette is Tableau-10 (`#4e79a7`, `#f28e2b`, …) — the
sequence renderers' palette, **not** `DEFAULT_COLORS` (the R TNA node palette).
States are coloured in sorted order, so an index plot and a distribution plot
of the same data agree cell for cell. The two group-aware painters
(`plotEntropyProfile`, `plotMeanTimes`) cycle the same palette over **groups**
rather than states.

### Grouped input

Every sequence painter accepts a `Record<groupName, SequenceData>` as well as a
plain `SequenceData`, and the two families differ in what that means:

| painter | grouped input | why |
|---|---|---|
| `plotSequenceIndex`, `plotStateDistribution` | **one SVG per group**, returned as `Record<groupName, string>` | a carpet or a stacked bar cannot be overlaid; each group needs its own canvas. Same convention as [`plotNetwork()`](core.md#plotnetwork) on a `GroupTNA`. Each SVG is titled with its group name unless `title` is passed explicitly. |
| `plotEntropyProfile`, `plotMeanTimes` | **one SVG**, all groups overlaid, with a group legend | the comparison *is* the figure — this is the CarmNote semantic these two were lifted from. |

A group whose `SequenceData` is empty is dropped silently (the house rule for
an unusable optional input); a call with nothing usable left throws. An empty
record throws `no groups`.

### The `trim` option

All four sequence painters take `trim?: TrimOptions` — the same shape
[`trimSequences()`](#trimsequencesdata-options) takes — and apply it to the data *before*
drawing (per group, for a record input):

```js
// Clip at the 99th percentile so one 400-step outlier does not squash the rest.
const svg = plotSequenceIndex(sequences, { trim: { mode: 'percentile', percentile: 99 } });
```

This is a convenience for that single common move. It changes **only** this
figure — no statistic reported anywhere else in the package is affected, and
the input array is not mutated.

### plotSequenceIndex()

TraMineR `seqIplot`: one row per sequence, one coloured rectangle per position,
legend on the right.

```js
import { plotSequenceIndex } from 'ladyna';

const svg = plotSequenceIndex(sequences, { sort: 'first', title: 'Sessions' });
```

Input is the package-root `SequenceData` (`(string | null)[][]`). Trailing
nulls are stripped per sequence; an **interior** null keeps its column and is
painted the missing-value grey `#ccc`, exactly as the source does.

`SequenceSort` = `'none' | 'first' | 'last' | 'frequency' | 'length'`, with the
comparators taken verbatim from `renderSeqIndex` (ties always break on the
input index):

| `sort` | source mode | ordering |
|---|---|---|
| `'none'` | Original order | input order |
| `'first'` | Start state | first state, `localeCompare` |
| `'last'` | End state | last state, `localeCompare` |
| `'frequency'` | Most-frequent state | dominant state, then dominant count descending |
| `'length'` | Length | short → long |

**Row-order precedence: `dendrogram` > `order` > `sort`.** An unusable
`dendrogram` or `order` is ignored *silently* — the next rule applies, rather
than an error being thrown mid-render.

`SequenceIndexPlotOptions`:

| option | default | meaning |
|---|---|---|
| `width` | `760` | canvas width |
| `height` | `18 × nSequences`, capped at `maxHeight` | when given, row height becomes `innerHeight / nSequences` (the source's fixed-height branch) |
| `rowHeight` | — | exact height of one row; when given the figure grows to `rowHeight × nSequences` with **no cap** (you asked for these rows) |
| `maxHeight` | `460` | cap on the default plot-area height — above `~25` sequences rows shrink to fit, so the carpet stays a readable figure instead of growing 18px per sequence; row labels are suppressed below 9px rows; `Infinity` restores unbounded growth. Ignored when `height` or `rowHeight` is passed |
| `title` / `subtitle` | — | headings drawn inside the SVG |
| `background` | `'#ffffff'` | canvas fill |
| `colors` | Tableau-10 | palette cycled in sorted-state order |
| `colorMap` | — | colour per state label; wins over `colors` |
| `sort` | `'none'` | see above |
| `order` | — | explicit 0-based row order; **wins over `sort`** |
| `dendrogram` | — | precomputed `{ merge, heights }` tree; **wins over `order`** |
| `trim` | — | `TrimOptions` applied before drawing |
| `showLegend` | `true` | legend block on the right (the 120px right gutter collapses to 10px when off) |
| `maxSequences` | all | draw the first N rows **after** sorting |
| `showBorders` | `false` | hairline `#ddd` cell borders |

Row-number labels are drawn only for **60 or fewer** sequences — the source's
cut-off, kept.

#### `order` — an explicit row order

```js
const svg = plotSequenceIndex(sequences, { order: [4, 0, 2, 1, 3] });
```

`order[0]` is the input row drawn at the top. It must be a **permutation of
`0 … n-1`**: a wrong-length, duplicated, non-integer or out-of-range array is
ignored and `sort` applies instead, so a caller that computes an order from
some other analysis never has to guard the painter.

#### `dendrogram` — draw a precomputed tree

```js
import { seqdist, computeDendrogram, plotSequenceIndex, Matrix } from 'ladyna';

// ANALYSIS: distance + clustering stay in the verbs.
const d = seqdist(sequences, { method: 'LCS' });          // number[][]
const tree = computeDendrogram(Matrix.from2D(d), 'ward.D2');

// PAINT: the painter only draws the tree it is handed.
const svg = plotSequenceIndex(sequences, { dendrogram: tree });
```

`computeDendrogram()` returns `{ merge, heights, order }`; the painter reads
`merge` and `heights` and re-derives the leaf order itself, so passing the
whole result works. `clusterData()` carries the same two fields for a
hierarchical `method`.

`SequenceDendrogram` is the R-`hclust`-shaped merge matrix ladyna's own
hierarchical clustering already records (`src/analysis/cluster.ts`):

- `merge[i] = [left, right]` is the i-th agglomeration. A **negative** entry
  `-k` is the leaf with 0-based index `k - 1`; a **positive** entry `m` is the
  earlier merge step `m` (1-based), so `m - 1 < i` always.
- `heights[i]` is that step's merge height.

Given the tree the painter (a) derives the row order by the in-order leaf
traversal — the same walk as `computeLeafOrder` in `cluster.ts`, reimplemented
locally so `sequences/` never imports from `analysis/` — and (b) draws the tree
in a **90px left gutter**, leaves flush with the carpet edge and each internal
node's x proportional to its merge height (base R `plot.dendrogram` geometry).

This closes the one gap the module header used to call "not ported". The
**analysis** half of the notebook's `cluster` sort mode — Ward.D2 on LCS
dissimilarity — is still not a paint step and still lives in
[`seqdist()`](#seqdist) plus the cluster verbs; only the **drawing** moved here.

A tree that is not a well-formed merge matrix over exactly the input rows
(wrong step count, a forward reference, a leaf used twice, a non-finite height)
is ignored silently. The gutter is also dropped — though the leaf *order* is
kept — when `maxSequences` removes rows, because a tree whose leaves have no
rows cannot be aligned to them.

### plotStateDistribution()

TraMineR `seqdplot`: the cross-sectional state proportions at each position,
as stacked bars (`style: 'stacked'`, the default — Desktop's
`renderDistribution`) or one line per state (`style: 'lines'` —
`renderDistributionLines`).

```js
import { plotStateDistribution } from 'ladyna';

const bars  = plotStateDistribution(sequences);
const lines = plotStateDistribution(sequences, { style: 'lines' });
```

The proportions come from [`sequenceStateDistribution()`](#sequencestatedistribution),
not from a private recomputation. One consequence: for an **interior** null the
source counted the missing cell in the per-position denominator (its bar summed
to less than 1), while `sequenceStateDistribution` drops nulls from numerator
and denominator alike, so every bar sums to 1. The ladyna definition wins.

`StateDistributionPlotOptions`:

| option | default | meaning |
|---|---|---|
| `style` | `'stacked'` | `'stacked'` or `'lines'` |
| `width` | `760` | canvas width |
| `height` | `585` (stacked) / `400` (lines) | the source fallbacks |
| `title` / `subtitle` | — | headings |
| `background` | `'#ffffff'` | canvas fill |
| `colors` / `colorMap` | Tableau-10 | as in `plotSequenceIndex` |
| `naGap` | `false` | divide by the TOTAL sequence count instead of the survivors — see below |
| `trim` | — | `TrimOptions` applied before drawing |
| `showLegend` | `true` | legend block on the right |
| `showBorders` | `true` | hairline white separators between stacked segments |
| `showProportionLabel` | `true` | the rotated "Proportion" y-axis title |

Kept-as-is source quirk: in the stacked style the x axis is labelled with the
**0-based** band domain while the tooltips read `Step t + 1`.

#### `naGap` — make the survivor curve visible

```js
const svg = plotStateDistribution(sequences, { naGap: true });
```

By default every bar sums to 1, because the proportions come from
[`sequenceStateDistribution()`](#sequencestatedistribution), which divides by
the number of sequences **still present** at that position. With `naGap: true`
the painter re-divides the same counts by the **total** number of sequences, so
a position where some sequences have already ended sums to *less* than 1 — a
visible gap at the top of the stack (or a downward drift of the lines under
`style: 'lines'`). The tooltip denominator follows: `(1/2)` becomes `(1/4)`.

This deliberately **differs from the data verb**, and only here. The
always-sums-to-1 definition stays the one ladyna reports everywhere else; `naGap`
is a drawing choice, computed inside the painter, and changes no statistic. It
exists because "half the cohort has finished by step 5" is exactly the fact a
normalised bar hides.

### plotEntropyProfile()

Normalized cross-sectional entropy at each position — one line per group, all
groups **overlaid in a single figure**.

```js
import { plotEntropyProfile } from 'ladyna';

const one = plotEntropyProfile(sequences, { title: 'Entropy over time' });
const two = plotEntropyProfile({ control: a, treatment: b });   // one SVG, two lines
```

The numbers come from [`entropyProfile()`](#entropyprofile) applied per group,
so the y axis is Shannon entropy divided by `log2(nStates)` and always sits in
`[0, 1]`. Jagged input is padded to a uniform width with nulls first (the
notebook's `_padSeqsWide` step); for ladyna's verb that padding is a **no-op** —
both a short row and a null-padded row contribute nothing past their end — and
it is kept only for exact parity with the source.

Source: `_renderEntropyProfile` (carm-tna's notebook) — the 0–1 y scale with 5
gridlines, the 1-based x labels, the `nPositions > 30` marker shrink
(r 3 → 1.5) and the `Position →  ·  Normalized entropy ↑` caption are verbatim.

`EntropyProfilePlotOptions`:

| option | default | meaning |
|---|---|---|
| `width` | `760` | canvas width |
| `height` | `240` | canvas height (the source's fixed height) |
| `title` / `subtitle` | — | headings |
| `background` | `'#ffffff'` | canvas fill |
| `colors` | Tableau-10 | palette cycled in **group** order |
| `colorMap` | — | colour per **group name**; wins over `colors` |
| `showLegend` | `true` when more than one group | horizontal group legend inside the plot |
| `showPoints` | `true` | per-position markers |
| `trim` | — | `TrimOptions` applied per group before drawing |

A single unnamed block never gets a legend — there is nothing to label.

### plotMeanTimes()

Mean number of positions spent in each state (TraMineR `seqmtplot`), as grouped
horizontal bars: one row per state, one bar per group inside the row, the mean
printed at the bar end, and ±SD whiskers with end caps.

```js
import { plotMeanTimes } from 'ladyna';

const one = plotMeanTimes(sequences, { title: 'Mean time in state' });
const two = plotMeanTimes({ control: a, treatment: b });   // one SVG, two bars per row
```

The numbers come from [`meanTimeInState()`](#meantimeinstate) per group. That
verb uses the **sample** SD (`n - 1`, matching R's `sd()`), so a single-sequence
block has `NaN` for every state — such a bar simply gets **no whisker**, exactly
as the source does. A state with zero variance likewise gets none.

Source: `_renderMeanTimeInState` (carm-tna's notebook) — the `18 + 13·nGroups`
row pitch, the single x scale over `max(mean + SD) × 1.15` shared by every group
and state, the 0.15 / 0.08 band paddings and the
`Mean positions in state (whiskers = ±SD)` caption are verbatim.

`MeanTimesPlotOptions`:

| option | default | meaning |
|---|---|---|
| `width` | `760` | canvas width |
| `height` | `nStates × (18 + 13·nGroups) + 50` (+ heading headroom) | canvas height |
| `title` / `subtitle` | — | headings |
| `background` | `'#ffffff'` | canvas fill |
| `colors` | Tableau-10 | palette cycled in **group** order |
| `colorMap` | — | colour per **group name**; wins over `colors` |
| `showLegend` | `true` when more than one group | horizontal group legend |
| `stateOrder` | every state seen in any group, sorted | explicit row order, top first |
| `showValues` | `true` | the mean printed at the end of each bar |
| `trim` | — | `TrimOptions` applied per group before drawing |

A `stateOrder` entry that no group visited still gets a labelled row, just no
bar; an empty `stateOrder` array is ignored.

### plotMosaic()

A true mosaic (Marimekko) of a contingency table: tile **width** is the row
marginal, tile **height** is that row's split across the columns, and the fill
is the cell's standardized (adjusted) residual under independence — from
[`stdResiduals()`](analysis.md), with the χ² header from `chisqTest()`.

```js
import { plotMosaic } from 'ladyna';

// Transition mosaic — transpose the weights, as the source does.
const n = model.labels.length;
const table = Array.from({ length: n }, (_, i) =>
  Array.from({ length: n }, (_, j) => Math.max(0, model.weights.get(j, i))));
const svg = plotMosaic(table, { rowLabels: model.labels, colLabels: model.labels });
```

**One geometry for both styles: x is always driven by the ROW marginal.**
`renderMosaic` is already that way; `renderClusterMosaic` drives x from the
*column* marginal (its columns are the groups), so to reproduce it pass the
**transpose** — rows = groups, columns = states.

`MosaicPlotOptions`:

| option | default | meaning |
|---|---|---|
| `style` | `'continuous'` | `'continuous'` = diverging RdBu ramp, thin `#333` borders, in-cell values (`renderMosaic`); `'binned'` = the 6-bin discrete palette, dashed borders on negative residuals, thick borders on \|residual\| > 2, χ² header and residual legend (`renderClusterMosaic`) |
| `width` | `450` (continuous) / `max(220, 90·nCols) + 250` (binned) | canvas width |
| `height` | `450` (continuous) / `max(180, 38·nRows) + 105` (binned) | canvas height |
| `title` / `subtitle` | — | headings; for `showChiSq` the χ² summary is appended to the title, as in the source |
| `background` | `'#ffffff'` | canvas fill |
| `rowLabels` | `R1`, `R2`, … | labels for the matrix ROWS (the x tiles) |
| `colLabels` | `C1`, `C2`, … | labels for the matrix COLUMNS (the y splits) |
| `xLabel` | `'Incoming edges'` (continuous) / none (binned) | x-axis title |
| `yLabel` | `'Outgoing edges'` (continuous) / `'State'` (binned) | y-axis title |
| `showValues` | `true` | cell value inside big-enough tiles |
| `showChiSq` | `true` for `'binned'`, `false` otherwise | append `χ²df = X, p = P` to the title |
| `showLegend` | `true` | residual legend — `'binned'` only; the continuous source has none |

**Both styles carry the same polarity: high (over-represented) residuals paint
BLUE, low (under-represented) residuals paint RED.** The binned `RES_BINS`
palette always did (`#2166AC`, `#4393C3` positive; `#D6604D`, `#B2182B`
negative). The Desktop source's continuous ramp did *not* — it shipped
`d3.scaleDiverging(d3.interpolateRdBu).domain([4, 0, -4])`, a reversed domain
that put positive residuals on red and disagreed with its own binned palette —
so ladyna uses `t = 0.5 + residual / 8` instead and the two styles now agree.
Expect a colour flip against Desktop's continuous mosaic; the magnitudes are
identical. *(This paragraph previously documented the un-fixed behaviour and
was stale as of v1.8.8.)*

Throws on an empty (`no cells`) or all-zero (`all zeros`) table.

*Available from:* root, sequences. Tests: `tests/sequence-plots.test.ts` (61).

---

## Pattern painters (self-contained SVG)

Two more painters, same contract as the five above — one `<svg>` string,
`viewBox` + `max-width:100%`, escaped text, `<title>` tooltips, documented
defaults and a throw on empty input. Both are ports of the CarmNote TNA
notebook's d3 figures (`src/tna-notebook_v2.html:12217` for the metric bars,
`notebook-render/pattern-outcome-bars.js` for the stacked bars); the shared
chrome comes from `src/sequences/plots.ts` rather than being duplicated.

### plotPatterns()

```ts
function plotPatterns(
  result: PatternResult | readonly PatternEntry[],
  options?: PatternsPlotOptions,
): string
```

Horizontal bars of a discovered-pattern metric: monospace pattern labels in a
left gutter sized to the longest label that survived `top`, the bar filled from
a single-hue Blues ramp (darker = larger), and the value printed at the bar
end.

```js
import { discoverPatterns, plotPatterns } from 'ladyna';

const found = discoverPatterns(sequences, { len: [2, 3], minFreq: 3 });
const svg = plotPatterns(found, { metric: 'support', top: 12 });
```

| option | default | meaning |
|---|---|---|
| `metric` | `'support'` | `'support'` \| `'frequency'` \| `'lift'` \| `'proportion'` — also the sort key |
| `top` | `25` | keep the first N rows after sorting by `metric`, descending |
| `width` / `height` | `760` / 26px per drawn row + margins | canvas size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |
| `colors` | three ColorBrewer Blues stops | bar ramp, light → dark across the metric range; a one-entry array paints flat |

**Significance badge.** When the discovery was grouped
(`discoverPatterns(data, { group })`, so the entries carry `pValue`), a badge
is drawn in the right gutter: `p=<value>` plus `*` / `**` / `***` at .05 / .01
/ .001, green on `#e8f5e9` when starred and grey on `#f5f5f5` otherwise — the
notebook's colours. An ungrouped result gets no badge and no gutter for one.

**Wildcards are drawn as gaps.** A gapped pattern (`a->**->b`, what
`discoverPatterns({ type: 'gapped' })` produces) renders as `a → ·· → b`: one
middle dot per skipped position, never a state called `*`. The same rule is
exported on its own as `formatPatternLabel(pattern)`.

Throws `no patterns` on an empty result. `PatternMetric` and
`PatternsPlotOptions` are the exported types.

*Available from:* root, sequences. Tests: `tests/pattern-plots.test.ts`.

### plotPatternOutcome()

```ts
function plotPatternOutcome(
  rows: readonly PatternOutcomeCountRow[],
  options?: PatternOutcomePlotOptions,
): string
```

Pattern × outcome-level **stacked** bars: one horizontal bar per pattern, one
segment per level, the segment's share of the row printed inside it when there
is room (the source's 32px gate), and a swatch legend on the right. The x axis
is the raw count.

```js
import { discoverPatterns, patternOutcomeCounts, plotPatternOutcome } from 'ladyna';

const found  = discoverPatterns(sequences, { len: [2], minFreq: 2, topN: 8 });
const counts = patternOutcomeCounts(sequences, found, pass);
const svg    = plotPatternOutcome(counts, { title: 'Patterns by outcome' });
```

| option | default | meaning |
|---|---|---|
| `top` | `10` | keep the biggest N patterns by total count |
| `showValues` | `true` | print the % inside each wide-enough segment |
| `colors` | Tableau-10 | LEVEL palette, cycled in level order |
| `colorMap` | — | colour per outcome level; wins over `colors` |
| `width` / `height` | `760` / 28px per drawn row + margins | canvas size |
| `title` / `subtitle` / `background` | — / — / `'#ffffff'` | standard chrome |

The in-segment label colour follows the fill's **luminance**, not a fixed
choice: `0.299R + 0.587G + 0.114B > 0.62` gets `#1a1a1a`, anything darker gets
white — so a Tableau yellow segment stays readable. That rule is exported as
`barTextColor(hex)` for consumers drawing their own bars in the same palette.

A pattern whose counts are all zero is dropped silently. Throws `no rows` on an
empty list, `no outcome levels` when no row carries a level, and `zero total`
when every pattern was dropped. `PatternOutcomePlotOptions` is the exported
option type.

*Available from:* root, sequences. Tests: `tests/pattern-plots.test.ts`.

### Forest plots of pattern → outcome effects

The generic coefficient/forest painter lives on the analysis surface:
[`plotCoefficients()`](analysis.md#plotcoefficientsitems-options) takes plain
`{ name, estimate, ci, p }` rows, so `patternOutcome().rows` map straight into
it — odds ratios with `refValue: 1, logScale: true`, continuous βs with
`refValue: 0`.
