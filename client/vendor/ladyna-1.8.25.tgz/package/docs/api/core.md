# ladyna/core — Model layer

The core module is the foundation of ladyna: it turns sequence data into weighted
directed transition networks (`TNA` models) and provides everything those models
are made of. It contains the model factories (`tna`, `ftna`, `ctna`, `atna`,
`buildModel`), the `Float64Array`-backed `Matrix` class with all shared linear
algebra (row-normalisation, scaling, LU solve, stationary distributions), data
preparation for wide sequences (`prepareData`) and long event logs
(`prepareLong`, the R `tna::prepare_data` counterpart), grouped models
(`GroupTNA` builders and helpers), the seeded RNG used by every stochastic
analysis, the R-TNA colour palettes, and the SVG network painters —
`plotNetwork` (the JS analogue of R `plot.tna()`) with its data verb
`networkPlotData`, the difference painter `plotDifferenceNetwork`, and the
small-multiples grid `plotNetworkGrid`. Numerical semantics are pinned to the R
**`tna`** package v1.2.3 — matching R output to 1e-10..1e-15 is a hard
requirement for the computational functions (rendering functions are exempt).

All exports use camelCase; the core module has no R-style snake_case aliases
(snake aliases such as `cluster_summary` or `process_map` live in the analysis,
processmining, htna, and lagdynamics modules).

## Import

```js
import { tna, prepareLong, plotNetwork, Matrix, SeededRNG } from 'ladyna';
// or the core subpath only:
import { tna, buildModel, groupTna } from 'ladyna/core';
```

**Availability.** Unless a section says otherwise, every export below is
importable from root `ladyna`, `ladyna/core`, `ladyna/light`, and `ladyna/full`
(see `docs/api/exports.md` for the generated matrix). Exceptions:

| export | root | core | light | full | note |
|---|---|---|---|---|---|
| `solveLinear` | ✓ | ✓ | ✓ | ✓ | also from `ladyna/analysis` |
| `designMatrix` | ✓ | ✓ | — | ✓ | not in `ladyna/light` |
| `networkEdgeGeometry` | ✓ | ✓ | — | — | root and core only |
| `networkArrowPolygon` | ✓ | ✓ | — | — | root and core only |
| `networkSelfLoopGeometry` | ✓ | ✓ | — | — | root and core only |
| `prepareLong` | ✓ | ✓ | ✓ | ✓ | also from `ladyna/lagdynamics` |

---

## Model factories

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

A `TNA` model is a plain object: `{ weights: Matrix, inits: Float64Array,
labels: string[], data: SequenceData | null, type: ModelType,
scaling: string[], params?, counts? }`. `counts` holds the raw transition
counts (R's `$frequency_matrix`) whenever the model was built from sequences —
several analyses (`certainty()`, `bayesCompare()`) need integers that a
normalised `weights` can no longer supply.

### `buildModel(x, options?)`

```ts
buildModel(
  x: SequenceData | TNAData | number[][],
  options?: BuildModelOptions,
): TNA
```

The general factory behind `tna`/`ftna`/`ctna`/`atna`. Accepts wide sequence
data (arrays of state strings, `null`/`''` = missing), a `TNAData` container
from `prepareData()`, or a square numeric weight matrix (`number[][]`) used
directly. State labels are auto-detected (sorted unique states) unless given.

`BuildModelOptions`:

| option | type | default | meaning |
|---|---|---|---|
| `type` | `ModelType` | `'relative'` | transition model type (see `ModelType` under Types) |
| `scaling` | `string \| string[] \| null` | `null` | post-hoc scaling: `'minmax'`, `'max'`, `'rank'` — applied in order |
| `labels` | `string[]` | auto-detected | state labels (row/column order of `weights`) |
| `beginState` | `string` | — | prepend this state to every sequence |
| `endState` | `string` | — | append this state to every sequence |
| `params` | `TransitionParams` | — | type-specific parameters (`n`, `maxGap`, `decay`, `size`, `beta`, windowing) |

### `tna(x, options?)`

```ts
tna(x: SequenceData | TNAData | number[][], options?: Omit<BuildModelOptions, 'type' | 'params'>): TNA
```

Build a **relative** (row-normalised transition probability) model — the R
`tna::tna()` default. Each row of `weights` sums to 1 (zero rows stay zero);
`inits` is the distribution of first states.

```js
import { tna, summary } from 'ladyna';

const model = tna([
  ['plan', 'discuss', 'execute', 'reflect'],
  ['plan', 'execute', 'execute', 'reflect'],
  ['discuss', 'plan', 'execute', null],
]);
console.log(model.labels);
// [ 'discuss', 'execute', 'plan', 'reflect' ]
console.log(model.weights.to2D().map(r => r.map(v => +v.toFixed(4))));
// [ [ 0, 0.5, 0.5, 0 ],
//   [ 0, 0.3333, 0, 0.6667 ],
//   [ 0.3333, 0.6667, 0, 0 ],
//   [ 0, 0, 0, 0 ] ]
console.log(summary(model));
// { nStates: 4, type: 'relative', scaling: [], nEdges: 6, density: 0.375,
//   meanWeight: 0.5, maxWeight: 0.6666666666666666, hasSelfLoops: true }
```

### `ftna(x, options?)`

```ts
ftna(x: SequenceData | TNAData | number[][], options?: Omit<BuildModelOptions, 'type' | 'params'>): TNA
```

Build a **frequency** model: `weights` holds raw transition counts (no
normalisation). Matches R `tna::ftna()`.

### `ctna(x, options?)`

```ts
ctna(x: SequenceData | TNAData | number[][] | OnehotSequenceData, options?: Omit<BuildModelOptions, 'type'>): TNA
```

Build a **co-occurrence** model: all ordered pairs `(i, j)` with `i < j` in a
sequence count, symmetrised. When passed the `OnehotSequenceData` result of
`importOnehot()`, its window metadata is threaded through automatically as
windowed co-occurrence (R's `compute_transitions_windowed`). Matches R
`tna::ctna()`.

### `atna(x, options?)`

```ts
atna(x: SequenceData | TNAData | number[][], options?: Omit<BuildModelOptions, 'type'> & { beta?: number }): TNA
```

Build an **attention** model: every forward pair contributes
`exp(-beta * distance)`. `beta` defaults to `1`, matching R `tna::atna()` —
note R writes the same kernel as `exp(-|i-j| / lambda)` with `lambda = 1`, so
**beta = 1 / lambda**; `beta: 0.1` is not a mild decay, it is `lambda = 10`.

```js
import { atna } from 'ladyna';
const m = atna([['a','b','c'], ['c','b','a']]);
console.log(m.type, m.params);
// attention { beta: 1 }
console.log(m.weights.to2D().map(r => r.map(v => +v.toFixed(4))));
// [ [ 0, 0.3679, 0.1353 ],
//   [ 0.3679, 0, 0.3679 ],
//   [ 0.1353, 0.3679, 0 ] ]
```

### `createTNA(weights, inits, labels, data?, type?, scaling?, params?, counts?)`

```ts
createTNA(
  weights: Matrix,
  inits: Float64Array,
  labels: string[],
  data: SequenceData | null = null,
  type: ModelType = 'relative',
  scaling: string[] = [],
  params?: TransitionParams,
  counts?: Matrix,
): TNA
```

Low-level constructor that assembles a `TNA` object from already-computed
parts. Prefer the factories above; use this when you have precomputed weights
(e.g. from `computeWeightsFrom3D`).

### `summary(model)`

```ts
summary(model: TNA): Record<string, unknown>
```

Compact model summary: `nStates`, `type`, `scaling`, `nEdges` (weights > 0),
`density`, `meanWeight` (mean of non-zero weights), `maxWeight`,
`hasSelfLoops`. See the `tna()` example above for real output.

---

## Matrix class and matrix ops

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

### `class Matrix`

```ts
new Matrix(rows: number, cols: number, data?: Float64Array | number[])
```

Row-major `Float64Array`-backed dense matrix, designed for the small matrices
TNA works with (3×3 to ~30×30; HON adjacencies up to ~100). Fields:
`data: Float64Array` (readonly), `rows`, `cols`. Throws if `data.length !==
rows * cols`.

Static constructors:

| method | signature | meaning |
|---|---|---|
| `Matrix.from2D` | `(arr: number[][]) => Matrix` | build from nested arrays |
| `Matrix.eye` | `(n: number) => Matrix` | identity |
| `Matrix.zeros` | `(rows, cols) => Matrix` | zero matrix |
| `Matrix.fill` | `(rows, cols, value) => Matrix` | constant matrix |
| `Matrix.diag` | `(values: Float64Array \| number[]) => Matrix` | diagonal matrix from a vector |
| `Matrix.outer` | `(a, b) => Matrix` | outer product of two vectors |

Instance methods (all pure — they return new matrices — except `set`):

| method | signature | meaning |
|---|---|---|
| `get` / `set` | `(i, j)` / `(i, j, value)` | element access (row `i`, col `j`) |
| `clone` | `() => Matrix` | deep copy |
| `to2D` | `() => number[][]` | nested-array view |
| `transpose` | `() => Matrix` | transpose |
| `matmul` | `(other: Matrix) => Matrix` | matrix product `this @ other` |
| `add` / `sub` / `mul` | `(other: Matrix) => Matrix` | element-wise +, −, × |
| `scale` | `(s: number) => Matrix` | scalar multiply |
| `map` | `(fn: (v, i, j) => number) => Matrix` | element-wise apply |
| `sum` | `() => number` | sum of all elements |
| `rowSums` / `colSums` | `() => Float64Array` | marginal sums |
| `diag` | `() => Float64Array` | diagonal values |
| `setDiag` | `(value: number) => Matrix` | copy with constant diagonal |
| `setDiagFrom` | `(values) => Matrix` | copy with diagonal from a vector |
| `max` / `min` | `() => number` | extreme element |
| `count` | `(pred: (v) => boolean) => number` | count matching elements |
| `any` | `(pred: (v) => boolean) => boolean` | any element matches |
| `flatten` | `() => Float64Array` | row-major copy of the data |
| `flattenColMajor` | `() => Float64Array` | column-major (R's `as.vector`) |
| `row` / `col` | `(i) => Float64Array` | one row / column |
| `subMatrix` | `(rowIndices: number[], colIndices: number[]) => Matrix` | index-based sub-matrix |
| `quantile` | `(p: number) => number` | linear-interpolated quantile of all elements |
| `isSquare` | getter `boolean` | rows === cols |
| `meanNonZero` | `() => number` | mean of elements > 0 |
| `inverse` | `() => Matrix` | Gauss-Jordan inverse (throws on singular) |

### `rowNormalize(mat)`

```ts
rowNormalize(mat: Matrix): Matrix
```

Divide each row by its sum so rows sum to 1; all-zero rows are left as zeros
(division by zero avoided). This is the `'relative'` model's normalisation.

```js
import { Matrix, rowNormalize } from 'ladyna';
rowNormalize(Matrix.from2D([[2, 1], [0, 3]])).to2D();
// [ [ 0.6666666666666666, 0.3333333333333333 ], [ 0, 1 ] ]
```

### `minmaxScale(mat)` / `maxScale(mat)` / `rankScale(mat)`

```ts
minmaxScale(mat: Matrix): Matrix   // (v - min) / (max - min); all-equal → zeros
maxScale(mat: Matrix): Matrix      // v / max; max 0 → unchanged clone
rankScale(mat: Matrix): Matrix     // 1-based ranks, average ties — R rank(x, ties.method = "average")
```

The three scaling primitives behind the `scaling` build option. `rankScale`
ranks **all** cells including zeros, matching R.

### `applyScaling(mat, scaling)`

```ts
applyScaling(mat: Matrix, scaling: string | string[] | null | undefined):
  { weights: Matrix; applied: string[] }
```

Apply one or more of `'minmax'`, `'max'`, `'rank'` in order; returns the scaled
matrix and the list of methods actually applied. Unknown method names throw.
Note: for **grouped** models, scaling is applied globally across all groups
(R `scale_weights_global`), not per group — see the group builders below.

### Array helpers

```ts
arrayMean(arr: Float64Array): number                 // mean (0 for empty)
arrayStd(arr: Float64Array, ddof = 1): number        // sample SD (ddof=1, like R sd())
pearsonCorr(a: Float64Array, b: Float64Array): number // Pearson r (NaN if <2 or zero variance)
arrayQuantile(arr: Float64Array, p: number): number  // linear-interpolated quantile
```

---

## Linear algebra

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`
(`solveLinear` also from `ladyna/analysis`).

### `solveLinear(A, b)`

```ts
solveLinear(A: Matrix, b: Matrix | Float64Array | number[]): Matrix
```

Solve `A·x = b` by LU decomposition with partial pivoting — the behaviour of R
`base::solve(A, b)` for well-conditioned systems. `b` may be an n-vector or an
n×m matrix; the result has the same shape (a vector comes back as an n×1
`Matrix`). Throws on non-square or (near-)singular `A` (pivot < 1e-14).

```js
import { Matrix, solveLinear } from 'ladyna';
solveLinear(Matrix.from2D([[3, 1], [1, 2]]), [9, 8]).to2D();
// [ [ 2 ], [ 3 ] ]
```

### `eigenDominantLeft(P)`

```ts
eigenDominantLeft(P: Matrix): Float64Array
```

Stationary distribution π of a row-stochastic matrix `P` (πᵀP = πᵀ, Σπ = 1) —
equivalent to R's `.mpt_stationary` eigen-decomposition, computed via the
closed-form linear solve `(I − Pᵀ + (1/n)·J)·π = (1/n)·1`. Throws when a row
sum is ≤ 0 (chain not ergodic). Used by the Markov-chain routines
(`passageTime`, `markovStability`).

```js
import { Matrix, eigenDominantLeft } from 'ladyna';
Array.from(eigenDominantLeft(Matrix.from2D([[0.9, 0.1], [0.5, 0.5]])));
// [ 0.8333333333333334, 0.16666666666666663 ]
```

---

## Data preparation

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`
(`prepareLong` also from `ladyna/lagdynamics`; `designMatrix` not in `ladyna/light`).

### `prepareData(data, options?)`

```ts
prepareData(
  data: SequenceData,
  options?: { beginState?: string; endState?: string },
): TNAData
```

Wrap wide-format sequence data into a `TNAData` container with detected labels
and summary statistics. The result can be passed straight to any model factory.

```js
import { prepareData } from 'ladyna';
prepareData([['a', 'b'], ['b', 'a', 'b']]).statistics;
// { nSessions: 2, nUniqueActions: 2, uniqueActions: [ 'a', 'b' ],
//   maxSequenceLength: 3, meanSequenceLength: 2.5 }
```

### `createSeqdata(data, options?)`

```ts
createSeqdata(
  data: SequenceData,
  options?: { beginState?: string; endState?: string },
): { data: SequenceData; labels: string[] }
```

Lower-level piece of `prepareData`: detect sorted unique state labels and
optionally prepend a `beginState` / append an `endState` to every sequence
(the artificial states are added to the label set as first/last).

### `importOnehot(data, cols, options?)`

```ts
importOnehot(
  data: Record<string, number | string>[],
  cols: string[],
  options?: {
    actor?: string;
    session?: string;
    windowSize?: number;        // R window_size: rows per sub-window (default 1)
    interval?: number;          // R interval: sub-windows per output sequence (default: all)
    windowType?: 'tumbling' | 'sliding';  // default 'tumbling'
    aggregate?: boolean;        // default false
  },
): OnehotSequenceData
```

Convert one-hot encoded rows (0/1 indicator columns) into wide sequence data,
matching R `tna::import_onehot()` (dev branch). Rows are optionally grouped by
`actor`/`session`, chunked into sub-windows of `windowSize` rows (tumbling, or
R's lag-expansion sliding windows), and every `interval` sub-windows become one
output sequence. The result carries `windowSize`/`windowSpan` metadata that
`ctna()` consumes to compute windowed co-occurrence.

### `prepareLong(rows, headers, options)`

```ts
prepareLong(
  rows: readonly (readonly unknown[])[],
  headers: readonly string[],
  options: PrepareLongOptions,
): PrepareLongResult
```

The long event-log → wide-sequences pivot **with metadata** — the engine's
counterpart to R `tna::prepare_data(data, actor, time, action, order,
time_threshold, unused_fn)`. Events are grouped by actor, ordered by time (then
`order`, then original row order), optionally cut into sessions on inactivity
gaps, and pivoted into ragged wide sequences. Everything the pivot did not
consume survives as one metadata row per session (R keeps the actor and the
raw time column too; time collapses to the session start).

`PrepareLongOptions`:

| option | type | default | meaning |
|---|---|---|---|
| `actor` | `string \| number` | required | actor/participant column (name or index) |
| `action` | `string \| number` | required | event/state column that becomes the sequence |
| `time` | `string \| number` | — | timestamp column, for ordering and session cutting; a numeric column is used as-is (seconds), a datetime column is parsed and converted to seconds |
| `order` | `string \| number` | — | explicit ordering column, used when `time` is absent or ties. R (`tna`, `Nestimate`) **sorts on it**; a column that restarts inside a sequence (a position-within-line index) will re-sequence events — check `statistics.sessionsReordered`. Numeric when every non-blank value is a number, else sorted as text; a blank/NA value sorts **last** (R `na.last = TRUE`) |
| `session` | `string \| number` | — | explicit session column, **nested in `actor`** (`Nestimate::prepare(session=)`; `tna::prepare_data` has no equivalent). One sequence per (actor, session) pair; the gap cut runs inside the pair |
| `timeThreshold` | `number` | undefined = never cut | cut a session when the gap **exceeds** this many seconds (R `time_threshold`); `0` cuts on any positive gap — it does not mean "never". A missing time sorts last and always starts a new session (R: `is.na(gap)` ⇒ new session), threshold or not |
| `numericAgg` | `'first' \| 'last' \| 'sum' \| 'mean' \| 'mode'` | `'mean'` | collapse rule for a repeated numeric metadata column |
| `categoricalAgg` | `'first' \| 'last' \| 'mode'` | `'mode'` | collapse rule for a repeated categorical column |

The time column always collapses to `'first'` (session start), whatever
`numericAgg` says. Columns that were **not** constant within a session are
reported in `meta.varying` rather than silently averaged away. The result also
carries `ids` (R's `<actor> session<N>` format, or `<actor> <session>` when a
`session` column was given), `actors`, `sessions` (the explicit session value,
or `null`), `sessionNr` (counted within the actor), `seqRowIndices` (the raw row
indices per session — the exact join key), `times`, and a `statistics` block
(including `sessionsFromGap`, `sessionsPerActor`, which flags nested sessions,
and `sessionsReordered` — how many sequences the `time`/`order` sort changed
relative to file order; a caller should warn when it is non-zero and only
`order` was supplied).

Pinned to `tna::prepare_data` (30 datasets) and, for `session` and the
`order` contract, to `Nestimate::prepare` / `build_network` over the full
session × order × time factorial (40 datasets × 12 mappings,
`tools/generate-prepare-long-session-fixtures.R`).

```js
import { prepareLong } from 'ladyna';

const headers = ['user', 'time', 'event', 'score'];
const rows = [
  ['u1', 0,    'plan',    3],
  ['u1', 60,   'execute', 5],
  ['u1', 5000, 'reflect', 4],
  ['u2', 10,   'plan',    2],
  ['u2', 40,   'discuss', 2],
];
const res = prepareLong(rows, headers,
  { actor: 'user', time: 'time', action: 'event', timeThreshold: 900 });
console.log(res.ids);
// [ 'u1 session1', 'u1 session2', 'u2 session1' ]
console.log(res.sequences);
// [ [ 'plan', 'execute' ], [ 'reflect' ], [ 'plan', 'discuss' ] ]
console.log(res.meta.columns);
// [ '.session_id', 'user', 'time', 'score', '.session_nr' ]
console.log(res.meta.rows);
// [ [ 'u1 session1', 'u1', 0, 4, 1 ],
//   [ 'u1 session2', 'u1', 5000, 4, 2 ],
//   [ 'u2 session1', 'u2', 10, 2, 1 ] ]
```

### `designMatrix(meta, terms, options?)`

```ts
designMatrix(
  meta: MetaData,
  terms: readonly string[],
  options?: { reference?: Record<string, string> },
): DesignMatrix
```

R's `model.matrix` for `prepareLong` metadata, so a factor can enter a
covariate model. A numeric column enters as itself; a factor with L levels
enters as L−1 dummies (named `col=level`) against a dropped reference level
(first level alphabetically, or `options.reference[col]`). No intercept column
is added (`mmm` adds one). Sessions with a missing term are dropped and
reported in `dropped` — a hole in X is never imputed to 0. Throws on unknown
terms and constant factors.

```js
import { prepareLong, designMatrix } from 'ladyna';
// res = prepareLong(...) with a 'condition' column: 'ctrl'/'exp'
const dm = designMatrix(res.meta, ['condition']);
console.log(dm.names, dm.reference, dm.X);
// [ 'condition=exp' ] { condition: 'ctrl' } [ [ 0 ], [ 1 ], [ 1 ] ]
```

### `parseTimeValue(raw)`

```ts
parseTimeValue(raw: unknown): number | null
```

A timestamp as a sortable number: a finite number is returned unchanged, any
other value is tried as a date (`Date.parse` milliseconds); `null` when
neither. `prepareLong` decides per **column** (as R's `is.numeric` does)
whether values are already seconds or need parsing.

### `isNumericColumn(vals)`

```ts
isNumericColumn(vals: readonly string[]): boolean
```

Is a column a measurement or a factor? True when every non-blank value parses
as a finite number — and nothing else. A 0/1 flag **is** numeric (deliberately:
a binary indicator is a perfectly good regressor).

---

## Transitions helpers

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

These are the computational kernels the factories delegate to; reach for them
when you need per-sequence counts (bootstrap, permutation) or want to assemble
a model from precomputed matrices.

### `computeTransitions(data, states, type?, params?)`

```ts
computeTransitions(
  data: SequenceData,
  states: string[],
  type: ModelType = 'relative',
  params?: TransitionParams,
): { weights: Matrix; inits: Float64Array }
```

Compute the pooled transition matrix and initial-state distribution for any
`ModelType` (`'relative'`, `'frequency'`, `'co-occurrence'` — plain or
windowed, `'reverse'`, `'n-gram'`, `'gap'`, `'window'`, `'attention'`).
Missing values (`null`/`''`) are skipped, so transitions bridge gaps.
`params` defaults: `n: 2` (n-gram), `maxGap: 5`, `decay: 0.5` (gap),
`size: 3` (window), `beta: 1` (attention).

### `computeTransitions3D(data, states, type?, params?)`

```ts
computeTransitions3D(
  data: SequenceData,
  states: string[],
  type: ModelType = 'relative',
  params?: TransitionParams,
): Matrix[]
```

Per-sequence transition counts: one `nStates × nStates` matrix per sequence
(R TNA's `compute_transitions`). Supports `'relative'`/`'frequency'`
(adjacent, positional — unlike `computeTransitions` it walks columns, so a
missing value breaks the pair), `'reverse'`, `'co-occurrence'` (plain and
windowed), and `'attention'`. This is the resampling unit for bootstrap and
permutation.

### `computeWeightsFrom3D(transitions, type?, scaling?)`

```ts
computeWeightsFrom3D(
  transitions: Matrix[],
  type: ModelType = 'relative',
  scaling?: string | string[] | null,
): Matrix
```

Sum an array of per-sequence matrices into one weight matrix, row-normalise
when `type === 'relative'`, then apply optional scaling. Throws on an empty
array.

### `computeWeightsFromMatrix(mat, type?)`

```ts
computeWeightsFromMatrix(mat: Matrix, type: ModelType = 'relative'): Matrix
```

Process a direct weight/count matrix input: row-normalise for `'relative'`,
otherwise return an untouched clone. This is what `buildModel` calls when
handed a square `number[][]`.

---

## Group models

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

A `GroupTNA` is `{ models: Record<string, TNA> }` — one model per group,
sharing one label set.

### `groupTna(data, groups, options?)` / `groupFtna` / `groupCtna` / `groupAtna`

```ts
groupTna(data: SequenceData, groups: string[], options?: Omit<BuildModelOptions, 'type' | 'params'>): GroupTNA
groupFtna(data: SequenceData, groups: string[], options?: Omit<BuildModelOptions, 'type' | 'params'>): GroupTNA
groupCtna(data: SequenceData, groups: string[], options?: Omit<BuildModelOptions, 'type' | 'params'>): GroupTNA
groupAtna(data: SequenceData, groups: string[], options?: Omit<BuildModelOptions, 'type'> & { beta?: number }): GroupTNA
```

Build one model per group (`groups[i]` labels sequence `data[i]`; groups are
kept in first-appearance order). Labels are detected across **all** groups so
every model shares the same state space. When `scaling` is requested it is
applied **globally** across all groups' weights pooled column-major — R's
`scale_weights_global` — not per group; for the relative type, rows are
re-normalised first. `groupAtna`'s `beta` defaults to 1, as in `atna`.

```js
import { groupTna, groupNames } from 'ladyna';
const g = groupTna(
  [['a','b','a'], ['b','a','b'], ['a','a','b'], ['b','b','a']],
  ['g1', 'g1', 'g2', 'g2'],
);
console.log(groupNames(g));       // [ 'g1', 'g2' ]
console.log(g.models['g1'].weights.to2D());
// [ [ 0, 1 ], [ 1, 0 ] ]
```

### `createGroupTNA(models)`

```ts
createGroupTNA(models: Record<string, TNA>): GroupTNA
```

Wrap an existing name → model record as a `GroupTNA`.

### `isGroupTNA(x)`

```ts
isGroupTNA(x: unknown): x is GroupTNA
```

Duck-typed guard (`'models' in x`). Every polymorphic analysis verb uses this
to dispatch between `TNA` and `GroupTNA`.

### `isHtna(x)`

```ts
isHtna(x: unknown): x is TNA & { partition: string[]; actorLevels: string[] }
```

True when a `TNA` carries a populated actor `partition` (one tag per node) —
HTNA is a plain `TNA` plus that field, not a separate class. Populated by the
`htna()` factory (in `ladyna/htna`).

### `groupNames(g)` / `groupEntries(g)` / `groupApply(g, fn)`

```ts
groupNames(g: GroupTNA): string[]
groupEntries(g: GroupTNA): [string, TNA][]
groupApply<T>(g: GroupTNA, fn: (model: TNA, name: string) => T): Record<string, T>
```

Iteration helpers over a group model: names, `[name, model]` pairs, and
map-over-groups returning a name-keyed record.

### `renameGroups(g, newNames)`

```ts
renameGroups(g: GroupTNA, newNames: string[]): GroupTNA
```

Return a new `GroupTNA` with the groups renamed in order. Throws when the
lengths do not match.

---

## SeededRNG

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

### `class SeededRNG`

```ts
new SeededRNG(seed: number)
```

Reproducible pseudo-random number generator — xoshiro128\*\* (32-bit) seeded
via splitmix32, no BigInt. Every stochastic analysis in ladyna (bootstrap,
permutation, stability, simulate…) threads a `seed` through to one of these,
so results are exactly reproducible per seed. Note this is ladyna's own stream —
it does **not** reproduce R's Mersenne-Twister draws; cross-language parity
tests compare distributions/statistics, not individual draws.

Methods (the raw 32-bit generator `.next()` is **private** — use the methods
below):

| method | signature | meaning |
|---|---|---|
| `random` | `(): number` | uniform float in `[0, 1)` |
| `randInt` | `(max: number): number` | integer in `[0, max)` |
| `shuffle` | `<T>(arr: T[]): T[]` | Fisher-Yates shuffle, **in place** (also returned) |
| `permutation` | `(n: number): number[]` | random permutation of `[0, n)` |
| `choice` | `(n: number, size: number): number[]` | `size` draws from `[0, n)` **with** replacement |
| `choiceWithoutReplacement` | `(n: number, size: number): number[]` | `size` distinct draws from `[0, n)` (partial Fisher-Yates); throws if `size > n` |

```js
import { SeededRNG } from 'ladyna';
const rng = new SeededRNG(42);
console.log(rng.random());        // 0.4690228053368628
console.log(rng.randInt(10));     // 5
console.log(rng.permutation(5));  // [ 3, 1, 2, 4, 0 ]
console.log(new SeededRNG(42).choiceWithoutReplacement(10, 3)); // [ 4, 6, 2 ]
```

---

## Colors

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

### Palettes

```ts
DEFAULT_COLORS: string[]   // 9 colors — the R TNA package node palette
ACCENT_PALETTE: string[]   // 8 colors — ColorBrewer Accent
SET3_PALETTE: string[]     // 12 colors — ColorBrewer Set3
```

### `colorPalette(nStates, palette?)`

```ts
colorPalette(nStates: number, palette?: 'default' | 'accent' | 'set3' | 'hcl'): string[]
```

Return `nStates` hex colors. With no `palette`: Accent for ≤ 8, Set3 for ≤ 12,
generated qualitative HCL beyond that. A named palette is sliced (and extended
with HCL colors when it runs out); `'hcl'` always generates.

```js
import { colorPalette } from 'ladyna';
colorPalette(3);   // [ '#7fc97f', '#beaed4', '#fdc086' ]
```

### `createColorMap(labels, colors?)`

```ts
createColorMap(labels: string[], colors?: string[]): Record<string, string>
```

Map state labels to colors (cycling when `colors` is shorter than `labels`;
defaults to `DEFAULT_COLORS`). Pass the result as `plotNetwork`'s `colorMap` to
keep state colors identical across side-by-side plots.

The default is `DEFAULT_COLORS` — the same palette `plotNetwork` uses — so the
idiom below only *pins* each state's color by name and does not recolor the
plot. For the auto-selected Accent/Set3/HCL palettes pass
`colorPalette(labels.length)` explicitly.

```js
createColorMap(['A', 'B', 'C']);
// { A: '#d1ea2c', B: '#fd5306', C: '#68b033' }

// Same colors in every panel, regardless of each model's state order:
plotNetwork(model, { colorMap: createColorMap(allStates) });

// Opt into the ColorBrewer palettes instead:
createColorMap(['A', 'B', 'C'], colorPalette(3));
// { A: '#7fc97f', B: '#beaed4', C: '#fdc086' }
```

### Color conversion helpers

```ts
hexToRgb(hex: string): [number, number, number]  // '#rrggbb' → [r, g, b] 0-255
rgbToHex(r: number, g: number, b: number): string
lightenColor(hex: string, amount = 0.3): string  // blend toward white
darkenColor(hex: string, amount = 0.3): string   // scale toward black
```

---

## Network drawing geometry

Available from: `ladyna` and `ladyna/core` **only** (not in `ladyna/light` /
`ladyna/full`).

Shared SVG geometry used by `plotNetwork`, the demo, and the notebook
renderers — exported so custom renderers stay pixel-consistent with the
built-in painter. All return a `NetworkEdgeGeometry`:
`{ path, tipX, tipY, tipDx, tipDy, labelX, labelY }` (SVG path string, arrow
tip position and unit direction, label anchor).

### `networkEdgeGeometry(sx, sy, tx, ty, sourceRadius, targetRadius?, curvature?, arrowLength?)`

```ts
networkEdgeGeometry(
  sx: number, sy: number,          // source center
  tx: number, ty: number,          // target center
  sourceRadius: number,
  targetRadius = sourceRadius,
  curvature = 0,                   // perpendicular offset of the control point; 0 = straight line
  arrowLength = 8,
  labelPosition = 0.55,            // Bézier t for labelX/labelY: 0 = source boundary, 1 = arrow base
): NetworkEdgeGeometry
```

Quadratic (or straight, when `curvature` is 0) edge from painted node boundary
to painted node boundary, leaving room for the arrowhead. Degenerate edges
(< 1px apart) return an empty `path`.

### `networkArrowPolygon(tipX, tipY, dx, dy, length?, halfWidth?)`

```ts
networkArrowPolygon(
  tipX: number, tipY: number,
  dx: number, dy: number,          // unit direction (from geometry.tipDx/tipDy)
  length = 7,
  halfWidth = 3.5,
): string                          // SVG <polygon points="..."> value
```

Filled triangle arrowhead at an edge tip.

### `networkSelfLoopGeometry(x, y, nodeRadius, outwardAngle, reach?)`

```ts
networkSelfLoopGeometry(
  x: number, y: number,
  nodeRadius: number,
  outwardAngle: number,            // radians; direction the loop bulges
  reach = nodeRadius * 1.15,
): NetworkEdgeGeometry
```

Compact outward cubic self-loop anchored on the node boundary, label placed
past the loop's outer edge.

---

## plotNetwork

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

### `plotNetwork(model, options?)`

```ts
plotNetwork(model: TNA, options?: NetworkPlotOptions): string
plotNetwork(model: GroupTNA, options?: NetworkPlotOptions): Record<string, string>
```

Self-contained SVG transition-network plot — the JS analogue of R `plot.tna()`
(qgraph circle layout): nodes on a circle starting at 12 o'clock, weight-scaled
curved edges with probability labels (reciprocal edges get opposite curvature),
and an initial-probability ring around each node standing in for qgraph's pie.
Returns a complete `<svg>` string; a `GroupTNA` yields one SVG per group (keyed
by group name, each titled with it). Rendering only — no R numerical-parity
requirement. Throws when the model has no states. Edge width scales with
`sqrt(|w| / max|w|)` between `edgeWidthMin` and `edgeWidthMax`; edges are drawn
weakest-first so strong edges stay on top. To *filter* edges statistically use
`prune()` — `cutoff` only hides them visually.

**Every option defaults to the painter's historical literal**, so
`plotNetwork(model)` is byte-stable and any knob you don't pass changes nothing.

**`GroupTNA` and `title`.** For a `GroupTNA` the `title` option is *ignored*:
each SVG is always titled with its own group name, because that is what the
record's keys promise. Every other option is forwarded to all groups unchanged.

#### Core options

| option | type | default | meaning |
|---|---|---|---|
| `width` | `number` | `760` | SVG canvas width |
| `height` | `number` | `560` | SVG canvas height |
| `title` | `string` | — | heading rendered inside the SVG (ignored for `GroupTNA` — the group name always wins) |
| `subtitle` | `string` | — | second heading line |
| `background` | `string` | `'#ffffff'` | canvas background |
| `colors` | `string[]` | `DEFAULT_COLORS` | node palette (R TNA parity) |
| `colorMap` | `Record<string, string>` | — | color per state label; wins over `colors`, keeps colors stable across side-by-side plots |
| `cutoff` | `number` | `0` | hide edges with \|weight\| ≤ cutoff |
| `edgeLabels` | `boolean` | `true` | draw numeric edge labels |
| `decimals` | `number` | `0` for frequency models, else `2` | digits on edge labels |
| `initRing` | `boolean` | on when any init > 0 | initial-probability ring around each node |
| `nodeRadius` | `number` | `23`, auto-shrunk on crowded circles (min 9) | node disc radius |
| `edgeColor` | `string` | `'#2B4C7E'` | edge stroke color |
| `edgeWidthMin` | `number` | `0.55` | minimum rendered edge width (SVG units) |
| `edgeWidthMax` | `number` | `2.8` | maximum rendered edge width (SVG units) |
| `positions` | `{x,y}[]` \| `ReadonlyMap<string,{x,y}>` | — | explicit node coordinates — see below |

#### Node-label options

| option | type | default | meaning |
|---|---|---|---|
| `showLabels` | `boolean` | `true` | draw the state label inside each disc |
| `labelSize` | `number` | `10` | node-label font size in px |
| `labelColor` | `string` | `'#1f2937'` | node-label fill |
| `truncateLabels` | `number` | `Infinity` | shorten drawn labels to N chars + `…`; the **full** label stays in the node's `<title>` tooltip |

#### Edge-label options

| option | type | default | meaning |
|---|---|---|---|
| `edgeLabelSize` | `number` | `9` | edge-label font size in px |
| `edgeLabelColor` | `string` | `'#444'` | edge-label fill |
| `edgeLabelMin` | `number` | `0` | don't annotate edges with \|weight\| below this — the edge is still **drawn**, only its number is suppressed |
| `edgeLabelOffset` | `number` | `3` | vertical nudge of the label baseline off the curve, in px |
| `labelPosition` | `number` | `0.55` | where along the edge the label sits, as the Bézier parameter t (0 = source node, 1 = arrowhead) |

#### Edge-rendering options

| option | type | default | meaning |
|---|---|---|---|
| `edgeOpacity` | `number` \| `[number, number]` | `0.8` | scalar opacity for every edge, or `[min, max]` ramped linearly by \|weight\|/max\|weight\|. Arrowheads are drawn 0.1 more opaque than their edge |
| `curvature` | `number` | `24` | perpendicular Bézier offset separating a reciprocal edge pair; `0` draws every edge straight |
| `arrows` | `boolean` | `true` | draw arrowheads; `false` also un-shortens the edges |
| `arrowScale` | `number` | `1` | multiplier on the weight-derived head length (`5.5 + 2·width`) |
| `showSelfLoops` | `boolean` | `true` | draw self-loops |
| `edgeStyle` | `'solid'` \| `'dashed'` \| `'dotted'` | `'solid'` | dash pattern for every edge (`5,3` / `1,3`) |
| `edgeWidthScale` | `'sqrt'` \| `'linear'` | `'sqrt'` | how \|weight\| maps onto stroke width |
| `edgeColorBy` | `'flat'` \| `'weight'` \| `'sign'` | `'flat'` | see below |
| `edgeColorPositive` | `string` | `EDGE_COLOR_POSITIVE` (`'#4f8a55'`) | stroke for positive edges under `edgeColorBy: 'sign'` |
| `edgeColorNegative` | `string` | `EDGE_COLOR_NEGATIVE` (`'#a85050'`) | stroke for negative edges under `edgeColorBy: 'sign'` |

`edgeColorBy`:

- `'flat'` — every edge is `edgeColor` (the historical behaviour).
- `'weight'` — `edgeColor` ramped light → dark by \|weight\|: the strongest edge
  keeps `edgeColor` exactly, the weakest fades 70 % toward white.
- `'sign'` — `edgeColorPositive` / `edgeColorNegative` chosen on the **signed**
  cell value (magnitude still drives width). This is what difference networks
  want; the two constants are exported so every downstream difference view
  shares one convention.

#### Node options

| option | type | default | meaning |
|---|---|---|---|
| `nodeStroke` | `string` | `'#ffffff'` | node disc outline color |
| `nodeStrokeWidth` | `number` | `1.5` | node disc outline width |
| `nodeSizeBy` | `ArrayLike<number>` | — | per-node size driver, index-aligned with `model.labels` — see below |
| `nodeRadiusRange` | `[number, number]` | `[8, 40]` | radius range `nodeSizeBy` maps into |
| `hideIsolates` | `boolean` | `false` | drop nodes left with no visible incident edge — see below |
| `initRingStroke` | `string` | `'#e5e7eb'` | color of the unfilled part of the initial-probability ring |
| `initRingWidth` | `number` | `max(3, nodeRadius × 0.22)` per node | ring thickness |

#### Legend option

| option | type | default | meaning |
|---|---|---|---|
| `legend` | `boolean` \| `NetworkLegendSpec` | `false` | in-SVG legend — see below |

The legend is drawn **inside** the SVG, anchored to the canvas rather than to
any pan/zoom group, so an exported or embedded file is self-describing.
Default `false`: the historical output carries no legend and that byte-stability
is a contract.

- `legend: true` — **auto mode**: one 10×10 swatch row per drawn node, coloured
  with that node's fill, i.e. exactly the `colorMap` when one was supplied.
  Capped at `maxEntries` (12).
- `legend: { entries, position?, fontSize?, color?, maxEntries? }` — explicit
  rows. `entries` is `{ label, color, shape? }[]` with `shape` either
  `'swatch'` (10×10 block, for a node colour) or `'line'` (14×3 bar, for an edge
  colour). `position` is `'bottom-left'` (default), `'bottom-right'`,
  `'top-left'`, or `'top-right'`.

The `.legend` stylesheet rule is emitted only when there is at least one row.

```js
import { tna, plotNetwork } from 'ladyna';
const model = tna([['a','b','c','a'], ['a','c','b','c']]);
plotNetwork(model, { legend: true });
plotNetwork(model, {
  legend: {
    position: 'top-right',
    entries: [{ label: 'gain', color: '#4f8a55', shape: 'line' }],
  },
});
```

#### Exported constants

```ts
EDGE_COLOR_POSITIVE: string   // '#4f8a55' — muted green
EDGE_COLOR_NEGATIVE: string   // '#a85050' — muted red
```

#### Sizing nodes with `nodeSizeBy`

`nodeSizeBy` takes a **vector**, not a measure name — one number per state in
`model.labels` order — min-max normalised into `nodeRadiusRange`. Keeping it a
vector is deliberate: the painter stays free of any dependency on the analysis
layer, and you can size by anything (a centrality column, a bootstrap p-value,
an external outcome). A constant vector lands mid-range. Self-loops, edge
anchors, and initial-probability rings all track the per-node radius.

```js
import { tna, centralities, plotNetwork } from 'ladyna';
const model = tna([['a','b','c','a'], ['a','c','b','c'], ['b','a','c','a']]);
const svg = plotNetwork(model, {
  nodeSizeBy: centralities(model).measures.Betweenness,
  nodeRadiusRange: [10, 34],
});
```

A vector of the wrong length, or one holding non-finite values, is **silently
ignored** and the uniform radius is used — the painter never throws on an
optional styling input.

#### `hideIsolates`

Nodes with no surviving incident edge are dropped — their disc, label, and
initial-probability ring all vanish. Isolate detection runs **after** `cutoff`
(and after `showSelfLoops`), so it reflects what the reader actually sees rather
than what the raw matrix holds. The **layout is unchanged**: positions are
computed from the full state set first, so surviving nodes stay exactly where
they were and two plots of the same model line up.

```js
import { tna, plotNetwork } from 'ladyna';
const model = tna([['a','b','c'], ['a','c','b']]);
const svg = plotNetwork(model, { title: 'Demo', width: 400, height: 300 });
console.log(svg.slice(0, 120) + '...');
// <svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Demo" viewBox="0 0 400 300" width="400" height="300" styl...
```

#### Custom layouts via `positions`

By default the nodes sit on a circle, which is what R's `plot.tna()` draws. Pass
`positions` to place them anywhere instead — most usefully the output of
[`networkLayout()`](#graph-layouts), which gives you all 24 algorithms:

```js
import { tna, plotNetwork, networkLayout } from 'ladyna';
const model = tna([['a','b','c','a'], ['a','c','b','c'], ['b','a','c','a']]);
const svg = plotNetwork(model, { positions: networkLayout(model, 'spectral') });
```

Coordinates are in arbitrary units: `plotNetwork` uniformly rescales them to
fill its canvas, preserving the aspect ratio so a layout keeps its shape rather
than being stretched. A layout computed at any size therefore drops straight in,
and `spacing` / `rotation` (passed to `networkLayout`, not here) compose with it.

Two details worth knowing:

- **Node radius** is derived from the closest pair rather than from `n`, so
  discs shrink to fit a crowded region of a free layout instead of overlapping.
- **Self-loops and label offsets** point away from the drawing's centroid, so
  they stay on the outside of the figure whatever shape the layout has.

`positions` also accepts a **label-keyed map** — the shape `plotProcessMap()`
uses — so dragged coordinates can be handed back without re-indexing:

```js
const dragged = new Map([['a', { x: 0, y: 0 }], ['b', { x: 1, y: 0 }], ['c', { x: 0.5, y: 1 }]]);
plotNetwork(model, { positions: dragged });
```

Unusable input degrades silently to the circular layout: an array of the wrong
length, or a map that does not name every state with finite coordinates. Extra
keys in a map are ignored.

A `positions` array whose length does not match `model.labels` is ignored and
the circular layout is used, so a stale layout cannot silently mis-place nodes.

### `networkPlotData(model, options?)`

```ts
networkPlotData(model: TNA, options?: NetworkPlotOptions): NetworkPlotData
networkPlotData(model: GroupTNA, options?: NetworkPlotOptions): Record<string, NetworkPlotData>
```

The same figure as `plotNetwork`, **as data instead of a string**. It takes the
identical options and is the single resolution pipeline both verbs share:

```
plotNetwork(model, o)  ===  render(networkPlotData(model, o))
```

so the two can never drift. Reach for it when you are driving an interactive
renderer (D3, canvas, React, a WebGL scene) and need positions, colours, widths,
and paths — but want your own DOM. A `GroupTNA` yields one entry per group,
keyed by group name and titled with it, exactly as `plotNetwork` does. Throws
when the model has no states.

**`NetworkPlotData`**

| field | type | meaning |
|---|---|---|
| `width` / `height` | `number` | canvas size |
| `background` | `string` | canvas fill |
| `ariaLabel` | `string` | root `<svg>` `aria-label` (the title, or `'Transition network'`) |
| `title` / `subtitle` | `string?` | heading text, present only when supplied |
| `titleX` | `number` | centred heading anchor x |
| `titleY` / `subtitleY` | `number` | heading baselines (24 / 42) |
| `labels` | `string[]` | source model's state labels, model order |
| `nodes` | `NetworkPlotNode[]` | drawn nodes, in `model.labels` order (isolates already removed) |
| `edges` | `NetworkPlotEdge[]` | drawn edges, **weakest-\|weight\| first** — the SVG draw order, so strong edges land on top |
| `legend` | `NetworkPlotLegendRow[]` | resolved legend rows, already placed; `[]` when no legend |
| `style` | `NetworkPlotStyle` | `{ labelSize, labelColor, edgeLabelSize, edgeLabelColor, legendSize, legendColor }` — what the `<style>` block declares |

**`NetworkPlotNode`**

| field | type | meaning |
|---|---|---|
| `id` / `label` | `string` | the state label |
| `displayLabel` | `string` | label as drawn (`truncateLabels` applied) |
| `index` | `number` | index into `model.labels` — stable even when `hideIsolates` drops rows |
| `x` / `y` | `number` | disc centre, final SVG units |
| `radius` | `number` | disc radius |
| `fill` / `stroke` / `strokeWidth` | `string` / `string` / `number` | disc paint |
| `showLabel` | `boolean` | whether `displayLabel` is drawn |
| `tooltip` | `string` | unescaped `<title>` text |
| `initProb` | `number` | initial-state probability as the model carries it |
| `angle` | `number` | outward angle in radians (away from the figure centre) — drives self-loops |
| `ringRadius`, `ringWidth`, `ringStroke`, `ringCircumference`, `ringFraction` | `number?` / `string?` | initial-probability ring; **present only when the ring is drawn** |

**`NetworkPlotEdge`**

| field | type | meaning |
|---|---|---|
| `from` / `to` | `string` | endpoint labels |
| `fromIndex` / `toIndex` | `number` | endpoint indices into `model.labels` |
| `weight` | `number` | `\|signedWeight\|` — what drives width and opacity |
| `signedWeight` | `number` | the raw matrix cell, sign intact — what `edgeColorBy: 'sign'` reads |
| `width` | `number` | rendered stroke width |
| `color` | `string` | stroke and arrowhead fill |
| `opacity` / `arrowOpacity` | `number` | 0..1; the painter draws heads 0.1 more opaque |
| `path` | `string` | SVG `d`, boundary to boundary with arrowhead room deducted |
| `arrow` | `string \| null` | `<polygon points="…">` value, `null` under `arrows: false` |
| `dashArray` | `string \| null` | `stroke-dasharray` value, `null` for solid |
| `label` | `string` | the formatted numeric annotation |
| `showLabel` | `boolean` | whether it is drawn (`edgeLabels`, `edgeLabelMin`) |
| `labelX` / `labelY` | `number` | label anchor; `labelY` **already includes** `edgeLabelOffset` |
| `tooltip` | `string` | unescaped `<title>` text, e.g. `read → quiz: 0.50` |
| `curved` | `boolean` | true when the path bows (half of a reciprocal pair) |
| `selfLoop` | `boolean` | `from === to` |
| `pValue` / `significant` | `number?` / `boolean?` | set only by `differenceNetworkData()` |

**`NetworkPlotLegendRow`** — `{ label, color, shape, swatchX, swatchY,
swatchWidth, swatchHeight, textX, textY }`, geometry already placed on the
canvas.

#### Repainting from the data

The design rule is that **every visual attribute the SVG contains is derivable
from the data object alone** — you never need to read the painter. Nodes and
edges are already in draw order, so a faithful repaint is a straight loop:

```js
import { networkPlotData } from 'ladyna';

const data = networkPlotData(model, { title: 'Cohort A' });

for (const e of data.edges) {
  ctx.strokeStyle = e.color;
  ctx.lineWidth = e.width;
  ctx.globalAlpha = e.opacity;
  ctx.setLineDash(e.dashArray ? e.dashArray.split(',').map(Number) : []);
  strokeSvgPath(ctx, e.path);              // your own d-string renderer
  if (e.arrow) fillPolygon(ctx, e.arrow, e.color, e.arrowOpacity);
  if (e.showLabel) drawText(ctx, e.label, e.labelX, e.labelY);
}
for (const n of data.nodes) {
  if (n.ringRadius !== undefined) drawRing(ctx, n);   // fraction = n.ringFraction
  fillCircle(ctx, n.x, n.y, n.radius, n.fill, n.stroke, n.strokeWidth);
  if (n.showLabel) drawText(ctx, n.displayLabel, n.x, n.y + 3.5);
}
```

Two conventions worth knowing when repainting: node labels sit at `y + 3.5`
(the painter's baseline nudge), and the ring dash pattern is
`` `${ringCircumference * ringFraction} ${ringCircumference}` `` rotated
`-90°` about the node centre. Both are pinned by a test that rebuilds the
default SVG byte for byte from `networkPlotData` output alone.

---

## plotDifferenceNetwork

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

### `plotDifferenceNetwork(a, b, options?)`

```ts
plotDifferenceNetwork(a: TNA, b: TNA, options?: DifferenceNetworkOptions): string
plotDifferenceNetwork(group: GroupTNA, nameA: string, nameB: string, options?: DifferenceNetworkOptions): string

differenceNetworkData(a: TNA, b: TNA, options?: DifferenceNetworkOptions): NetworkPlotData
differenceNetworkData(group: GroupTNA, nameA: string, nameB: string, options?: DifferenceNetworkOptions): NetworkPlotData
```

One SVG showing **Δ = A − B** for every transition — the library form of the
CarmNote / Desktop "compare networks" view. Everything runs through
`networkPlotData()`'s pipeline, so every `plotNetwork` style knob applies here
too, and `differenceNetworkData()` gives you the same data/render split.

**Sign convention — positive means the FIRST argument is larger.** `Δ > 0` is
painted `edgeColorPositive` (default `EDGE_COLOR_POSITIVE`, muted green) and
`Δ < 0` is painted `edgeColorNegative` (default `EDGE_COLOR_NEGATIVE`, muted
red). `|Δ|` drives width and opacity through the usual scale. This anchors one
convention across every downstream difference view.

**Self-loops are skipped.** A self-loop Δ says a state repeats more (or less)
often — that reads as a change in *node size*, not in flow between states — so
drawing it with the same visual grammar as the off-diagonal edges misleads.
Desktop's `compare-networks.ts` drops the diagonal for the same reason. The
diagonal is zeroed before anything else, so it cannot dominate the width scale
either.

Both models must carry the **same state labels in the same order**; anything
else throws with both label lists in the message. `edgeColorBy` and
`showSelfLoops` are not accepted — the difference view fixes them.

| option | type | default | meaning |
|---|---|---|---|
| `nameA` / `nameB` | `string` | the group names, else `'A'` / `'B'` | names used in the legend |
| `significance` | `DifferenceSignificance` | — | per-edge p-values; switches on the inference overlay |
| `level` | `number` | `significance.level`, else `0.05` | α for the overlay |
| `fadeNonSignificant` | `number` | `0.35` | opacity multiplier for non-significant edges |
| `stars` | `boolean` | `true` | append `*` / `**` / `***` to significant edge labels |
| `legend` | `boolean` \| `NetworkLegendSpec` | **`true`** | on by default — see below |
| everything in `NetworkPlotOptions` | | | except `edgeColorBy` and `showSelfLoops` |

**Legend on by default.** A difference figure is unreadable without the sign
convention spelled out, and an exported SVG carries no surrounding page, so two
`'line'` swatches — `"A > B"` and `"A < B"` with the real names — are drawn in
the bottom-left corner. Pass `legend: false` to drop them, or a
`NetworkLegendSpec` to move or replace them.

**Edge labels** use an explicit sign glyph before the magnitude (`+0.12`,
`−0.08`, with a Unicode minus) rather than a leading hyphen — it reads faster at
9px — followed by the significance stars when there are any. `edgeLabelMin` and
`cutoff` both apply to `|Δ|`.

#### The significance overlay

`significance` is structurally a `permutationTest()` result, so one drops
straight in:

```ts
interface DifferenceSignificance {
  labels: string[];            // state labels the matrix is indexed by
  nStates: number;             // side length
  pValues: ArrayLike<number>;  // row-major, pValues[i * nStates + j]
  level?: number;              // α, when the caller does not pass one
}
```

Significant edges (`p < level`) stay **solid** and gain their stars; everything
else is **dashed** (`5,3`) and faded to `fadeNonSignificant × opacity`. Each
edge row in `differenceNetworkData()` output carries `pValue` and `significant`.
Without a `significance` input none of this happens and no edge row carries
those fields — a purely descriptive difference network.

```js
import { tna, permutationTest, plotDifferenceNetwork } from 'ladyna';

const early = tna(seqsEarly);
const late = tna(seqsLate);
const perm = permutationTest(early, late, { iter: 1000, seed: 42 });

const svg = plotDifferenceNetwork(early, late, {
  nameA: 'early', nameB: 'late',
  significance: perm,
});
```

```js
// The GroupTNA form names the legend for you.
import { groupTna, plotDifferenceNetwork } from 'ladyna';
const groups = groupTna(data, labels);
const svg = plotDifferenceNetwork(groups, 'high', 'low');
```

---

## plotNetworkGrid

Available from: `ladyna`, `ladyna/core`, `ladyna/light`, `ladyna/full`.

### `plotNetworkGrid(group, options?)`

```ts
plotNetworkGrid(group: GroupTNA, options?: NetworkGridOptions): string
```

Small multiples: **one** SVG holding every group of a `GroupTNA`, on a shared
colour scale and a shared layout so the cells are comparable at a glance. The
library form of the notebook's `g2` / `g3` group-layout presets. Each cell is a
`networkPlotData()` result rendered into its own `<g>`, so the grid can never
drift from the single-model painter. Throws on an empty `GroupTNA`.

| option | type | default | meaning |
|---|---|---|---|
| `columns` | `number` \| `'auto'` | `'auto'` | cells per row; auto = `ceil(sqrt(nGroups))` **capped at 3** |
| `sharedPositions` | `boolean` | `true` | give every cell identical node coordinates — see below |
| `width` | `number` | `1080` | overall canvas width; cell width is derived |
| `cellHeight` | `number` | `cellWidth × 0.78` | height of one cell; overall height is derived from the row count |
| `gap` | `number` | `12` | gutter between cells and around the grid |
| `cellBorder` | `string` \| `null` | `'#e5e7eb'` | cell frame colour, `null` for none |
| `title` / `subtitle` | `string` | — | head the **whole figure**; each cell is titled with its group name |
| `legend` | `boolean` \| `NetworkLegendSpec` | `false` | **one** figure-level legend, never a per-cell one |
| everything else in `NetworkPlotOptions` | | | forwarded to every cell (`height` is replaced by `cellHeight`) |

**Shared colours.** One `colorMap` is built from the union of every group's
labels — first appearance, groups in record order — so a state is the same
colour in every cell. A caller `colorMap` still wins per label.

**Shared positions, and what anchors them.** With `sharedPositions: true` (the
default) every cell is drawn over that **pooled** label set: a group missing a
state gets a zero row and column for it, which makes the default circular layout
land on identical coordinates in every cell. The pooled union anchors the
arrangement, not any single model, so no group's state ordering is privileged;
because the union is built in record order, the first group's states keep their
familiar positions and later groups' extra states are appended after them. Set
it `false` to let each cell lay out only its own states — useful when the groups
genuinely have different vocabularies and you care about each shape on its own
terms rather than about comparing them.

Cell headings use a `.celltitle` rule (12px) rather than the 15px `.title` a
standalone plot uses, so a cell name does not shout over the figure title.

```js
import { groupTna, plotNetworkGrid } from 'ladyna';

const groups = groupTna(data, labels);
const svg = plotNetworkGrid(groups, {
  title: 'Transition networks by achievement group',
  columns: 3,
  legend: true,
});
```

---

## Graph layouts

### networkLayout(model, layout, options?)

```typescript
networkLayout(model: TNA, layout: NetworkLayoutName, options?: NetworkLayoutOptions): LayoutPosition[]
```

Deterministic node placement — returns one `{ x, y }` per state, index-aligned
with `model.labels`. Pure geometry: it draws nothing, so it composes with any
renderer. Pair it with `plotNetwork` or hand the positions to your own
interactive view (the process-map cell in CarmNote does exactly this with
`plotProcessMap`'s `positions` override).

**24 layouts** (`NETWORK_LAYOUTS` enumerates them for UI menus), ported from
the CarmNote TNA Pro notebook and Dynalytics Desktop with source citations in
`src/core/layouts.ts`:

| Family | Layouts |
|---|---|
| Geometric | `circular`, `concentric`, `radial`, `grid`, `random`, `spiral`, `arc`, `dual-circle`, `star` |
| Structural | `bipartite`, `shell`, `hierarchical`, `degree-sorted`, `degree-hierarchical`, `community-grouped`, `radial-axis` |
| Force / spectral | `fruchterman-reingold`, `forceatlas2`, `fr-shell`, `kamada-kawai`, `spectral`, `spring` |
| Process-map | `saqr`, `oval` |

`'mds'` is **accepted but not listed**: classical multidimensional scaling is
deliberately not implemented (the notebook branch carrying that name ran a
d3 force simulation and its own comment called it a heuristic, so porting it
would have shipped a layout that is not the thing its name promises).
`networkLayout(model, 'mds')` resolves to `kamada-kawai` — the real
stress-minimisation algorithm, and the closest honest answer — purely so a
CarmNote picker whose menu still offers "MDS" keeps working. It is an alias,
not a layout, so `NETWORK_LAYOUTS` stays 24 entries long.

Options (defaults): `width` 380, `height` 340, `nodeRadius` 13 (or a per-node
array), `padding` 22, `seed` 42, `communities?` (per-node group index — used
by `shell`, `bipartite` and `community-grouped`; each falls back exactly as
the source did when it is absent, so the layout still renders).

Two post-layout transforms apply to **every** layout, both identity by
default, so a caller that passes neither gets the raw layout unchanged:

- `spacing` (default `1`) — uniform scale about the centroid. Bigger spreads
  the nodes out, smaller pulls them in; the shape is untouched.
- `rotation` (default `0`) — rotation in **degrees** about the centroid.
  Rotating the positions rather than the SVG transform keeps every label
  upright. Note the on-screen direction: the matrix is the source's
  "clockwise" one, which holds in maths coordinates, but SVG's y axis points
  down — so at `+90` a node due north of the centroid swings **west**.

```typescript
import { tna, networkLayout, plotNetwork, NETWORK_LAYOUTS } from 'ladyna';

const model = tna(sequences);
const positions = networkLayout(model, 'kamada-kawai', { seed: 42 });
// positions[i] corresponds to model.labels[i]
```

Every layout is deterministic under a fixed `seed` (stochastic ones use
ladyna's `SeededRNG`, so they replay identically across runtimes). `spectral`
and `kamada-kawai` are the real algorithms — Laplacian eigen-decomposition
via power iteration, and weighted-spring stress minimisation.

**`saqr` is a process-map layout**: it expects `Start`/`End` sentinel states
(auto-detected by label) and its lens envelope collapses the final row onto
the centre when no `End` node exists. Use a sentinel-bearing model, or a
different layout, for plain TNA models.


#### Flow anchors — `startLabel` / `endLabel`

`saqr`, `degree-hierarchical` and `oval` lay a graph out **along a flow**: the
anchor node takes the first row (or the left pole) and its counterpart the last.
Pass the anchors explicitly:

```js
networkLayout(model, 'oval', { startLabel: '(start)', endLabel: '(end)' });
```

Without them the layouts look for states literally named `Start` and `End`,
which is exactly what fails on a real process map — ladyna renames its sentinels
to `(start)` / `(end)` whenever the data already contain an activity by that
name, so the anchor silently disappears and the layout degenerates to an
unanchored ring. An anchor the model does not contain is ignored rather than
throwing, so a stale label after a rebuild degrades instead of failing.

#### Per-layout options

| option | layout | default | meaning |
|---|---|---|---|
| `ratio` | `oval` | `1.6` | ellipse width : height |
| `jitter` | `saqr` | `0.32` | first middle row's zig-zag, as a fraction of row spacing |
| `spring` | `spring` | see below | the d3-force parameters |

`spring` is the classic CarmNote process-map default — d3-force's integrator
reproduced without the dependency. `SpringForceOptions`:

| option | default | meaning |
|---|---|---|
| `linkDistance` | `70` | `forceLink().distance()` — edge rest length |
| `charge` | `-180` | `forceManyBody().strength()`; negative repels |
| `iterations` | `300` | synchronous ticks; alpha anneals fully over whatever count you give |
| `velocityDecay` | `0.6` | d3's internal multiplier, i.e. `velocityDecay(0.4)` |
| `collidePadding` | `4` | clearance added to each node radius in `forceCollide` |
| `linkStrengthBase` | `0.1` | strength = `base + scale × (weight / maxWeight)` |
| `linkStrengthScale` | `0.6` | …so a maximal edge pulls at 0.7, the weakest at 0.1 |
| `centerStrength` | `1` | `forceCenter().strength()` |

```js
// Faster, looser — good while a user drags a control.
networkLayout(model, 'spring', { spring: { iterations: 60, charge: -120 } });
```

Many-body and collision run as exact O(n²) sweeps rather than Barnes–Hut: for
the tens of nodes a process map holds, that is both faster than building a
quadtree and closer to the ideal the quadtree approximates.

### layout(model, options?)

```ts
function layout(model: TNA, options?: {
  algorithm?: LayoutAlgorithm;   // 'spring' | 'fr' | 'circle' | 'grid' | 'spectral'
                                 // | 'kamada-kawai' | 'star' | 'hierarchical'
                                 // | 'concentric' | 'community' | 'random'
  iterations?: number;           // accepted for dynajs compat; ignored
  width?: number; height?: number; seed?: number;
}): LayoutResult                 // { x, y: Float64Array; labels: string[] }
```

The dynajs-compatible wrapper (added in the 2026-08-22 consolidation so the
retired fork's consumers could repoint unchanged): positions come back
min-max normalized to **[0, 1] independently per axis**; a single node sits
at (0.5, 0.5). Each algorithm name resolves to one of `networkLayout`'s
layouts (`fr` → `fruchterman-reingold`, `circle` → `circular`, `community` →
`community-grouped`, the rest map 1:1), so coordinates are deterministic
under the default seed but not numerically identical to dynajs's retired
implementations.

```js
const r = layout(model, { algorithm: 'spring' });
pts = r.labels.map((lab, i) => ({ lab, x: r.x[i] * W, y: r.y[i] * H }));
```


---

## R-semantics helpers

`src/core/r-semantics.ts` holds the R-behaviour shims — `rround` (round half
to even, R `round()`), `collate` / `sortCollated` (ICU collation, R `sort()`),
and `factorLevels` (R `as.factor()` level order, numeric-aware). They are
consumed internally by the core module but are **not** part of the
`ladyna`/`ladyna/core` public surface; of the four, only `factorLevels` is
exported publicly, and only from `ladyna/transitiontrees`.

---

## Types

All exported as types from `ladyna` and `ladyna/core` (types are erased at
runtime, so the exports matrix does not track them).

- **`Sequence`** — `(string | null)[]`: one row of state tokens, `null` = missing.
- **`SequenceData`** — `Sequence[]`: a wide-format sequence dataset.
- **`ModelType`** — `'relative' | 'frequency' | 'co-occurrence' | 'reverse' | 'n-gram' | 'gap' | 'window' | 'attention' | 'betweenness' | 'matrix'`.
- **`TransitionParams`** — type-specific parameters: `n?` (n-gram order, default 2), `maxGap?` (5), `decay?` (0.5), `size?` (window, 3), `beta?` (attention decay, 1 — beta = 1/lambda vs R), `windowed?`, `windowSize?`, `windowSpan?`.
- **`BuildModelOptions`** — `{ type?, scaling?, labels?, beginState?, endState?, params? }` (see `buildModel`).
- **`TNA`** — the model object: `weights`, `inits`, `labels`, `data`, `type`, `scaling`, plus optional `params`, `counts` (raw counts, R `$frequency_matrix`), `sourceWeights`/`edgeBetweenness` (betweenness-network provenance), `partition`/`actorLevels` (HTNA).
- **`GroupTNA`** — `{ models: Record<string, TNA> }`.
- **`TNAData`** — prepared-data container: `sequenceData`, `labels`, `statistics` (`nSessions`, `nUniqueActions`, `uniqueActions`, `maxSequenceLength`, `meanSequenceLength`).
- **`OnehotSequenceData`** — `importOnehot` result: `{ sequences, windowSize, windowSpan }`.
- **`CentralityMeasure`** — `'OutStrength' | 'InStrength' | 'ClosenessIn' | 'ClosenessOut' | 'Closeness' | 'Betweenness' | 'BetweennessRSP' | 'Diffusion' | 'Clustering' | 'PageRank'`.
- **`CentralityResult`** — `{ labels, measures: Record<CentralityMeasure, Float64Array>, groups? }`.
- **`CliqueResult`** — `{ weights: Matrix[], indices, labels, size, threshold }`.
- **`CommunityResult`** — `{ counts, assignments, labels }`.
- **`CommunityMethod`** — `'fast_greedy' | 'louvain' | 'label_prop' | 'leading_eigen' | 'edge_betweenness' | 'walktrap'`.
- **`ClusterResult`** — sequence-clustering result: `data`, `k`, `assignments`, `silhouette`, `sizes`, `method`, `distance`, `dissimilarity`, plus optional `merge`/`heights`/`order` (R `hclust` conventions).
- **`CompareRow`** — one row of `compareSequences()`: `pattern`, `frequencies`, `proportions`, `residuals` (R `chisq.test()$stdres`), `effectSize?`, `pValue?`.
- **`NetworkEdgeGeometry`** — `{ path, tipX, tipY, tipDx, tipDy, labelX, labelY }` (see Network drawing geometry).
- **`NetworkPlotOptions`** — `plotNetwork` options (see the tables above).
- **`NetworkPlotPosition`** — `{ x: number, y: number }`, a node coordinate in the layout's own units.
- **`NetworkEdgeColorBy`** — `'flat' | 'weight' | 'sign'`.
- **`NetworkEdgeStyle`** — `'solid' | 'dashed' | 'dotted'`.
- **`NetworkEdgeWidthScale`** — `'sqrt' | 'linear'`.
- **`NetworkPlotData`** — `networkPlotData` result: `width`, `height`, `background`, `ariaLabel`, `title?`, `subtitle?`, `titleX`, `titleY`, `subtitleY`, `labels`, `nodes`, `edges`, `legend`, `style` (see the tables above).
- **`NetworkPlotNode`** / **`NetworkPlotEdge`** — one resolved node / edge row (see the tables above).
- **`NetworkPlotLegendRow`** — one placed legend row: `{ label, color, shape, swatchX, swatchY, swatchWidth, swatchHeight, textX, textY }`.
- **`NetworkPlotStyle`** — `{ labelSize, labelColor, edgeLabelSize, edgeLabelColor, legendSize, legendColor }`.
- **`NetworkLegendEntry`** — one caller-supplied legend row: `{ label, color, shape? }`.
- **`NetworkLegendSpec`** — `{ entries?, position?, fontSize?, color?, maxEntries? }`.
- **`NetworkLegendPosition`** — `'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'`.
- **`DifferenceNetworkOptions`** — `plotDifferenceNetwork` options (see the table above); `NetworkPlotOptions` minus `edgeColorBy` and `showSelfLoops`, plus `nameA`, `nameB`, `significance`, `level`, `fadeNonSignificant`, `stars`.
- **`DifferenceSignificance`** — `{ labels, nStates, pValues, level? }`, structurally a `permutationTest()` result.
- **`NetworkGridOptions`** — `plotNetworkGrid` options (see the table above); `NetworkPlotOptions` minus `height`, plus `columns`, `sharedPositions`, `cellHeight`, `gap`, `cellBorder`.
- **`PrepareLongOptions`** — `prepareLong` options (see the table above).
- **`PrepareLongResult`** — `prepareLong` result: `sequences`, `ids`, `actors`, `sessionNr`, `seqRowIndices`, `times`, `meta`, `statistics`.
- **`MetaData`** — per-session metadata: `columns` (`.session_id` first, `.session_nr` last, as in R), `rows`, `types` (`'numeric' | 'categorical'`), `varying`.
- **`DesignMatrix`** — `designMatrix` result: `X` (no intercept), `names` (dummies as `col=level`), `reference`, `dropped`.
- **`NumericAgg`** — `'first' | 'last' | 'sum' | 'mean' | 'mode'`.
- **`CategoricalAgg`** — `'first' | 'last' | 'mode'`.
