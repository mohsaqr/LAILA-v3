# ladyna/processmining — process mining on event logs

The engine-owned process-mining layer: event-log analytics, directly-follows
process maps with bupaR-style simplification and perspectives, conformance
checking, process discovery (heuristic and inductive miners), Petri-net token
replay, a zero-dependency layered (Sugiyama) layout, and self-contained SVG
painters. Pulled up from Dynalytics Desktop per the workspace architecture
contract (algorithms live in packages, apps keep thin bridges).

**Provenance / ground truth.** This module follows **bupaR conventions**
(edeaR's `filter_activity_frequency` coverage rule, `frequency()` /
`performance()` perspectives, `sec_nodes` / `sec_edges`) and the Dynalytics
Desktop implementation it replaced. It is **not** pinned to an R-parity
fixture suite: `tests/processmining.test.ts` states its expectations are
hand-computed on tiny logs against the Desktop implementation plus
pen-and-paper values (the PM design spec's conformance-testing plan). There is
no `*-r-groundtruth` fixture for this module. Discovery and replay implement
the standard published algorithms (Weijters & van der Aalst heuristic miner,
Leemans et al. inductive miner, Rozinat & van der Aalst token replay).

**Available from:** every runtime export below is importable from `ladyna`
(root), `ladyna/processmining`, `ladyna/light`, and `ladyna/full` (the WASM bundles
mirror light/full) — see [exports.md](./exports.md).

**Runnable gallery:** [`demo/processmining.html`](../../demo/processmining.html)
renders the full painter surface in the browser (`npm run demo`).

## Critical caveats

1. **Argument order — the log/variants come FIRST.**
   `tokenReplay(log, net)`, `conformance(log, referenceEdges)`,
   `traceCoverage(variants)` (variants, not a log). Swapping the arguments is
   a recorded agent trap.
2. **`activities` / `paths` are cumulative coverage, not label shares.**
   Both follow bupaR's cumulative-share rule (edeaR
   `filter_activity_frequency`): `activities: 0.8` keeps the most frequent
   activities accounting for **80% of all EVENTS**, and `paths: 0.8` keeps
   the heaviest hand-offs accounting for **80% of all TRANSITIONS** — never
   "80% of the distinct labels/edges". The item that crosses the threshold is
   kept, so at least one item always survives.
3. **A sentinel that collides with a real activity is RENAMED, and says so.**
   The defaults are the literal strings `"Start"` / `"End"`. When the log
   already contains an activity by that name, `processMap()` relabels the
   *injected* nodes to `"(start)"` / `"(end)"` — never the data — and reports
   the labels it used on `renamedSentinels`. Read the boundary nodes off
   `node.type`, not off the literal string, and anything downstream that
   needs the anchors (`saqr` / `oval` layouts, say) keeps working. Pass
   `sentinels: { start, end }` to choose your own labels.

## Import

```ts
import {
  eventLog, processMap, plotProcessMap, traceVariants,
  traceCoverage, conformance, tokenReplay,
  heuristicMiner, inductiveMiner, treeToPetriNet,
  frequency, performance, layeredLayout, plotVariants,
} from 'ladyna/processmining';   // also: 'ladyna', 'ladyna/light', 'ladyna/full'
```

## End-to-end example

Run and verified against `dist/index.js` (ladyna 1.8.2):

```ts
import {
  eventLog, processMap, plotProcessMap, traceVariants, plotVariants,
} from 'ladyna/processmining';

const sequences = [
  ['plan', 'discuss', 'execute', 'reflect'],
  ['plan', 'execute', 'reflect'],
  ['plan', 'discuss', 'discuss', 'execute', 'reflect'],
  ['plan', 'execute', 'reflect'],
  ['discuss', 'plan', 'execute', 'reflect'],
];

const log = eventLog(sequences);
const map = processMap(log, { sentinels: true });
console.log(map.nodes.map(n => `${n.id}(${n.type},${n.absoluteFreq})`).join(' '));
// End(end,5) Start(start,5) discuss(activity,4) execute(activity,5) plan(activity,5) reflect(activity,5)
console.log(map.edges.map(e => `${e.from}->${e.to}:${e.absoluteCount}`).join(' '));
// discuss->discuss:1 discuss->execute:2 discuss->plan:1 execute->reflect:5 plan->discuss:2 plan->execute:3 reflect->End:5 Start->discuss:1 Start->plan:4

const svg = plotProcessMap(map, { metric: 'probability', direction: 'LR' });
console.log(svg.startsWith('<svg'), svg.length);
// true 8240

const variants = traceVariants(log);
console.log(variants.map(v => `#${v.variantId} ${v.trace.join('>')} x${v.count}`));
// [ '#0 plan>execute>reflect x2',
//   '#1 discuss>plan>execute>reflect x1',
//   '#2 plan>discuss>discuss>execute>reflect x1',
//   '#3 plan>discuss>execute>reflect x1' ]

const vsvg = plotVariants(variants, { title: 'Trace variants' });
console.log(vsvg.startsWith('<svg'), vsvg.length);
// true 3146
```

All later "→" example outputs in this document come from this same 5-case
log (or the small timestamped log shown in the Analytics section), executed
against the built library.

---

## Event logs

The data model. Process mining consumes the same per-case ordered event
streams as TNA (`SequenceData`, i.e. `(string | null)[][]` — nulls are
absent events) and adds two optional columns: case ids and per-event
timestamps in **milliseconds since epoch**. Every verb in this module
accepts either a wrapped `EventLog` or bare `SequenceData` (`LogInput`) and
coerces internally. TNA's `SequenceData` is never mutated — sentinel
injection returns copies.

### `eventLog(sequences, options?)` → `EventLog`

Alias: `event_log`.

Build a typed `EventLog` from raw sequences. Throws when `sequences` is not
an array or when `caseIds` / `timestamps` lengths do not match the number of
cases.

| option | type | default | meaning |
|---|---|---|---|
| `caseIds` | `readonly string[]` | `case_<i>` per case | one id per case |
| `timestamps` | `LogTimestamps` | `null` | per-case timestamp rows aligned index-for-index with `sequences` (`null` row = no times for that case; `null` entry = untimed event) |

The result carries `sequences`, `caseIds`, `timestamps`, and `activities`
(distinct non-null labels, sorted).

```ts
const log = eventLog(sequences);
// → { caseIds: ['case_0', …, 'case_4'],
//     activities: ['discuss','execute','plan','reflect'], timestamps: null }
```

### `asEventLog(input)` → `EventLog`

Coerce any `LogInput` to an `EventLog`: an `EventLog` passes through
unchanged; bare sequences get default `case_<i>` ids and no timestamps.

### `isEventLog(input)` → `input is EventLog`

Type guard — `true` for a wrapped log (a non-array object with `sequences`
and `caseIds` arrays), `false` for bare `SequenceData`.

### `injectSentinels(input, startLabel?, endLabel?)` → `EventLog`

Inject synthetic Start/End sentinel events around each trace. Non-mutating —
returns a new `EventLog` with copied sequences. Nulls are trimmed from each
trace before wrapping; timestamp rows are filtered in lock-step and padded
with `null` for the sentinels so alignment is preserved. Sentinel labels are
added to `activities`. With neither label given, returns the coerced log
unchanged.

```ts
injectSentinels(log, 'Start', 'End').sequences[1]
// → ['Start','plan','execute','reflect','End']
```

### `isSentinelSequence(data)` → `boolean`

`true` exactly for `[[]]` — the workspace-wide sentinel for non-sequence
modes. Every analytics verb short-circuits to an empty result on it. (This
"sentinel" is unrelated to Start/End sentinels.)

### `edgeKey(from, to)` → `string`

Stable string key for a directly-follows edge: `` `${from}\x00${to}` ``
(NUL-separated, collision-safe for labels containing arrows or dashes). Used
throughout the module and by the `conformance` plot-coloring option.

### `START_SENTINEL` / `END_SENTINEL`

The default sentinel labels — the **literal strings `'Start'` and `'End'`**.

### `START_SENTINEL_ALT` / `END_SENTINEL_ALT`

The fallback labels — `'(start)'` and `'(end)'` — that `processMap()`
injects instead when the log already contains an activity literally equal
to a requested sentinel. Renaming the *injected* node is the only safe move:
leaving it would merge the two, and one node standing for two different
things is a map that lies. The pair is always renamed together (a map
showing `Start` beside `(end)` reads as a bug), and the labels actually used
are reported on the result as `renamedSentinels`.

---

## Analytics

Log-level, activity-level, and case-level metrics computed directly from the
event log. Every verb returns a typed one-row-per-observation array with
deterministic ordering; no TNA transition matrix is consulted — all
frequencies and probabilities are event-log computations.

### `activityStats(input)` → `ActivityStat[]`

Alias: `activity_stats`.

One tidy stat row per unique activity, **sorted by activity label**. Fields:

| field | meaning |
|---|---|
| `activity` | label |
| `frequency` | total event occurrences across the log |
| `relativeFrequency` | `frequency / total events` |
| `caseCount` | cases containing the activity at least once |
| `presence` | `caseCount / total cases` |
| `startCount` / `endCount` | cases starting / ending with this activity |
| `selfLoops` | total X→X transitions |
| `selfLoopRate` | `selfLoops / total outgoing transitions` (0 when none) |
| `repetitionsPerCase` | mean extra visits per case among cases containing it |

```ts
activityStats(log)[0]
// → { activity: 'discuss', frequency: 4, relativeFrequency: 0.2105…,
//     caseCount: 3, presence: 0.6, startCount: 1, endCount: 0,
//     selfLoops: 1, selfLoopRate: 0.25, repetitionsPerCase: 0.3333… }
```

### `startActivities(input)` / `endActivities(input)` → `BoundaryActivity[]`

Start- / end-activity distribution: one `{ activity, count, fraction }` row
per boundary activity, sorted count descending then activity ascending.

```ts
startActivities(log)
// → [ { activity: 'plan', count: 4, fraction: 0.8 },
//     { activity: 'discuss', count: 1, fraction: 0.2 } ]
```

### `traceLengths(input)` → `number[]`

Non-null event count per case (= trace length), **input order**.

### `traceLengthSummary(input)` → `TraceLengthSummary`

`{ n, min, median, mean, max, distribution }` where `distribution` is the raw
per-case lengths in input order. Empty log → all zeros.

```ts
traceLengthSummary(log)
// → { n: 5, min: 3, max: 5, median: 4, mean: 3.8, distribution: [4,3,5,3,4] }
```

### `traceVariants(input)` → `TraceVariant[]`

Alias: `trace_variants`.

Enumerate distinct traces. Nulls inside a case are treated as absent events.
**Documented ordering:** count descending, ties broken by ascending
stringified trace (activities joined by U+0001) — deterministic on any input.
Each row: `variantId` (0-based rank), `trace` (canonical activity array),
`count`, `percentage` (`count / totalCases`), `caseIndices` (0-based indices
into the input log).

### `traceCoverage(variants, totalCases?)` → `CoveragePoint[]`

Alias: `trace_coverage`. **Takes the variant list from `traceVariants`, not
a log.**

Cumulative coverage curve over an ordered variant list: one
`{ rank, cumulativeCount, cumulativeFraction }` per variant, `rank` 1-based
(plot-ready). `totalCases` defaults to `sum(variants[].count)`.

```ts
traceCoverage(traceVariants(log))
// → [ { rank: 1, cumulativeCount: 2, cumulativeFraction: 0.4 },
//     { rank: 2, cumulativeCount: 3, cumulativeFraction: 0.6 },
//     { rank: 3, cumulativeCount: 4, cumulativeFraction: 0.8 },
//     { rank: 4, cumulativeCount: 5, cumulativeFraction: 1 } ]
```

### `caseMetrics(input)` → `CaseMetric[]`

Alias: `case_metrics`.

One tidy row per case, input order:
`{ caseId, traceLength, nActivities, variantId, selfLoops, repetitions,
throughputTime? }`. `variantId` matches `traceVariants` ranks; `repetitions`
counts activities occurring more than once in the case; `throughputTime`
(`max(ts) − min(ts)` in ms) is present only when the log has timestamps for
the case (0 for a single timed event).

### `throughputTimes(input)` → `ThroughputRow[]`

Alias: `throughput_times`. **Requires a timestamped EventLog** — throws
`"…the event log has no timestamps…"` otherwise (as do `dwellTimes` and
`transitionDurations`).

Per-case `{ caseId, throughputTime }` where `throughputTime = max(ts) −
min(ts)` in ms; cases with fewer than 2 valid timestamps yield 0.

### `dwellTimes(input)` → `DwellStat[]`

Alias: `dwell_times`. Timestamp-gated.

Per-activity dwell time: `dwell(event_k) = t(event_{k+1}) − t(event_k)`,
attributed to the **source** activity; terminal activities contribute
nothing. Rows `{ activity, n, totalDwell, meanDwell, medianDwell, minDwell,
maxDwell }` (ms), sorted by activity label. A gap is only timed when the
events are truly adjacent after null-dropping: a real activity whose
timestamp is missing breaks the bridge (no phantom hand-off), whereas a
`null` event does not. Negative gaps (log not sorted by time) are skipped
with a `console.warn`.

### `transitionDurations(input)` → `TransitionDurationStat[]`

Alias: `transition_durations`. Timestamp-gated.

Per-edge transit-time stats: one `{ from, to, n, mean, median, min, max,
total }` row (ms) per observed directly-follows pair, sorted by `(from, to)`.
Same bridging and negative-gap rules as `dwellTimes`.

```ts
const MIN = 60_000;
const tlog = eventLog(
  [['plan','execute','reflect'], ['plan','execute','reflect']],
  { caseIds: ['s1','s2'],
    timestamps: [[0, 5*MIN, 12*MIN], [0, 9*MIN, 14*MIN]] },
);
throughputTimes(tlog)
// → [ { caseId: 's1', throughputTime: 720000 },
//     { caseId: 's2', throughputTime: 840000 } ]
transitionDurations(tlog)[1]
// → { from: 'plan', to: 'execute', n: 2, mean: 420000, median: 420000,
//     min: 300000, max: 540000, total: 840000 }
```

---

## Process maps

### `processMap(input, options?)` → `ProcessMap | Record<string, ProcessMap>`

Alias: `process_map`.

Build a fully-annotated directly-follows map. Typed overloads:

```ts
function processMap(input: GroupTNA, options?): Record<string, ProcessMap>; // one map per group
function processMap(input: LogInput | TNA, options?): ProcessMap;
```

Accepts an `EventLog`, bare `SequenceData`, a `TNA` model (its stored
`data` sequences are used — throws if the model stores none), or a
`GroupTNA` (dispatches per group). Every node and edge carries **all**
metric variants (absolute / relative / case / probability, plus the full
duration perspective when the log is timestamped), so consumers toggle
perspectives without recomputation.

| option | type | default | meaning |
|---|---|---|---|
| `sentinels` | `boolean \| { start?: string; end?: string }` | off | inject synthetic Start/End sentinels around each trace (on a copy). `true` uses `START_SENTINEL`/`END_SENTINEL`; an object overrides the labels. A label that collides with a real activity is renamed to `START_SENTINEL_ALT`/`END_SENTINEL_ALT` and reported on `renamedSentinels`. See caveat 3. |
| `activities` | `number` in `(0, 1]` | `1` | **cumulative EVENT coverage** (bupaR `filter_activity_frequency(percentage=)`): sort activities by frequency, keep while the cumulative share *before* each is below the threshold — `0.8` = the most frequent activities accounting for 80% of all events, **not** 80% of the labels. Filters the **log itself** before sentinel injection (so shares reconcile with the visible picture and A→B→C becomes a real A→C when B goes); cases emptied by the filter are removed. Throws outside `(0, 1]`. |
| `paths` | `number` in `(0, 1]` | `1` | the same **cumulative rule over TRANSITIONS**, applied at display level to directly-follows edges: `0.8` keeps the heaviest hand-offs accounting for 80% of all transitions. Boundary arrows (Start→…, …→End) compete **within their own group**, so the main ways in/out survive and sentinels never float unattached. Throws outside `(0, 1]`. |
| `minEdgeCount` | `number ≥ 0` | `0` | hide hand-offs observed fewer than this many times (absolute threshold; applied before the `paths` cut). Throws when negative. |

An activity left with no surviving edge after `paths`/`minEdgeCount` is
dropped from the map (bupaR semantics — trimmed paths are never restored to
keep a node on screen; a self-loop counts as connectivity). Node/edge
metrics are computed on the (activity-filtered) log, so `paths` /
`minEdgeCount` affect display only. Everything removed is reported in
`dropped`.

Result (`ProcessMap`): `nodes` (sorted by id), `edges` (sorted by
`(from, to)`), `totalCases`, `totalTransitions`, `hasDurations` (`true` only
when at least one edge actually carries a timed duration — not merely
because a timestamp array exists), and
`dropped: { activities: string[]; edges: number }`, plus
`renamedSentinels?: { start?: string; end?: string }` — present only when a
requested sentinel label collided with a real activity and the injected
nodes were relabelled `(start)` / `(end)` (see caveat 3). The painter turns
that into a `warnings` entry.

`ProcessMapNode`: `id`, `type` (`'activity' | 'start' | 'end'`),
`absoluteFreq`, `relativeFreq`, `caseFreq` (fraction of cases),
`caseAbsolute` (bupaR `absolute_case`), `startCount`, `endCount`, and — on
timestamped logs — `meanDuration`, `medianDuration`, `minDuration`,
`maxDuration`, `totalDuration`, `nDurations` (dwell times, ms).

`ProcessMapEdge`: `from`, `to`, `absoluteCount`, `relativeCount`,
`caseCount` (fraction), `caseAbsolute`, `probability` (share of the
source's outflow — bupaR relative-antecedent), `probabilityIn` (share of
the target's inflow — bupaR relative-consequent), plus the same six
duration fields (transit times, ms) on timestamped logs.

```ts
const map = processMap(log, { sentinels: true });
map.edges.find(e => e.from === 'plan' && e.to === 'execute')
// → { from: 'plan', to: 'execute', absoluteCount: 3, relativeCount: 0.125,
//     caseCount: 0.6, caseAbsolute: 3, probability: 0.6, probabilityIn: 0.6 }

processMap(log, { sentinels: true, paths: 0.8 }).dropped
// → { activities: [], edges: 3 }   (discuss→discuss, discuss→plan, Start→discuss)
```

---

## Conformance & replay

### `conformance(input, reference)` → `ConformanceResult`

Alias: `check_conformance`. **Log first, then the reference edges.**

Edge-based replay of the log against a reference model of permitted
directly-follows pairs (the format educational research actually has: an
expected progression). Deliberately not net-based: alignments and
Petri-net fitness are out of scope here (use `tokenReplay` for token
fitness).

- `input` — event log or raw sequences.
- `reference` — permitted pairs as `{ from, to }` objects **or**
  `[from, to]` tuples (duplicates deduped).

Result:

| field | meaning |
|---|---|
| `cases` | per case `{ caseId, moves, onModelMoves, fitness }` — fitness = on-model moves / moves (1 when the trace has no moves) |
| `fitness` | move-weighted aggregate fitness across the log |
| `precision` | escaping-edges precision, visit-weighted: per activity with ≥1 outgoing reference edge, the fraction of its allowed continuations actually used, weighted by how often the activity is a move source. 1 = the model allows nothing unused |
| `deviations` | off-model moves aggregated across the log `{ from, to, count, caseCount }`, count desc then from/to |
| `unusedReferenceEdges` | reference edges never observed in the log |

```ts
conformance(log, [['plan','discuss'], ['plan','execute'],
                  ['discuss','execute'], ['execute','reflect']])
// → { fitness: 0.8571…, precision: 1,
//     deviations: [ { from: 'discuss', to: 'discuss', count: 1, caseCount: 1 },
//                   { from: 'discuss', to: 'plan',    count: 1, caseCount: 1 } ],
//     unusedReferenceEdges: [], cases: [ …5 rows… ] }
```

### `tokenReplay(input, net)` → `TokenReplayResult`

Alias: `token_replay`. **Log first, then the Petri net.**

Classic token-based replay (Rozinat & van der Aalst) of the log on a
workflow net (typically from `treeToPetriNet`). For each event the enabled
transition is fired, searching through silent (τ) transitions when needed
(BFS capped at 2000 markings per event); when the model disallows the event
the first labeled candidate is force-fired with missing tokens. Per-case
fitness uses the four-counter formula
`½·(1 − missing/consumed) + ½·(1 − remaining/produced)`.

Result: `cases` (`{ caseId, produced, consumed, missing, remaining,
fitness }` per case), `fitness` (log-level, from the summed counters; 1 on
an empty log), `unknownEvents` (events whose label has no transition in the
net, counted as missing; `{ activity, count }` sorted count desc).

```ts
const pnet = treeToPetriNet(inductiveMiner(log).tree);
tokenReplay(log, pnet)
// → { fitness: 1, unknownEvents: [],
//     cases: [ { caseId: 'case_0', produced: 10, consumed: 10,
//                missing: 0, remaining: 0, fitness: 1 }, … ] }
```

---

## Discovery

### `heuristicMiner(input, options?)` → `HeuristicNet`

Alias: `heuristic_miner`.

Frequency-based dependency-graph discovery (Weijters & van der Aalst) —
the noise-tolerant workhorse. Standard measures:

- dependency `a⇒b = (|a>b| − |b>a|) / (|a>b| + |b>a| + 1)` for `a ≠ b`
- L1-loop `a⇒a = |a>a| / (|a>a| + 1)`
- L2-loop `a⇒²b = (|a>b>a| + |b>a>b|) / (|a>b>a| + |b>a>b| + 1)`

| option | type | default | meaning |
|---|---|---|---|
| `dependencyThreshold` | `number` | `0.9` | minimum dependency measure to keep an edge |
| `minCount` | `number` | `1` | minimum `\|a>b\|` observations to keep an edge (also gates self-loops) |
| `relativeToBest` | `number` | `0.05` | keep an edge only if its dependency is within this margin of the best dependency leaving the same activity |
| `l1Threshold` | `number` | `0.9` | minimum L1-loop measure to keep a self-loop |
| `l2Threshold` | `number` | `0.9` | minimum L2-loop measure to keep a two-loop |
| `allConnected` | `boolean` | `true` | always keep each activity's single strongest incoming and outgoing edge, so no activity is stranded |

Result: `activities` (`{ activity, frequency }`, sorted), `edges` (**every**
observed non-self pair with `count`, `reverseCount`, `dependency`, `kept`,
and a `reason` of `'kept' | 'all-connected' | 'below-dependency' |
'below-count' | 'relative-to-best'`; sorted by from/to), `selfLoops`
(`{ activity, count, dependency, kept }`), `twoLoops` (unordered pairs
`a < b`: `{ a, b, countAba, countBab, dependency, kept }`).

```ts
heuristicMiner(log, { dependencyThreshold: 0.5 })
  .edges.filter(e => e.kept).map(e => `${e.from}->${e.to}(${e.reason})`)
// → [ 'discuss->execute(kept)', 'discuss->plan(all-connected)',
//     'execute->reflect(kept)', 'plan->discuss(all-connected)',
//     'plan->execute(kept)' ]
```

### `inductiveMiner(input)` → `InductiveMinerResult`

Alias: `inductive_miner`.

Recursive process-tree discovery (Leemans et al.). Tries the four cut types
in canonical order — exclusive-choice (×), sequence (→), parallel (∧),
loop (↺) — splitting the log per cut and recursing (max depth 40). When no
cut applies, falls through to the flower model `↺(τ, a₁ … aₙ)`. The result
is a sound, block-structured tree.

Result: `tree` (`ProcessTree`), `notation` (pm4py-style operator string),
`activities` (sorted), `flowers` (the alphabets that fell through to a
flower model — empty means every level found a perfect cut).

```ts
inductiveMiner(log).notation
// → '→(∧(×(↺(discuss, τ), τ), plan), execute, reflect)'
```

### `treeNotation(tree)` → `string`

Alias: `tree_notation`.

Render a `ProcessTree` in operator notation: `→(…)`, `×(…)`, `∧(…)`,
`↺(…)`, `τ`, activity labels verbatim. For a loop, `children[0]` is the
body and the rest are redo parts.

### `treeToPetriNet(tree)` → `PetriNet`

Alias: `tree_to_petri_net`.

Compile a block-structured process tree into a sound workflow net. Silent
(τ, `label: null`) transitions realize ∧-splits/joins and ↺ wiring. Result:
`{ places, transitions, arcs, initialPlace, finalPlace }` with generated ids
`p0, p1, …` / `t0, t1, …`; `arcs` is the bipartite `{ from, to }` list
between place and transition ids.

```ts
treeToPetriNet(inductiveMiner(log).tree)
// → { places: 10 ids, transitions: 10, arcs: 22,
//     initialPlace: 'p0', finalPlace: 'p1' }  (counts for the example log)
```

---

## Metrics & formatting

The bupaR perspective model: nodes and edges are annotated, independently,
with either a **frequency** or a **performance** perspective. `processMap()`
precomputes every variant, so switching perspective is a relabel, never a
recomputation. This vocabulary drives `plotProcessMap` / `processMapData`
(`nodeMetric`, `edgeMetric`, `secNodeMetric`, `secEdgeMetric`) and any
downstream table.

### `frequency(value = 'absolute')` → `FrequencyMetric`

bupaR's `frequency()`. `value` is one of `'absolute' | 'relative' |
'absolute_case' | 'relative_case' | 'relative_antecedent' |
'relative_consequent' | 'probability'` (the last three are edge-only;
`probability` is the older ladyna name for `relative_antecedent` — bupaR
spells the antecedent/consequent pair with hyphens, this API uses
underscores). Throws on an unknown value. Returns
`{ perspective: 'frequency', value }`.

### `performance(aggregate = 'mean', units = 'auto')` → `PerformanceMetric`

bupaR's `performance()`. `aggregate ∈ 'mean' | 'median' | 'min' | 'max' |
'sum'`; `units ∈ 'auto' | 'secs' | 'mins' | 'hours' | 'days' | 'weeks'`
(`auto` picks a readable unit per value). Throws on unknown inputs. Returns
`{ perspective: 'performance', aggregate, units }`.

> Note: importing `performance` shadows the global timing API of the same
> name in that scope — alias it (`performance as perf`) if you need both.

### `asMetric(input, fallback)` → `MapMetric`

Normalise a caller-supplied metric: accepts a full `MapMetric` spec, a bare
frequency value string (`'absolute'`, …), or the legacy `ProcessMapMetric`
vocabulary where `'case'` meant `relative_case`. `null`/`undefined` →
`fallback`.

```ts
asMetric('case', frequency())
// → { perspective: 'frequency', value: 'relative_case' }
```

### `isPerformance(metric)` → `metric is PerformanceMetric`

`true` when the metric reads a duration rather than a count.

### `nodeMetricValue(node, metric)` → `number | null`

Resolve a `ProcessMapNode`'s value for a metric. `null` when undefined for
this node — a performance metric on an untimed log, or the edge-only values
(`probability` / `relative_antecedent` / `relative_consequent`). Callers
decide whether `null` means "blank" or "fall back".

### `edgeMetricValue(edge, metric)` → `number | null`

Resolve a `ProcessMapEdge`'s value: frequency values map to
`absoluteCount` / `relativeCount` / `caseAbsolute` / `caseCount`;
`probability` and `relative_antecedent` → `edge.probability`;
`relative_consequent` → `edge.probabilityIn`; performance aggregates read
the duration fields (`null` on untimed maps).

### `formatMetricValue(value, metric)` → `string`

Format a resolved value for display: counts as integers; proportions as
percentages (`'relative'`-family with 1 decimal, `relative_case` with 0;
non-zero values below display resolution render `'<0.1%'` / `'<1%'` rather
than a false zero); durations in the metric's unit (`auto` scales per
value). `null`/non-finite → `''`.

```ts
formatMetricValue(0.66666, frequency('relative'))          // → '66.7%'
formatMetricValue(5400000, performance('mean', 'hours'))   // → '1.50h'
```

### `formatDurationAuto(ms)` → `string`

Compact auto-scaled duration: `'1.50h'`, `'1.2m'`, `'42.0s'`, `'1.09d'`;
non-positive or non-finite → `'0s'`.

### `formatDuration(ms)` → `string`

Exported from the plot layer; identical behaviour to `formatDurationAuto`
(kept for the painter's historical import path).

```ts
formatDuration(93784000)   // → '1.09d'
```

### `toUnit(ms, units)` → `number`

Convert a duration in ms to the metric's unit; unscaled passthrough when
`units === 'auto'`. `toUnit(7200000, 'hours')` → `2`.

### `metricLabel(metric)` → `string`

Human-readable name for legends and axis captions:
`'absolute frequency'`, `'relative case frequency'`,
`'median duration (hours)'`, `'share of the source's outflow'`
(probability/antecedent), `'share of the target's inflow'` (consequent), …

---

## Layout

### `layeredLayout(nodes, edges, options?)` → `LayeredLayoutResult`

Zero-dependency layered DAG layout (Sugiyama) — the dagre replacement used
by the process-map painter, usable for any flow-ranked rendering. Pipeline:
greedy Eades–Lin–Smyth cycle breaking → longest-path rank assignment →
weighted barycenter crossing-reduction sweeps → rank packing +
priority-alignment coordinates. Deterministic on any input (all tie-breaks
on node id); designed for ≤ ~100 nodes.

- `nodes` — `{ id, width, height }[]` (rendered sizes in px).
- `edges` — `{ from, to, weight? }[]`; heavier edges pull harder in the
  barycenter passes (e.g. pass the absolute count). Self-loops and unknown
  endpoints are ignored; parallel edges are deduped with summed weights.

| option | type | default | meaning |
|---|---|---|---|
| `direction` | `'LR' \| 'TB'` | `'LR'` | flow direction |
| `nodeSep` | `number` | `30` | cross-axis gap between nodes in a rank |
| `rankSep` | `number` | `100` | flow-axis gap between ranks |
| `margin` | `number` | `50` | outer margin |
| `sweeps` | `number` | `8` | barycenter ordering sweeps |
| `first` | `readonly string[]` | — | node ids forced into an exclusive rank 0 (e.g. a Start sentinel; other roots are pushed down a rank) |
| `last` | `readonly string[]` | — | node ids forced into a rank after every other node |
| `rankHint` | `ReadonlyMap<string, number>` | — | per-node ordering key replacing structural ranking: nodes are ranked by ascending hint (equal hints share a rank); absent nodes fall back to 0 |

Result: `positions` (`Map<id, {x, y}>` node **centres**), `ranks`
(`Map<id, number>`, 0 = first layer), `width`, `height` (including margins).

```ts
layeredLayout(
  [{ id:'A', width:100, height:40 }, { id:'B', width:100, height:40 },
   { id:'C', width:100, height:40 }],
  [{ from:'A', to:'B' }, { from:'B', to:'C' }, { from:'A', to:'C', weight:2 }],
)
// → ranks A:0 B:1 C:2; positions A(100,70) B(300,70) C(500,70);
//   width 600, height 140
```

---

## Visualization

The ladyna two-layer pattern: `processMapData()` produces renderer-neutral
typed geometry (layout, colors, labels, edge paths) any consumer can paint;
`plotProcessMap()` is the shared self-contained SVG painter. The visual
design ports the Dynalytics prototype with zero dependencies: bupaR-style
rose→navy node shading, rounded-rect activities, Start/End sentinel
circles, halo edge labels, rank-aware edge routing (near-straight
adjacent-rank edges with two-sided reciprocal chords, nested skip arcs,
back arcs on the far side), and a canvas sized to the true bounding box so
nothing clips. See the gallery:
[`demo/processmining.html`](../../demo/processmining.html).

### `processMapData(map, options?)` → `ProcessMapPlotData`

Compute the geometry without painting. Same options as `plotProcessMap`
(below). Result: `width`, `height`, `offsetX` / `offsetY` (the translation
applied when fitting the canvas — a consumer converting a rendered
coordinate back into a `positions` override must subtract it), `direction`,
`metric` (the legacy single-metric switch echoed back), `nodes`
(`ProcessMapPlotNode[]`: position, size, fill/border/text colors, text
halo, formatted `valueLabel` + optional `secLabel`), and `edges`
(`ProcessMapPlotEdge[]`: SVG cubic-Bézier `path`, arrowhead polygon
`arrow`, color/width/opacity, label position and text, `kind: 'forward' |
'skip' | 'back' | 'self'`, `dashed`), plus `warnings: string[]`.

`warnings` is where the painter's silent degradations become visible. Ask
for a performance metric on a log with no timestamps and the map still
draws: nodes show their absolute frequency rather than rendering bare, edge
thickness follows the absolute count, and the affected edge labels come out
blank. Those fallbacks are right, but invisible, so the reason is reported
here instead. It also
carries the sentinel-rename note when `processMap()` had to relabel an
injected boundary node. `plotProcessMap` ignores it entirely (the SVG is
byte-identical either way); consumers read it from `processMapData` and
show it next to the map.

### `plotProcessMap(map, options?)` → `string`

Alias: `plot_process_map`.

Render a `ProcessMap` to a **self-contained SVG string** (inline styles,
no external assets; verified to start with `<svg`).

Hand it the `Record<string, ProcessMap>` that `processMap(GroupTNA)`
returns and it paints one SVG per group, returning
`Record<string, string>` — the same convention as `plotNetwork` on a
`GroupTNA`. Overloaded, so a single-map call still gets a plain `string`.

```ts
const maps = processMap(groupModel);            // Record<string, ProcessMap>
const svgs = plotProcessMap(maps);              // Record<string, string>
```

| option | type | default | meaning |
|---|---|---|---|
| `metric` | `'absolute' \| 'relative' \| 'case' \| 'probability'` | — | legacy single switch driving both nodes and edges; superseded by `nodeMetric` / `edgeMetric`, which take precedence. When passed it is the base fallback for **both** sides, so a legacy call behaves exactly as it always did |
| `nodeMetric` | `MapMetric \| FrequencyValue` | `metric`, else `frequency('relative')` | bupaR `type_nodes` — node perspective; a spec from `frequency()` / `performance()` or a bare frequency value. A node-undefined value (probability, or performance on an untimed log) falls back to absolute frequency rather than rendering blank |
| `edgeMetric` | `MapMetric \| FrequencyValue` | `metric`, else `frequency('relative_antecedent')` | bupaR `type_edges` — edge perspective (thickness follows it too; an undefined performance value falls back to the absolute count for thickness) |
| `secNodeMetric` | `MapMetric \| FrequencyValue \| null` | `null` | bupaR `sec_nodes` — second node value, rendered in brackets |
| `secEdgeMetric` | `MapMetric \| FrequencyValue \| null` | `null` | bupaR `sec_edges` — second edge label line (no implicit second line otherwise) |
| `direction` | `'LR' \| 'TB'` | `'LR'` | flow direction |
| `fixedThickness` | `boolean` | `false` | fixed 2px edges instead of metric-scaled thickness |
| `showSelfLoops` | `boolean` | `true` | draw self-loop arcs |
| `edgeLabels` | `'auto' \| 'all' \| 'none'` | `'auto'` | label policy: `auto` labels the strongest edges — capped at `maxEdgeLabels` past `denseEdgeThreshold` — and then DROPS any label whose box would overprint an already-kept label or a node rectangle (heaviest edge wins; the edge itself still draws). `all` keeps every label uncut; `none` draws none |
| `highlightPath` | `readonly string[] \| null` | `null` | ordered activity path to highlight; other edges are dimmed |
| `conformance` | `{ onModel: ReadonlySet<string> } \| null` | `null` | conformance coloring: edges whose `edgeKey(from, to)` is in the set paint green, the rest red |
| `layout` | `ProcessMapLayoutName` | `'spring'` | how the nodes are placed: the rank-based flow layout, or any [`NETWORK_LAYOUTS`](./core.md#graph-layouts) algorithm run over the map's own nodes and edges and fitted into the canvas. An unknown name — or a layout that throws — falls back to `'layered'` rather than failing the render. `PROCESS_MAP_LAYOUTS` is the menu |
| `spread` | `number` | `1` | overall breathing room. On `'layered'` it scales `rankSep` and `nodeSep`; on any other layout it scales the placed coordinates about their centroid. Explicit `rankSep` / `nodeSep` win over it. A value that is not a positive finite number degrades to `1` |
| `nodeSep` | `number` | `30 * spread` | cross-axis gap between nodes in a rank |
| `rankSep` | `number` | `100 * spread` | flow-axis gap between ranks |
| `margin` | `number` | `40` | outer margin |
| `denseEdgeThreshold` | `number` | `60` | edge count above which the map counts as dense — strokes and labels thin out |
| `maxEdgeWidth` | `number` | `6`, or `3` on a dense map | widest edge stroke |
| `minEdgeWidth` | `number` | `0.8` | narrowest edge stroke |
| `edgeOpacityRange` | `readonly [number, number]` | `[0.3, 0.85]` | stroke opacity at the weakest and the strongest edge |
| `maxEdgeLabels` | `number` | `50` | how many edges keep a label on a dense map under `edgeLabels: 'auto'` |
| `arcTierCap` | `number` | `110`, or `62` when wrapped | ceiling on the height of a tiered skip / back arc |
| `nodeRamp` | `readonly [string, string, string]` | rose → steel blue → deep navy | the three-stop node fill ramp, interpolated over activity frequency |
| `wrap` | `'auto' \| number` | off | serpentine wrap for wide LR maps: ranks fold into rows; a number = ranks per row, `'auto'` targets ~1400px rows. LR only |
| `wrapStyle` | `'serpentine' \| 'rows'` | `'rows'` | `rows` keeps every row left-to-right, so the flow reads one way and the End sentinel lands at the far end of the last row; `serpentine` mirrors odd rows so the turn is a short hop. LR only, with `wrap` |
| `positions` | `ReadonlyMap<string, {x, y}>` | — | node centres overriding the computed layout (drag support); routing, arrowheads, labels and canvas size are recomputed. Coordinates are read *before* the `offsetX`/`offsetY` shift |
| `nodeWidth` | `(label: string) => number` | `max(110, 7.8·len + 44)` | override the estimated per-label node width |
| `title` / `subtitle` | `string` | — | header text (adds 40/56px top padding) |
| `background` | `string` | `'#ffffff'` | canvas fill (also the edge-label halo color) |

```ts
plotProcessMap(map, { metric: 'probability', direction: 'LR' }).startsWith('<svg')
// → true   (8240 chars for the example map)

// bupaR: process_map(type_nodes = frequency("relative_case"),
//                    type_edges = performance(median, "hours"))
plotProcessMap(map, {
  nodeMetric: frequency('relative_case'),
  edgeMetric: performance('median', 'hours'),
});
```

### `PROCESS_MAP_LAYOUTS`

```ts
const PROCESS_MAP_LAYOUTS: readonly ProcessMapLayoutName[]
```

The process-map layout menu: `'layered'` (the bupaR-style flow layout, and
the silent fallback) followed by every
[`NETWORK_LAYOUTS`](./core.md#graph-layouts) algorithm, with the three built
for process maps — `spring` (the painter's default, matching CarmNote TNA's
shipped default), `saqr`, `oval` — promoted to the front. Deduplicated, so it
is exactly `NETWORK_LAYOUTS.length + 1` entries long. Pass any of them as
`layout`.

`networkLayout`, `NETWORK_LAYOUTS` and the `NetworkLayoutName` /
`NetworkLayoutOptions` / `LayoutPosition` types are re-exported from this
subpath too, so a process-map consumer that wants to precompute or reuse
coordinates needs only one import path.

### `processMapTables(map, options?)` → `ProcessMapTables`

Two tidy one-row-per-observation tables, `{ activities, edges }`. Every
column is a **projection** of a field `processMap()` already computed —
nothing is recomputed here, so a table can never disagree with the map it
came from. Both tables are sorted heaviest-first.

`ProcessMapActivityRow`: `activity`, `type` (`'activity' | 'start' | 'end'`),
`absoluteCount`, `relativeFrequency`, `caseCount`, `relativeCaseCoverage`,
`meanDuration`, `medianDuration`.

`ProcessMapEdgeRow`: `from`, `to`, `absoluteCount`, `relativeFrequency`,
`caseCount`, `probability`, `meanDuration`, `medianDuration`.

Both duration fields are `null` on a map with no timestamps — and also on a
timed map for an activity that never dwells (a terminal one, say), because
that absence is real.

| option | type | default | meaning |
|---|---|---|---|
| `topEdges` | `number` | `25` | keep at most this many hand-offs, heaviest first. `Infinity` for every edge |

```ts
const { activities, edges } = processMapTables(map, { topEdges: 10 });
activities[0];
// { activity: 'A', type: 'activity', absoluteCount: 3, relativeFrequency: 0.333…,
//   caseCount: 3, relativeCaseCoverage: 1, meanDuration: null, medianDuration: null }
```

### `processMapCaption(map, options?)` → `string`

The one-line summary that sits under a rendered map: how much log it
covers, what each label set means, and whether the log was timed. The
metric defaults match `plotProcessMap`'s own, so calling it with just the
map describes the map that painter would draw.

| option | type | default | meaning |
|---|---|---|---|
| `nodeMetric` | `MapMetric \| FrequencyValue` | `frequency('relative')` | the node perspective the caption names |
| `edgeMetric` | `MapMetric \| FrequencyValue` | `frequency('relative_antecedent')` | the edge perspective the caption names |

```ts
processMapCaption(map);
// "3 cases · 6 hand-offs · nodes: relative frequency · edges: share of the
//  source’s outflow · no timestamps"
```

### `attachProcessMapDrag(container, rerender, options?)` → `() => void`

**Browser only** — it touches the DOM, and only when called. Wires
pointer-drag onto the `[data-node]` groups of a rendered map and returns a
detach function. Not in `ladyna/light`; available from `ladyna`,
`ladyna/processmining` and the full bundles.

Two things every consumer got wrong before getting right, and the reason
this lives in the engine:

1. **The coordinate space.** The rendered `transform` is in final canvas
   space, but `positions` overrides are read *before* the canvas is fitted
   to its content. Without subtracting `offsetX` / `offsetY` a committed
   drag re-places the node in a different space than it was read from, and
   it jumps.
2. **The canvas lock.** The canvas is sized from the bounding box of
   everything drawn, so re-fitting it every frame makes the whole map
   rescale and slide under the cursor. During a drag the viewBox is held
   exactly as it was, and re-fitted once on release.

`rerender(positions, lock)` must repaint the container and honour `lock`
(pass it to `applyCanvasLock`). It is called at most once per animation
frame while dragging, and once more with `lock === null` on release. The
`positions` map is maintained across drags and handed back each time.

| option | type | meaning |
|---|---|---|
| `positions` | `ProcessMapPositions` | pre-seeded positions; mutated in place, so the caller keeps a live handle |
| `offset` | `{ x, y }` | `offsetX` / `offsetY` from `processMapData(map, options)` — what converts a rendered coordinate back into an override |
| `onDragStart` | `(id) => void` | a drag began on this node |
| `onDragEnd` | `(id, positions) => void` | a drag finished, after the final re-render |

```ts
const geom = processMapData(map, opts);
const detach = attachProcessMapDrag(el, (positions, lock) => {
  el.innerHTML = plotProcessMap(map, { ...opts, positions });
  applyCanvasLock(el.querySelector('svg'), lock);
}, { offset: { x: geom.offsetX, y: geom.offsetY } });
```

Also exported, and testable without a DOM: `applyCanvasLock(svg, lock)`,
`parseTranslate(transform)` → `{ x, y } | null`,
`viewBoxScale(viewBox, boundingBox)` → screen-px-to-viewBox-unit factors
(a missing or zero-sized box degrades to 1:1), and
`dragPosition(origin, pointerStart, pointerNow, scale)` → where the node
lands in override space.

### `plotVariants(variants, options?)` → `string`

Alias: `plot_variants`. **Takes the `traceVariants` result, not a log.**

Self-contained SVG variant explorer: one segmented color bar per trace
variant (segment = activity, in trace order), a `count (percentage%)` label
per row, and an activity legend.

| option | type | default | meaning |
|---|---|---|---|
| `top` | `number` | `20` | show at most this many variants |
| `width` | `number` | `900` | total SVG width |
| `rowHeight` | `number` | `30` | height of one variant row |
| `colors` | `Record<string, string>` | core palette in sorted activity order | activity → color override |
| `title` | `string` | — | header |
| `background` | `string` | `'#ffffff'` | canvas fill |

```ts
plotVariants(traceVariants(log), { title: 'Trace variants' }).startsWith('<svg')
// → true   (3146 chars for the example log)
```

---

## snake_case aliases

Every alias is the same function object as its camelCase original:

| alias | original |
|---|---|
| `event_log` | `eventLog` |
| `process_map` | `processMap` |
| `activity_stats` | `activityStats` |
| `trace_variants` | `traceVariants` |
| `trace_coverage` | `traceCoverage` |
| `case_metrics` | `caseMetrics` |
| `throughput_times` | `throughputTimes` |
| `dwell_times` | `dwellTimes` |
| `transition_durations` | `transitionDurations` |
| `plot_process_map` | `plotProcessMap` |
| `plot_variants` | `plotVariants` |
| `check_conformance` | `conformance` |
| `heuristic_miner` | `heuristicMiner` |
| `inductive_miner` | `inductiveMiner` |
| `tree_notation` | `treeNotation` |
| `tree_to_petri_net` | `treeToPetriNet` |
| `token_replay` | `tokenReplay` |

## Types

All exported as TypeScript types from the same subpaths.

**Event log** — `EventLog` (`{ sequences, caseIds, timestamps, activities }`),
`EventLogOptions` (`{ caseIds?, timestamps? }`),
`LogInput` (`EventLog | SequenceData` — what every verb accepts),
`LogTimestamps` (`ReadonlyArray<ReadonlyArray<number | null> | null>`).

**Analytics** — `ActivityStat`, `BoundaryActivity`
(`{ activity, count, fraction }`), `TraceLengthSummary`, `TraceVariant`,
`CoveragePoint` (`{ rank, cumulativeCount, cumulativeFraction }`),
`CaseMetric`, `ThroughputRow`, `DwellStat`, `TransitionDurationStat`.

**Process map** — `ProcessMap`, `ProcessMapNode`, `ProcessMapEdge`,
`ProcessMapOptions`, `ProcessMapMetric`
(`'absolute' | 'relative' | 'case' | 'probability'` — the legacy
single-switch vocabulary).

**Conformance** — `ConformanceResult`, `CaseConformance`, `Deviation`,
`ReferenceEdge` (`{ from, to }`).

**Discovery** — `HeuristicMinerOptions`, `HeuristicNet`, `DependencyEdge`,
`SelfLoopEdge`, `TwoLoopEdge`, `ProcessTree` (discriminated union:
`activity | tau | sequence | xor | parallel | loop`; for `loop`,
`children[0]` is the body), `InductiveMinerResult`, `PetriNet`,
`PetriTransition` (`{ id, label }`, `label: null` = silent τ),
`TokenReplayResult`, `CaseReplay`.

**Metrics** — `MapMetric` (`FrequencyMetric | PerformanceMetric`),
`FrequencyMetric`, `PerformanceMetric`, `FrequencyValue`,
`PerformanceAggregate` (`'mean' | 'median' | 'min' | 'max' | 'sum'`),
`DurationUnit` (`'auto' | 'secs' | 'mins' | 'hours' | 'days' | 'weeks'`).

**Layout** — `LayeredLayoutOptions`, `LayeredLayoutResult`,
`LayoutNodeInput` (`{ id, width, height }`),
`LayoutEdgeInput` (`{ from, to, weight? }`).

**Plot** — `ProcessMapPlotOptions`, `ProcessMapPlotData`,
`ProcessMapPlotNode`, `ProcessMapPlotEdge`, `ProcessMapDirection`
(`'LR' | 'TB'`), `VariantsPlotOptions`.
