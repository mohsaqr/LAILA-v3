# Directed motifs and named subnetworks

`ladyna/analysis` (also available from `ladyna`) implements the complete
16-class Holland–Leinhardt/MAN directed triad census used by **cograph**. It
supports count tables, named three-node instances with all six edge weights,
induced TNA subnetworks, deterministic null-model significance, and four
self-contained SVG views.

```ts
import {
  motifs, subgraphs, extractMotifSubnetwork,
  plotMotifs, plotMotifSubnetwork,
} from 'ladyna/analysis';

const network = {
  matrix: [[0, 7, 2, 0], [1, 0, 6, 3], [4, 0, 0, 8], [0, 2, 3, 0]],
  labels: ['Plan', 'Ask', 'Explain', 'Revise'],
};
const census = motifs(network, { pattern: 'all', significance: true, nPerm: 500 });
const named = subgraphs(network, { pattern: 'triangle', minCount: 0, minTransitions: 0 });

document.querySelector('#census')!.innerHTML = plotMotifs(census, { type: 'types' });
document.querySelector('#named')!.innerHTML = plotMotifs(named, { type: 'triads' });
document.querySelector('#focus')!.innerHTML = plotMotifSubnetwork(network, named.results[0]);
```

The [live motif gallery](../../demo/motifs.html) shows the complete workflow.
Motif SVGs are static and responsive; they do not install pan, zoom, wheel, or
drag handlers.

## Taxonomy

`TRIAD_TYPES` is ordered exactly as cograph/igraph's MAN census:

| Type | Description | Type | Description |
|---|---|---|---|
| `003` | Empty | `012` | Single edge |
| `102` | Mutual pair | `021D` | Out-star |
| `021U` | In-star | `021C` | Chain |
| `111D` | Out-star + mutual | `111U` | In-star + mutual |
| `030T` | Feed-forward | `030C` | Cycle |
| `201` | Mutual + in-star | `120D` | Two out-stars |
| `120U` | Two in-stars | `120C` | Mixed regulated |
| `210` | Mutual + feed-forward | `300` | Clique |

Canonical 3×3 binary templates are exported as `TRIAD_PATTERNS`; human labels
are in `TRIAD_DESCRIPTIONS`. `classifyTriad(ab, ba, ac, ca, bc, cb)` classifies
six directed dyads and is invariant to node order.

## Counting and extraction

### `triadCensus(input, options?)`

Returns `Record<TriadType, number>` containing all 16 types, including zero
counts. Every unordered node triple is counted once, so the total is
`choose(n, 3)`. Inputs may be a `TNA`, `Matrix`, square `number[][]`, or
`{ matrix, labels? }`.

### `extractTriads(input, options?)`

Returns one `TriadInstance` for every non-empty named triple that passes the
filters. Rows contain the `nodes`, original `indices`, `type`/`triad`, all six
weights (`weightAB`, `weightBA`, `weightAC`, `weightCA`, `weightBC`,
`weightCB`), and `totalWeight`. Options are `type`, `involving`, `threshold`,
`minTotal` (default 5), and `edgeMethod`.

### `motifCensus(input, options?)`

Returns one row per MAN type. With `significance: true`, rows also include
`expected`, `sd`, `z`, two-sided normal `p`, and `significant`.

```ts
motifCensus(network, {
  significance: true,
  nullModel: 'configuration', // directed degree-preserving swaps
  nPerm: 1000,
  seed: 42,
});
```

`nullModel: 'gnm'` instead samples the same number of directed edges from all
possible non-loop positions. The JavaScript stream is deterministic for a
given seed but intentionally does not reproduce R's random stream.

## Unified cograph-style API

### `motifs(input, options?)` and `subgraphs(input, options?)`

The default is census mode. Set `namedNodes: true` or `subgraphs: true` for
named instances; `subgraphs()` is the convenience wrapper.

```ts
interface MotifsOptions {
  namedNodes?: boolean;
  subgraphs?: boolean;
  pattern?: 'triangle' | 'network' | 'closed' | 'all';
  include?: TriadType | TriadType[];
  exclude?: TriadType | TriadType[];
  minCount?: number;       // default 0 census; 5 named
  minTransitions?: number; // default 5
  top?: number;
  edgeMethod?: 'any' | 'expected' | 'percent';
  edgeThreshold?: number;
  significance?: boolean;
  nPerm?: number;
  nullModel?: 'configuration' | 'gnm';
  seed?: number;
}
```

Pattern filters match cograph:

- `triangle`: `030C`, `030T`, `120C`, `120D`, `120U`, `210`, `300`
- `network`: all except `003`, `012`, `021C`
- `closed`: all except `003`, `012`, `021C`, `120C`
- `all`: all 16 types

`include` replaces the pattern set; `exclude` is then removed. In aggregate
named mode, `minCount` inclusively filters each instance's observed total edge
weight, matching current cograph behavior.

## Named induced subnetworks

### `extractMotifSubnetwork(input, selection)`

Extracts an induced three-node `TNA` while preserving labels, the weighted
matrix, normalized initial probabilities, model type, scaling, parameters, and
the count matrix when those values exist on the input model. `selection` is
either three node names or a `TriadInstance`.

## Plotting

### `plotMotifs(result, options?)`

Accepts `motifs()` or `subgraphs()` output and returns one SVG string.

| `type` | Input | Picture |
|---|---|---|
| `triads` | named | Named-node cards using the standard TNA network painter, total weight, full-name key |
| `types` | census or named | MAN-type count bars |
| `significance` | significant census | Diverging z-score bars with ±1.96 guides |
| `patterns` | census or named | Canonical A/B/C topology cards |

The default is `triads` for named results and `types` for a census. Options
include `width`, `columns`, `top`, `showWeights`, `showLegend`, and colors.

### `plotMotifSubnetwork(input, selection, options?)`

Calls the same `plotNetwork()` implementation used by the main TNA interactive
demo, on the induced three-node model. It therefore uses the package's standard
node palette, boundary-aware curves, arrow polygons, label halos, tooltips, and
the demo's linear/proportional edge-width scale. Integer weights are compact
(`6`, not `6.000`). Options include `width`, `height`, `threshold`,
`showWeights`, `color`, `nodeFill`, and `nodeColors`.

The named-subnetwork demo exposes both layers explicitly: its featured-renderer
control defaults to a direct `plotNetwork(extractMotifSubnetwork(...), options)`
call and can switch to `plotMotifSubnetwork(...)`. Both executable calls appear
in that page's generated `#technical-reference` section.

## cograph aliases

- `triad_census` → `triadCensus`
- `extract_triads` → `extractTriads`
- `motif_census` → `motifCensus`
- `extract_motif_subnetwork` → `extractMotifSubnetwork`
- `plot_motifs` → `plotMotifs`
- `plot_motif_subnetwork` → `plotMotifSubnetwork`
