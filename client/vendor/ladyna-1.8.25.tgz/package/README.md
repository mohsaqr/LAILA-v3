# ladyna

**Transition Network Analysis for JavaScript/TypeScript**

A zero-dependency, pure TypeScript implementation of Transition Network Analysis (TNA) for modeling sequential data as weighted directed networks. Works in Node.js, Deno, Bun, and browsers.

Ported from the [R TNA package](https://cran.r-project.org/package=TNA) and the [Python tna package](https://github.com/mohsaqr/tnapy), with numerical equivalence to R TNA validated to machine epsilon (~1e-15).

**Demo:** ships in-repo as source — run `npm run demo` and open the printed URL (the full painter catalogue is at `/tna-js/gallery.html`). Every demo page includes a generated `#technical-reference` section with its public imports, exact live function calls, result contracts, documentation links, and copy controls. It is not hosted: GitHub Pages is unavailable on this private repository. | **Desktop app:** [TNA Desktop](https://saqr.me/tnadesktop/)

---

## Ecosystem position

ladyna is part of a three-library ecosystem for network and sequence analysis
(`ARCHITECTURE.md` is the authoritative contract). It owns **sequences →
transition networks**, sequence-pattern and association-rule analytics, and everything you do *to* a
TNA model (centralities specific to TNA, pruning, communities, bootstrap,
permutation, stability, reliability, Markov-order test).

Sibling libraries with different scope:

- **snajs** — general SNA on plain `number[][]` adjacency matrices. Use for centralities / metrics / community detection on a graph that isn't a TNA model. (~95 centrality measures.)
- **[psychaj](https://github.com/mohsaqr/psychaj)** — psychometric networks from variable matrices (Pearson, partial correlation, GLASSO, mlVAR, graphicalVAR, IsingFit, MGM).

The former `dynajs` and `codynaj` packages are retired; their supported
descriptives, sequence indices, pattern discovery, association, and regression
verbs now live in ladyna.

### ladyna centralities ≠ snajs centralities

Both libraries expose `centralities()` and overlapping measure names (`Betweenness`, `Closeness`, `PageRank`, etc.). They answer to **different R references** and produce **different numerical values for the same matrix**:

| | ladyna | snajs |
|---|---|---|
| R reference | `tna` R package | `igraph` / `cograph` |
| Distance convention | `1/weight` (probabilities → costs) | raw weight |
| Direction | always directed | follows `directed` flag |
| Output | `Float64Array` | `number[]` |

If your code uses TNA models, call **ladyna's** `centralities(model)`. If you have a generic graph and want igraph-equivalent values, call **snajs's** `computeCentralities(matrix, labels, directed)`. Neither is "more correct" — they're parity-verified against the toolchain their consumers expect.

The workspace-level `ARCHITECTURE.md` (kept alongside the sibling repos, not inside this one) records the contract: who owns what, what depends on whom, and how data flows when a workflow crosses paradigms.

---

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Core Concepts](#core-concepts)
- [Prediction Suffix Trees](#prediction-suffix-trees)
- [Lag Dynamics](#lag-dynamics)
- [Association-Rule Mining](#association-rule-mining)
- [Directed Motifs and Named Subnetworks](#directed-motifs-and-named-subnetworks)
- [MCML Hierarchical Network Plot](#mcml-hierarchical-network-plot)
- [Visualization](#visualization)
- [Guides](#guides)
  - [Clustering Sequences and Building Per-Cluster Models](#clustering-sequences-and-building-per-cluster-models)
  - [Building a Dashboard with Clusters](#building-a-dashboard-with-clusters)
  - [Group Comparison Workflow](#group-comparison-workflow)
- [API Reference](#api-reference)
  - [Model Building](#model-building)
  - [Centralities](#centralities)
  - [Pruning](#pruning)
  - [Community Detection](#community-detection)
  - [Clique Detection](#clique-detection)
  - [Sequence Clustering](#sequence-clustering)
  - [Sequence Comparison](#sequence-comparison)
  - [Group Models](#group-models)
  - [Network Plots & Drawing](#network-plots--drawing)
  - [Data Preparation](#data-preparation)
  - [Utility Functions](#utility-functions)
- [Using in a Website](#using-in-a-website)
  - [With a Bundler (Vite, Webpack, etc.)](#with-a-bundler)
  - [From a CDN (ESM)](#from-a-cdn)
  - [Server-Side (Node.js / Bun / Deno)](#server-side)
- [Data Format](#data-format)
- [Types Reference](#types-reference)
- [Full Example: Analyzing Student Learning Behavior](#full-example-analyzing-student-learning-behavior)
- [Citation](#citation)
- [Related Projects](#related-projects)
- [License](#license)

---

## Installation

```bash
# npm
npm install ladyna

# yarn
yarn add ladyna

# pnpm
pnpm add ladyna

# bun
bun add ladyna
```

Or install from GitHub:

```bash
npm install github:mohsaqr/tna-js
```

---

## Quick Start

```typescript
import { tna, centralities, prune, communities, plotNetwork } from 'ladyna';

// Your sequential data: each row is a sequence of states
const data = [
  ['A', 'B', 'C', 'A', 'B'],
  ['B', 'C', 'A', 'C', 'B'],
  ['A', 'A', 'B', 'C', 'A'],
  ['C', 'B', 'A', 'B', 'C'],
];

// Build a TNA model (relative transition probabilities)
const model = tna(data);

console.log(model.labels);    // ['A', 'B', 'C']
console.log(model.type);      // 'relative'
console.log(model.inits);     // Float64Array [0.5, 0.25, 0.25]

// Compute centrality measures
const cent = centralities(model);
console.log(cent.measures.OutStrength);   // Float64Array [...]
console.log(cent.measures.Betweenness);   // Float64Array [...]

// Prune weak edges (remove edges below threshold)
const pruned = prune(model, 0.1);

// Detect communities
const comm = communities(model, { methods: 'louvain' });
console.log(comm.assignments.louvain);    // [0, 1, 0]
console.log(comm.counts.louvain);         // 2

// Render the transition network as a self-contained SVG (browser)
document.body.innerHTML = plotNetwork(model);
```

---

## Core Concepts

**TNA** (Transition Network Analysis) models sequential data as a weighted directed graph. Each unique state in the data becomes a node, and transitions between consecutive states become weighted directed edges.

**Model types:**

| Function | Type | Description |
|----------|------|-------------|
| `tna()` | `relative` | Row-normalized transition probabilities (values sum to 1 per row) |
| `ftna()` | `frequency` | Raw transition counts |
| `ctna()` | `co-occurrence` | Bidirectional co-occurrence counts |
| `atna()` | `attention` | Exponential decay weighted transitions (recent transitions weighted more) |

**What you get:**
- A `TNA` object with a weight matrix, initial state probabilities, and state labels
- 9 centrality measures per node (OutStrength, InStrength, Betweenness, Closeness, etc.)
- Network pruning, community detection, clique detection
- Sequence clustering (PAM, hierarchical) with 4 distance metrics
- Pattern comparison across groups with permutation testing

## Prediction Suffix Trees

`ladyna/transitiontrees` provides a typed, zero-dependency implementation of the
computational API in Saqr et al.'s R
[`transitiontrees`](https://github.com/mohsaqr/transitiontrees) package. It fits
variable-depth prediction suffix trees and exposes the same modeling workflows
using camelCase names.

```typescript
import {
  contextTree,
  treePathways,
  predictNext,
  pruneTree,
  treeModelFit,
} from 'ladyna/transitiontrees';

const sequences = [
  ['read', 'annotate', 'discuss', 'quiz'],
  ['read', 'quiz', 'read', 'annotate'],
  ['discuss', 'read', 'annotate', 'read'],
];

const tree = contextTree(sequences, {
  maxDepth: 3,
  minCount: 1,
  smoothing: { method: 'kneser_ney', discount: 0.75 },
});

console.log(predictNext(tree, ['read', 'annotate']));
console.table(treePathways(tree));
console.log(treeModelFit(pruneTree(tree, { criterion: 'G2' })));
```

The subpath includes:

- five smoothing methods: floor, Laplace, Kneser–Ney, Witten–Bell, and
  Jelinek–Mercer;
- G², KL, AIC, and BIC pruning;
- prediction, simulation, scoring, likelihood, perplexity, and pathway queries;
- pathway mining, sequential gap imputation, dependence diagnostics, and
  subtrees;
- cross-validated tuning, symmetric-KL tree comparison, permutation tests, and
  pathway bootstrap stability;
- long-event reshaping and multi-group behavioral/usage comparisons.

Deterministic results are checked against fixtures generated by R
`transitiontrees` 0.1.2. Seeded stochastic workflows use `ladyna`'s portable RNG,
so they replay identically across JavaScript runtimes but do not reproduce R's
random-number stream. Results are ordinary typed data, and twelve built-in
`plot*` functions (`plotTree`, `plotPathways`, `plotDivergence`,
`plotTrajectories`, …) render them as self-contained SVG strings.

Runnable browser examples are collected in
[`demo/transitiontrees/index.html`](demo/transitiontrees/index.html), covering
fitting, pruning, prediction, mining, tuning, comparison, bootstrap, and groups.
The visualization API returns dependency-free SVG with a white background by
default; pass `{ theme: 'dark' }` to any plot function for dark output.

## Lag Dynamics

`ladyna/lagdynamics` is a typed, dependency-free implementation of the complete
public API of R `lagdynamics` 0.32. It covers classical LSA plus the two-cell,
bidirectional, parallel-dominance, and nonparallel-dominance engines; grouped
and multi-lag analysis; structural-zero IPF; confirmatory inference; group
comparison; transfer entropy; and browser-native SVG visualization.

```typescript
import {
  lsa, transitions, bootstrapLSA, compareLSA,
  plotTransitions, plotForest,
} from 'ladyna/lagdynamics';

const fit = lsa([
  ['Question', 'Explain', 'Agree', 'Elaborate'],
  ['Question', 'Elaborate', 'Explain', 'Agree'],
  ['Disagree', 'Explain', 'Question', 'Agree'],
]);

console.table(transitions(fit, { significant: true }));
const boot = bootstrapLSA(fit, { iterations: 1000, seed: 42 });
document.body.innerHTML = plotForest(boot);
```

The subpath exports camelCase names and exact R-style aliases. Deterministic
quantities are checked against R fixtures to numerical tolerance, while
bootstrap and permutation equality is tested using replay indices. Plotting
includes heatmaps, lag-transition networks, chord diagrams, polar sunbursts,
uncertainty forests, and group-comparison barrel/heatmap views. See the
[interactive gallery](demo/lagdynamics.html).

## Association-Rule Mining

`ladyna/association` provides zero-dependency market-basket mining with three
interchangeable engines: Apriori, Eclat, and FP-growth. It returns frequent,
closed, maximal, or generator itemsets; creates directional rules; computes a
large contingency-measure family; removes redundant rules; and produces ranked
recommendations.

```typescript
import { apriori, plotRuleGraph } from 'ladyna/association';

const result = apriori([
  ['bread', 'milk'],
  ['bread', 'diaper', 'beer'],
  ['milk', 'diaper', 'beer'],
  ['bread', 'milk', 'diaper', 'beer'],
], { minSupport: 0.25, minConfidence: 0.6, maxRhsLength: 1 });

document.body.innerHTML = plotRuleGraph(result);
```

Apriori, Eclat, and FP-growth are cross-checked against the same itemset lattice;
rules and interest measures are independently validated against R `arules`
1.7.11. Advanced coverage includes weighted Eclat, hypergeometric significance,
out-of-sample evaluation, rule clustering and representatives. Fifteen SVG
views plus a draggable force-network explorer cover item/rule networks,
scatter, matrices, Sankey, chord, UpSet, itemset lattices, parallel coordinates,
and contingency views. See the
[complete association API](docs/api/association.md) and
[interactive gallery](demo/association.html).

## Directed Motifs and Named Subnetworks

The analysis module implements cograph's complete 16-type directed triad
census, including named three-node instances and induced weighted subnetworks:

```typescript
import { motifs, subgraphs, plotMotifs, plotMotifSubnetwork } from 'ladyna';

const census = motifs(model, { pattern: 'all', significance: true });
const named = subgraphs(model, { pattern: 'triangle', minCount: 0 });

document.querySelector('#counts')!.innerHTML =
  plotMotifs(census, { type: 'types' });
document.querySelector('#motif')!.innerHTML =
  plotMotifSubnetwork(model, named.results[0]);
```

Named results preserve actual node labels and all six possible directed edge
weights. The motif painters return static responsive SVG and deliberately have
no pan or zoom behavior. See the [complete motif API](docs/api/motifs.md) and
[named-subnetwork gallery](demo/motifs.html).

## MCML Hierarchical Network Plot

`plotMCML()` renders the cograph-style micro/macro hierarchy using ladyna's
network plot-data conventions. It draws original within-cluster edges,
aggregated shell-to-shell edges, the macro cluster network, and dashed
detail-to-summary links. Pass either an existing Nestimate/cograph-shaped
MCML object or a normal `TNA` with named node clusters.

```typescript
import { tna, plotMCML } from 'ladyna';

const network = tna([
  ['Read', 'Annotate', 'Discuss', 'Quiz'],
  ['Read', 'Quiz', 'Discuss', 'Annotate'],
]);

document.body.innerHTML = plotMCML(network, {
  clusters: {
    Study: ['Read', 'Annotate'],
    Social: ['Discuss', 'Quiz'],
  },
  theme: 'rich',
  summaryPie: 'inits', // use 'self' for cluster retention
});
```

Use `mcmlPlotData()` when an application wants to paint the same typed shells,
nodes, and four edge layers with D3, canvas, React, or another renderer. As in
current cograph, `mode: 'tna'` enables edge labels but does not transform an
existing object's weights.

---

## Visualization

Every plot in ladyna is a **self-contained SVG string** — no D3, no charting
library, no runtime dependencies. The wiring idiom is always:

```typescript
import { tna, plotNetwork } from 'ladyna';

const model = tna(sequences);
document.getElementById('net')!.innerHTML = plotNetwork(model);
```

`plotNetwork()` is the default network view for any TNA model (the R
`plot.tna` analogue): circular layout, weight-scaled curved edges with
probability labels, an initial-probability ring per node, arrowheads, and
hover tooltips. It scales to its container by default. Key options:

```typescript
plotNetwork(model, {
  width: 460, height: 340,        // canvas (SVG scales responsively anyway)
  title: 'Cluster A',             // rendered only when provided
  cutoff: 0.05,                   // hide edges at or below this weight
  edgeLabels: false,              // numeric labels on/off (default on)
  colorMap: createColorMap(tna(allSequences).labels),  // consistent colours
});                               // across side-by-side panels
```

A `GroupTNA` input returns `Record<string, string>` — one SVG per group,
titled by group name.

**All built-in plot functions:**

| Picture | Function | Section / demo |
|---|---|---|
| Transition network of a TNA model | `plotNetwork(model)` | above |
| Start→End process map | `plotProcessMap(processMap(model))` | `demo/processmining.html` |
| Trace-variant bars | `plotVariants(traceVariants(log))` | `demo/processmining.html` |
| Micro/macro cluster hierarchy | `plotMCML(model, { clusters })` | [MCML section](#mcml-hierarchical-network-plot), `demo/mcml.html` |
| HTNA actor network | `plotHTNA(htnaModel)` | `demo/htna.html` |
| Context trees: topology, pathways, divergence, trajectories, bootstrap… | `plotTree`, `plotPathways`, `plotDivergence`, +9 more | [Prediction Suffix Trees](#prediction-suffix-trees), `demo/transitiontrees/` |
| Lag-sequential: heatmap, network, chords, polar, forest, comparison | `plotLSAHeatmap`, `plotLSATransitions`, `plotLSAChords`, … | [Lag Dynamics](#lag-dynamics), `demo/lagdynamics.html` |
| Association rules: interactive networks, Sankey, chord, UpSet, lattices, matrices | `mountAssociationExplorer`, `plotRuleSankey`, `plotAssociationChord`, +12 more | [Association-Rule Mining](#association-rule-mining), `demo/association.html` |
| Directed motifs: census, significance, topology cards, named subnetworks | `plotMotifs`, `plotMotifSubnetwork` | [Directed Motifs](#directed-motifs-and-named-subnetworks), `demo/motifs.html` |

Run `npm run demo` to browse the live gallery. Building a custom interactive
renderer instead? The shared edge/arrow/self-loop geometry is exported as
`networkEdgeGeometry`, `networkArrowPolygon`, and `networkSelfLoopGeometry`
so bespoke views stay visually consistent with the built-in painters.

Every demo entry also carries a build-generated technical reference at
`#technical-reference`. It is derived from the page's actual module imports and
calls, and records the public package path, API name, exact executable call,
return category, source files, ladyna version, and canonical documentation URL.
This makes each visual example directly citable and reproducible without
maintaining a second, manually copied code sample.

---

## Guides

### Clustering Sequences and Building Per-Cluster Models

A common workflow is to cluster sequences by similarity, then build a separate TNA model for each cluster to compare behavioral patterns across groups.

```typescript
import {
  tna, clusterSequences, centralities, communities, prune, summary,
  colorPalette, createColorMap,
} from 'ladyna';

// 1. Your sequence data
const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'quiz', 'read', 'annotate', 'discuss'],
  ['discuss', 'read', 'annotate', 'read', 'quiz'],
  ['quiz', 'quiz', 'quiz', 'read', 'quiz'],
  ['quiz', 'read', 'quiz', 'quiz', 'quiz'],
  ['read', 'read', 'annotate', 'discuss', 'quiz'],
];

// 2. Cluster sequences into k groups
const k = 2;
const clusters = clusterSequences(sequences, k, {
  dissimilarity: 'lv',   // Levenshtein distance
  method: 'pam',         // Partitioning Around Medoids
});

console.log(clusters.assignments); // e.g. [1, 1, 1, 2, 2, 1] (1-indexed)
console.log(clusters.silhouette);  // Clustering quality (-1 to 1)
console.log(clusters.sizes);       // e.g. [4, 2]

// 3. Split sequences by cluster
const clusterData: Record<string, (string | null)[][]> = {};
for (let i = 0; i < sequences.length; i++) {
  const label = `Cluster ${clusters.assignments[i]}`;
  if (!clusterData[label]) clusterData[label] = [];
  clusterData[label].push(sequences[i]!);
}

// 4. Build a TNA model per cluster
for (const [name, seqs] of Object.entries(clusterData)) {
  const model = tna(seqs);
  const pruned = prune(model, 0.1);
  const cent = centralities(pruned);
  const comm = communities(pruned, { methods: 'louvain' });
  const s = summary(pruned);

  console.log(`\n--- ${name} (${seqs.length} sequences) ---`);
  console.log(`Edges: ${s.nEdges}, Density: ${Number(s.density).toFixed(3)}`);
  console.log(`Communities: ${comm.counts.louvain}`);
  model.labels.forEach((label, i) => {
    console.log(`  ${label}: OutStrength=${cent.measures.OutStrength[i]!.toFixed(3)}`);
  });
}
```

**Choosing dissimilarity metrics:**

| Metric | Best for | Description |
|--------|----------|-------------|
| `hamming` | Equal-length sequences | Counts positional mismatches |
| `lv` | Variable-length sequences | Edit distance (insert, delete, substitute) |
| `osa` | Sequences with transpositions | Edit distance + transpositions |
| `lcs` | Subsequence similarity | Longest common subsequence distance |

**Choosing clustering methods:**

| Method | Description |
|--------|-------------|
| `pam` | Partitioning Around Medoids — robust, finds representative sequences |
| `hierarchical` | Agglomerative clustering with average linkage |

---

### Building a Dashboard with Clusters

This guide shows how to build a multi-panel dashboard that clusters sequences and displays per-cluster networks and centrality charts — using only ladyna. The network plots come from the library's own `plotNetwork()` (the R `plot.tna` analogue: circular layout, weight-scaled curved edges, initial-probability rings — a self-contained SVG string; no charting library, no D3, no force simulation).

**Setup:**

```bash
npm create vite@latest tna-dashboard -- --template vanilla-ts
cd tna-dashboard
npm install ladyna
```

**`src/main.ts` — Full dashboard:**

```typescript
import {
  tna, clusterSequences, centralities, prune,
  plotNetwork, createColorMap, summary,
} from 'ladyna';
import type { TNA, CentralityResult } from 'ladyna';

// ──────────────────────────────────────────
// 1. Data & Clustering
// ──────────────────────────────────────────

const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'quiz', 'read', 'annotate', 'discuss'],
  ['discuss', 'read', 'annotate', 'read', 'quiz'],
  ['quiz', 'quiz', 'quiz', 'read', 'quiz'],
  ['quiz', 'read', 'quiz', 'quiz', 'quiz'],
  ['read', 'read', 'annotate', 'discuss', 'quiz'],
  ['annotate', 'discuss', 'read', 'quiz', 'annotate'],
  ['quiz', 'quiz', 'read', 'quiz', 'read'],
];

const k = 3;
const clusters = clusterSequences(sequences, k, {
  dissimilarity: 'lv',
  method: 'pam',
});

// Split sequences by cluster and build per-cluster models
const clusterGroups = new Map<string, { model: TNA; cent: CentralityResult; size: number }>();
const clusterSeqs: Record<string, (string | null)[][]> = {};

for (let i = 0; i < sequences.length; i++) {
  const label = `Cluster ${clusters.assignments[i]}`;
  if (!clusterSeqs[label]) clusterSeqs[label] = [];
  clusterSeqs[label].push(sequences[i]!);
}

for (const [name, seqs] of Object.entries(clusterSeqs)) {
  const model = tna(seqs);
  const pruned = prune(model, 0.05);
  const cent = centralities(pruned);
  clusterGroups.set(name, { model: pruned, cent, size: seqs.length });
}

// ──────────────────────────────────────────
// 2. Summary Panel
// ──────────────────────────────────────────

const app = document.getElementById('app')!;

const summaryHtml = `
  <h1>TNA Cluster Dashboard</h1>
  <p>Sequences: ${sequences.length} | Clusters: ${k} |
     Silhouette: ${clusters.silhouette.toFixed(3)}</p>
  <p>Sizes: ${clusters.sizes.join(', ')}</p>
`;
app.innerHTML = summaryHtml;

// ──────────────────────────────────────────
// 3. Per-Cluster Network + Centrality Cards
// ──────────────────────────────────────────

const CARD_COLORS = ['#4e79a7', '#e15759', '#59a14f', '#edc948'];
// One colour per state, shared by every card, so clusters stay comparable.
const colorMap = createColorMap(tna(sequences).labels);
const grid = document.createElement('div');
grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:16px;margin-top:20px';
app.appendChild(grid);

let idx = 0;
for (const [name, { model, cent, size }] of clusterGroups) {
  const color = CARD_COLORS[idx % CARD_COLORS.length]!;
  const s = summary(model);

  const card = document.createElement('div');
  card.style.cssText = 'border:1px solid #ddd;border-radius:8px;padding:16px;background:#fff';
  card.innerHTML = `
    <h3 style="color:${color};margin:0 0 4px">${name}</h3>
    <p style="font-size:13px;color:#888;margin:0 0 12px">
      ${size} sequences · ${s.nEdges} edges · density ${Number(s.density).toFixed(3)}
    </p>
    ${plotNetwork(model, { width: 460, height: 340, colorMap })}
    ${centralityBars(cent, model.labels, color)}
  `;
  grid.appendChild(card);
  idx++;
}

// ──────────────────────────────────────────
// 4. Network Rendering — one library call
// ──────────────────────────────────────────
//
// `plotNetwork()` returns a complete standalone <svg> string (scales to its
// container): circular layout, weight-scaled curved edges with probability
// labels, an initial-probability ring per node, arrows and hover tooltips.
// Useful options: `cutoff`, `edgeLabels: false`, `title`, `colors`/`colorMap`.
// Other built-in views: plotProcessMap(processMap(model)) for a Start→End
// process map, plotMCML() for cluster hierarchies, plotHTNA() for actor
// networks, plotVariants() for trace variants.

// ──────────────────────────────────────────
// 5. Centrality Bars (plain HTML, no chart library)
// ──────────────────────────────────────────

function centralityBars(cent: CentralityResult, labels: string[], accentColor: string): string {
  const measure = 'OutStrength';
  const values = cent.measures[measure]!;
  const data = labels.map((label, i) => ({ label, value: values[i]! }))
    .sort((a, b) => b.value - a.value);
  const max = Math.max(...data.map(d => d.value), 1e-9);

  const rows = data.map(({ label, value }) => `
    <div style="display:flex;align-items:center;gap:8px;font-size:12px;margin:2px 0">
      <span style="width:70px;text-align:right;color:#555">${label}</span>
      <span style="background:${accentColor};height:14px;border-radius:3px;width:${(value / max) * 180}px"></span>
      <span style="color:#666">${value.toFixed(3)}</span>
    </div>`).join('');

  return `<h4 style="font-size:11px;color:#666;margin:12px 0 4px">${measure}</h4>${rows}`;
}
```

**`index.html`:**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TNA Cluster Dashboard</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; padding: 24px; background: #f5f5f5; }
    #app { max-width: 1200px; margin: 0 auto; }
    h1 { margin: 0 0 8px; }
  </style>
</head>
<body>
  <div id="app"></div>
  <script type="module" src="/src/main.ts"></script>
</body>
</html>
```

Run with `npm run dev` — you'll see a dashboard with per-cluster network visualizations and centrality bar charts.

**Extending the dashboard:**

```typescript
// Add community detection per cluster
import { communities } from 'ladyna';

for (const [name, { model }] of clusterGroups) {
  const comm = communities(model, { methods: ['louvain', 'walktrap'] });
  console.log(`${name}: ${comm.counts.louvain} communities (Louvain)`);

  // Color nodes by community
  const communityColors = ['#4e79a7', '#e15759', '#59a14f', '#edc948'];
  model.labels.forEach((label, i) => {
    const commId = comm.assignments.louvain![i]!;
    console.log(`  ${label} → Community ${commId} (${communityColors[commId]})`);
  });
}

// Add clique detection
import { cliques } from 'ladyna';

for (const [name, { model }] of clusterGroups) {
  const cl = cliques(model, { threshold: 0.05 });
  console.log(`${name}: ${cl.labels.length} cliques found`);
  cl.labels.forEach((labels, i) => {
    console.log(`  Clique ${i + 1}: ${labels.join(' → ')}`);
  });
}

// Compare patterns across clusters with permutation testing
import { groupTna, compareSequences } from 'ladyna';

// Build group model: flat sequences + parallel cluster labels
const clusterLabels = sequences.map((_s, i) => `Cluster ${clusters.assignments[i]}`);
const gModel = groupTna(sequences, clusterLabels);
const comparison = compareSequences(gModel, {
  sub: [1, 2],      // Compare single states and bigrams
  test: true,        // Run permutation test
  iter: 999,
  seed: 42,
});

for (const row of comparison) {
  if (row.pValue !== undefined && row.pValue < 0.05) {
    console.log(`Significant: ${row.pattern} (p=${row.pValue.toFixed(3)}, ES=${row.effectSize?.toFixed(3)})`);
  }
}
```

---

### Group Comparison Workflow

When your data already has group labels (e.g., experimental vs. control, high vs. low performers), use group models directly:

```typescript
import {
  groupTna, centralities, communities, prune, compareSequences,
  groupNames, groupEntries,
} from 'ladyna';

// All sequences in a flat array
const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'discuss', 'annotate', 'quiz', 'discuss'],
  ['annotate', 'read', 'discuss', 'quiz', 'annotate'],
  ['quiz', 'quiz', 'read', 'quiz', 'quiz'],
  ['read', 'quiz', 'quiz', 'read', 'quiz'],
  ['quiz', 'read', 'quiz', 'quiz', 'read'],
];

// Parallel array of group labels (one per sequence)
const groups = [
  'High Performers', 'High Performers', 'High Performers',
  'Low Performers', 'Low Performers', 'Low Performers',
];

// Build group models in one call
const gModel = groupTna(sequences, groups);

// Centralities across all groups (combined result with group labels)
const cent = centralities(gModel);
console.log(cent.groups);   // ['High Performers', 'High Performers', ..., 'Low Performers', ...]
console.log(cent.labels);   // State labels repeated per group

// Per-group analysis
for (const [name, model] of groupEntries(gModel)) {
  const pruned = prune(model, 0.1);
  const comm = communities(pruned, { methods: 'louvain' });
  console.log(`${name}: ${comm.counts.louvain} communities`);
}

// Statistical comparison: which patterns differ between groups?
const comparison = compareSequences(gModel, {
  sub: [1, 2, 3],   // Unigrams, bigrams, trigrams
  test: true,
  iter: 999,
  adjust: 'bonferroni',
  seed: 42,
});

// Show significant differences
const significant = comparison.filter(r => r.pValue !== undefined && r.pValue < 0.05);
for (const row of significant) {
  console.log(`${row.pattern}: p=${row.pValue!.toFixed(3)}, ES=${row.effectSize?.toFixed(3)}`);
  console.log(`  Proportions:`, row.proportions);
}
```

---

## API Reference

The sections below cover the everyday surface. The **complete reference —
every module, every export, with verified signatures and executed examples —
lives in [`docs/api/`](docs/api/README.md)**, including the generated
[export availability matrix](docs/api/exports.md) (586 exports × 12 subpaths:
the authoritative answer to "is X exposed from Y?") and the
[entry-points guide](docs/api/entry-points.md) explaining what
`ladyna/light`/`ladyna/full` do and don't carry.

### Model Building

#### `tna(data, options?)`

Build a relative transition probability model.

```typescript
import { tna } from 'ladyna';

const data = [
  ['read', 'write', 'discuss', 'read'],
  ['write', 'discuss', 'read', 'write'],
];

const model = tna(data);
```

**Parameters:**
- `data` — `SequenceData | TNAData | number[][]` — Input data (see [Data Format](#data-format))
- `options.scaling` — `string | string[] | null` — Scaling to apply: `'minmax'`, `'max'`, `'rank'`, or array of these
- `options.labels` — `string[]` — Override auto-detected state labels
- `options.beginState` — `string` — Add artificial begin state
- `options.endState` — `string` — Add artificial end state

**Returns:** `TNA` object

#### `ftna(data, options?)`

Build a frequency (raw count) model. Same parameters as `tna()`.

```typescript
import { ftna } from 'ladyna';

const model = ftna(data);
// model.weights contains raw transition counts
```

#### `ctna(data, options?)`

Build a co-occurrence model. Same parameters as `tna()`.

```typescript
import { ctna } from 'ladyna';

const model = ctna(data);
// model.weights contains bidirectional co-occurrence counts
```

#### `atna(data, options?)`

Build an attention-weighted model with exponential decay.

```typescript
import { atna } from 'ladyna';

const model = atna(data, { beta: 0.1 });
// Recent transitions receive higher weights
```

**Additional parameter:**
- `options.beta` — `number` — Decay parameter (default: `0.1`). Higher values = stronger recency weighting.

#### `buildModel(data, options?)`

Generic model builder. Use this for advanced model types.

```typescript
import { buildModel } from 'ladyna';

// Build from a pre-computed weight matrix
const model = buildModel([
  [0, 0.3, 0.7],
  [0.5, 0, 0.5],
  [0.6, 0.4, 0],
], {
  type: 'matrix',
  labels: ['A', 'B', 'C'],
});
```

**All model types:** `'relative'`, `'frequency'`, `'co-occurrence'`, `'reverse'`, `'n-gram'`, `'gap'`, `'window'`, `'attention'`, `'matrix'`

#### `summary(model)`

Get a summary of model properties.

```typescript
import { tna, summary } from 'ladyna';

const s = summary(tna(data));
// {
//   nStates: 3,
//   type: 'relative',
//   nEdges: 6,
//   density: 0.667,
//   meanWeight: 0.333,
//   maxWeight: 0.5,
//   hasSelfLoops: false,
// }
```

---

### Centralities

#### `centralities(model, options?)`

Compute 9 centrality measures for each state in the network.

```typescript
import { tna, centralities, AVAILABLE_MEASURES } from 'ladyna';

const model = tna(data);
const cent = centralities(model);

// Access individual measures
cent.measures.OutStrength;      // Float64Array — weighted out-degree
cent.measures.InStrength;       // Float64Array — weighted in-degree
cent.measures.Betweenness;      // Float64Array — shortest-path betweenness
cent.measures.BetweennessRSP;   // Float64Array — randomized shortest-path betweenness
cent.measures.ClosenessIn;      // Float64Array — in-closeness
cent.measures.ClosenessOut;     // Float64Array — out-closeness
cent.measures.Closeness;        // Float64Array — undirected closeness
cent.measures.Diffusion;        // Float64Array — diffusion centrality
cent.measures.Clustering;       // Float64Array — weighted clustering coefficient

// Labels are aligned with measure arrays
cent.labels; // ['A', 'B', 'C']

// List all available measures
console.log(AVAILABLE_MEASURES);
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `options.loops` — `boolean` — Include self-loops (default: `true`)
- `options.normalize` — `boolean` — Normalize measures (default: `false`)
- `options.measures` — `CentralityMeasure[]` — Subset of measures to compute

**Returns:** `CentralityResult`

#### `betweennessNetwork(model)`

Replace edge weights with edge betweenness centrality values.

```typescript
import { tna, betweennessNetwork } from 'ladyna';

const bModel = betweennessNetwork(tna(data));
// bModel.weights now contains edge betweenness values
```

---

### Pruning

#### `prune(model, threshold?)`

Remove edges below a weight threshold.

```typescript
import { tna, prune } from 'ladyna';

const model = tna(data);
const pruned = prune(model, 0.1);
// All edges with weight < 0.1 are set to 0
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `threshold` — `number` — Weight threshold (default: `0.1`)

**Returns:** `TNA` (or `Record<string, TNA>` for GroupTNA)

---

### Community Detection

#### `communities(model, options?)`

Detect communities (clusters of densely connected nodes).

```typescript
import { tna, communities, AVAILABLE_METHODS } from 'ladyna';

const model = tna(data);

// Single method
const comm = communities(model, { methods: 'louvain' });
console.log(comm.assignments.louvain);  // [0, 1, 0] — community per node
console.log(comm.counts.louvain);       // 2 — number of communities

// Multiple methods at once
const commAll = communities(model, {
  methods: ['louvain', 'fast_greedy', 'walktrap'],
});

// Available methods
console.log(AVAILABLE_METHODS);
// ['fast_greedy', 'louvain', 'label_prop', 'leading_eigen', 'edge_betweenness', 'walktrap']
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `options.methods` — `CommunityMethod | CommunityMethod[]` — Detection method(s)

**Returns:** `CommunityResult`

---

### Clique Detection

#### `cliques(model, options?)`

Find fully connected subgraphs (cliques) above a weight threshold.

```typescript
import { tna, cliques } from 'ladyna';

const model = tna(data);
const cl = cliques(model, { threshold: 0.05 });
console.log(cl.labels);   // [['A', 'B'], ['B', 'C']] — labels per clique
console.log(cl.size);     // 2 — minimum clique size
```

**Parameters:**
- `model` — `TNA | GroupTNA`
- `options.threshold` — `number` — Minimum edge weight (default: `0.05`)

**Returns:** `CliqueResult`

---

### Sequence Clustering

#### `clusterSequences(data, k, options?)`

Cluster sequences based on pairwise distances.

```typescript
import { clusterSequences } from 'ladyna';

const data = [
  ['A', 'B', 'C'],
  ['A', 'B', 'C'],
  ['C', 'B', 'A'],
  ['C', 'B', 'A'],
];

const result = clusterSequences(data, 2, {
  dissimilarity: 'hamming',
  method: 'pam',
});

console.log(result.assignments);  // [1, 1, 2, 2]
console.log(result.silhouette);   // 0.75 — clustering quality (-1 to 1)
console.log(result.sizes);        // [2, 2]
```

**Parameters:**
- `data` — `SequenceData | TNAData`
- `k` — `number` — Number of clusters (must be >= 2)
- `options.dissimilarity` — `'hamming' | 'lv' | 'osa' | 'lcs'` — Distance metric (default: `'hamming'`)
  - `'hamming'` — Positional mismatches
  - `'lv'` — Levenshtein (edit distance: insert, delete, substitute)
  - `'osa'` — Optimal string alignment (edit distance + transpositions)
  - `'lcs'` — Longest common subsequence distance
- `options.method` — `'pam' | string` — Clustering algorithm (default: `'pam'`)
  - `'pam'` — Partitioning Around Medoids (like k-medoids)
  - Any other string — Hierarchical clustering (average linkage)
- `options.weighted` — `boolean` — Position-weighted Hamming (default: `false`)
- `options.lambda` — `number` — Exponential decay for weighted Hamming (default: `1`)

**Returns:** `ClusterResult`

---

### Sequence Comparison

#### `compareSequences(groupModel, options?)`

Compare subsequence patterns between groups (e.g., high vs. low performers).

```typescript
import { groupTna, compareSequences } from 'ladyna';

const sequences = [['A', 'B', 'C'], ['A', 'C', 'B'], ['C', 'B', 'A'], ['C', 'A', 'B']];
const groups = ['high', 'high', 'low', 'low'];
const gModel = groupTna(sequences, groups);

const result = compareSequences(gModel, {
  sub: [1, 2],
  minFreq: 0,
});

// Each row: { pattern, frequencies, proportions, effectSize?, pValue? }
for (const row of result) {
  console.log(row.pattern, row.frequencies, row.proportions);
}

// With permutation testing for statistical significance
const tested = compareSequences(gModel, {
  sub: [1, 2, 3],
  test: true,
  iter: 999,
  adjust: 'bonferroni',
  seed: 42,
});

for (const row of tested) {
  if (row.pValue !== undefined && row.pValue < 0.05) {
    console.log(`${row.pattern}: p=${row.pValue.toFixed(3)}, ES=${row.effectSize?.toFixed(3)}`);
  }
}
```

**Parameters:**
- `groupModel` — `GroupTNA` — Group model built with `groupTna()`, `groupFtna()`, etc.
- `options.sub` — `number[]` — Subsequence lengths to compare (default: `[1, 2, 3]`)
- `options.minFreq` — `number` — Minimum frequency threshold (default: `0`)
- `options.test` — `boolean` — Run permutation test (default: `false`)
- `options.iter` — `number` — Number of permutation iterations (default: `999`)
- `options.adjust` — `string` — P-value adjustment method: `'bonferroni'`, `'holm'`, `'fdr'`, `'BH'`, `'none'` (default: `'bonferroni'`)
- `options.seed` — `number` — Random seed for reproducibility

**Returns:** `CompareRow[]`

---

### Group Models

Build and analyze TNA models for multiple groups simultaneously.

```typescript
import { groupTna, centralities, communities, prune, groupNames, groupEntries } from 'ladyna';

// All sequences in a flat array, with a parallel array of group labels
const sequences = [
  ['A', 'B', 'C'],    // high
  ['A', 'C', 'B'],    // high
  ['C', 'B', 'A'],    // low
  ['C', 'A', 'B'],    // low
];
const groups = ['high', 'high', 'low', 'low'];

// Build group models
const gModel = groupTna(sequences, groups);

// List group names
console.log(groupNames(gModel)); // ['high', 'low']

// Iterate over groups
for (const [name, model] of groupEntries(gModel)) {
  console.log(name, model.labels);
}

// All analysis functions accept GroupTNA directly
const cent = centralities(gModel);       // Combined centralities with group labels
const pruned = prune(gModel, 0.1);       // { high: TNA, low: TNA }
const comm = communities(gModel);        // { high: CommunityResult, low: CommunityResult }
```

#### Group builder functions

| Function | Signature | Description |
|----------|-----------|-------------|
| `groupTna(data, groups)` | `(SequenceData, string[])` | Relative transition probabilities per group |
| `groupFtna(data, groups)` | `(SequenceData, string[])` | Frequency counts per group |
| `groupCtna(data, groups)` | `(SequenceData, string[])` | Co-occurrence per group |
| `groupAtna(data, groups)` | `(SequenceData, string[])` | Attention-weighted per group |
| `createGroupTNA(models)` | `(Record<string, TNA>)` | Create from pre-built TNA objects |

---

### Network Plots & Drawing

#### `plotNetwork(model, options?)`

Render a TNA model as a self-contained SVG string — the R `plot.tna`
analogue. Circular layout, weight-scaled curved edges (reciprocal pairs
curved apart), arrowheads, numeric edge labels, an initial-probability ring
per node, and hover tooltips. The SVG carries `viewBox` +
`max-width:100%;height:auto`, so it scales to its container.

```typescript
import { tna, plotNetwork, createColorMap } from 'ladyna';

const model = tna(sequences);
document.body.innerHTML = plotNetwork(model);

// All options (defaults shown)
plotNetwork(model, {
  width: 760, height: 560,
  title: undefined,          // heading rendered only when provided
  subtitle: undefined,
  background: '#ffffff',
  colors: undefined,         // node palette; default DEFAULT_COLORS (R TNA parity)
  colorMap: undefined,       // { label: color } — wins over colors; keeps state
                             // colours identical across side-by-side panels
  cutoff: 0,                 // hide edges with |weight| <= cutoff
  edgeLabels: true,
  decimals: undefined,       // 0 for frequency models, 2 otherwise
  initRing: undefined,       // auto: on when any initial probability > 0
  nodeRadius: undefined,     // auto-shrinks on crowded circles
  edgeColor: '#2B4C7E',
  edgeWidthMin: 0.55, edgeWidthMax: 2.8,
});

// GroupTNA in → one titled SVG per group out
const svgs = plotNetwork(groupModel);   // Record<string, string>
```

#### Drawing geometry (custom renderers)

Building an interactive network view (drag, zoom, animation) that the static
SVG strings can't provide? Use the same geometry the built-in painters use,
so custom views stay visually consistent:

```typescript
import {
  networkEdgeGeometry, networkArrowPolygon, networkSelfLoopGeometry,
} from 'ladyna';   // or 'ladyna/core' (not exported from ladyna/light or ladyna/full)

// Edge clipped to the painted node boundaries, straight or curved
const g = networkEdgeGeometry(
  sx, sy, tx, ty,      // source / target centres
  sourceRadius,        // painted radius of the source node
  targetRadius,        // default = sourceRadius
  curvature,           // 0 = straight; px offset of the control point
  arrowLength,         // default 8; tip is pulled back so the arrow lands on the edge
);
// → { path, tipX, tipY, tipDx, tipDy, labelX, labelY }
//   e.g. nodes at (0,0)→(100,0), r=10: path "M10,0 L82,0", tip (90,0)
//   path is '' when the nodes overlap — skip drawing then.

// Arrowhead polygon at the edge tip
const points = networkArrowPolygon(g.tipX, g.tipY, g.tipDx, g.tipDy);
// → SVG points string, e.g. "90,0 83,3.5 83,-3.5"

// Compact self-loop pointing away from the layout centre
const loop = networkSelfLoopGeometry(x, y, nodeRadius, outwardAngle);
```

The demo's interactive network view (`demo/main.ts`) is built on exactly
these helpers. See the [Visualization](#visualization) section for the full
catalogue of built-in painters.

### Data Preparation

#### `prepareData(data, options?)`

Prepare raw sequence data into a `TNAData` container with summary statistics.

```typescript
import { prepareData } from 'ladyna';

const raw = [
  ['read', 'write', 'discuss'],
  ['write', 'read', null, 'discuss'],
];

const prepared = prepareData(raw);
console.log(prepared.labels);           // ['discuss', 'read', 'write']
console.log(prepared.statistics);
// {
//   nSessions: 2,
//   nUniqueActions: 3,
//   uniqueActions: ['discuss', 'read', 'write'],
//   maxSequenceLength: 4,
//   meanSequenceLength: 3.5,
// }
```

#### `createSeqdata(data, options?)`

Lower-level function to clean sequence data and detect labels.

```typescript
import { createSeqdata } from 'ladyna';

const { data, labels } = createSeqdata(rawData, {
  beginState: 'START',
  endState: 'END',
});
```

#### `importOnehot(data, window, step?)`

Import windowed one-hot encoded data for TNA analysis.

```typescript
import { importOnehot } from 'ladyna';

const onehot = importOnehot(rawData, 5, 1);
```

---

### Utility Functions

#### Matrix operations

```typescript
import { Matrix, rowNormalize, minmaxScale, maxScale, rankScale } from 'ladyna';

// Create matrices
const m = Matrix.zeros(3, 3);
const m2 = Matrix.from2D([[1, 2], [3, 4]]);

// Access
m.get(0, 1);
m.set(0, 1, 0.5);
m.rows;  // number of rows
m.cols;  // number of columns

// Operations
const norm = rowNormalize(m2);     // Row-normalize
const mm = minmaxScale(m2);        // Min-max scale
const mx = maxScale(m2);           // Max scale
const rk = rankScale(m2);          // Rank scale
```

#### Color utilities

```typescript
import {
  colorPalette, DEFAULT_COLORS, createColorMap,
  hexToRgb, rgbToHex, lightenColor, darkenColor,
} from 'ladyna';

const colors = colorPalette(5);                       // Get 5 distinct colors
const map = createColorMap(['A', 'B', 'C']);           // { A: '#...', B: '#...', C: '#...' }
const [r, g, b] = hexToRgb('#4e79a7');                // [78, 121, 167]
const lighter = lightenColor('#4e79a7', 0.3);         // Lighten by 30%
```

#### Statistical utilities

```typescript
import { arrayMean, arrayStd, pearsonCorr, arrayQuantile } from 'ladyna';

const arr = new Float64Array([1, 2, 3, 4, 5]);
arrayMean(arr);              // 3
arrayStd(arr);               // ~1.58 (sample std, ddof=1)
arrayQuantile(arr, 0.5);     // 3 (median)

const a = new Float64Array([1, 2, 3]);
const b = new Float64Array([2, 4, 6]);
pearsonCorr(a, b);           // 1.0
```

#### Seeded RNG

```typescript
import { SeededRNG } from 'ladyna';

const rng = new SeededRNG(42);
rng.random();          // Deterministic float in [0, 1)
rng.randInt(10);       // Deterministic integer in [0, 10) — note the capital I
rng.shuffle([1, 2, 3]);      // In-place Fisher-Yates shuffle
rng.permutation(5);          // Random permutation of 0..4
rng.choice(10, 3);           // 3 draws from 0..9 (with replacement)
rng.choiceWithoutReplacement(10, 3);
```

---

## Using in a Website

### With a Bundler

The recommended approach for production websites. Works with Vite, Webpack, Rollup, esbuild, Parcel, etc.

**1. Install:**

```bash
npm install ladyna
```

**2. Import and use in your code:**

```typescript
// app.ts or app.js
import { tna, centralities, prune, communities, summary } from 'ladyna';

const data = [
  ['login', 'browse', 'search', 'purchase'],
  ['login', 'search', 'browse', 'logout'],
  ['login', 'browse', 'browse', 'purchase'],
];

const model = tna(data);
const cent = centralities(model);

// Render results in the DOM
const el = document.getElementById('results')!;
el.innerHTML = model.labels.map((label, i) => {
  return `<div>${label}: OutStrength=${cent.measures.OutStrength[i]!.toFixed(3)}</div>`;
}).join('');
```

**3. Vite example config:**

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
export default defineConfig({
  // ladyna is a standard ESM/CJS package — no special config needed
});
```

**4. Webpack example config:**

```javascript
// webpack.config.js
module.exports = {
  resolve: {
    extensions: ['.ts', '.js'],
  },
  module: {
    rules: [
      { test: /\.ts$/, use: 'ts-loader', exclude: /node_modules/ },
    ],
  },
};
```

### From a CDN

For quick prototyping or simple pages without a build step. Use [esm.sh](https://esm.sh), [jsDelivr](https://www.jsdelivr.com/), or [unpkg](https://unpkg.com/).

```html
<!DOCTYPE html>
<html>
<head>
  <title>TNA Demo</title>
</head>
<body>
  <div id="output"></div>

  <script type="module">
    // Import from CDN
    import { tna, centralities, prune, summary } from 'https://esm.sh/ladyna';

    const data = [
      ['A', 'B', 'C', 'A'],
      ['B', 'C', 'A', 'B'],
      ['A', 'A', 'B', 'C'],
    ];

    const model = tna(data);
    const cent = centralities(model);
    const s = summary(model);

    document.getElementById('output').innerHTML = `
      <h2>TNA Model (${s.type})</h2>
      <p>States: ${model.labels.join(', ')}</p>
      <p>Edges: ${s.nEdges}, Density: ${Number(s.density).toFixed(3)}</p>
      <h3>OutStrength</h3>
      <ul>
        ${model.labels.map((l, i) =>
          `<li>${l}: ${cent.measures.OutStrength[i].toFixed(4)}</li>`
        ).join('')}
      </ul>
    `;
  </script>
</body>
</html>
```

### Server-Side

**Node.js (ESM):**

```typescript
import { tna, centralities } from 'ladyna';

const data = [['A', 'B', 'C'], ['B', 'C', 'A']];
const model = tna(data);
const cent = centralities(model);
console.log(cent.measures.OutStrength);
```

**Node.js (CommonJS):**

```javascript
const { tna, centralities } = require('ladyna');

const data = [['A', 'B', 'C'], ['B', 'C', 'A']];
const model = tna(data);
const cent = centralities(model);
console.log(cent.measures.OutStrength);
```

**Deno:**

```typescript
import { tna, centralities } from 'npm:ladyna';

const data = [['A', 'B', 'C'], ['B', 'C', 'A']];
const model = tna(data);
console.log(centralities(model));
```

**Bun:**

```typescript
import { tna, centralities } from 'ladyna';
// Same API as Node.js ESM
```

---

## Data Format

### Sequence Data (primary input)

A 2D array where each row is a sequence of state labels (strings). Sequences can have different lengths. Use `null` for missing values.

```typescript
const data: SequenceData = [
  ['read', 'write', 'discuss', 'read'],
  ['write', 'discuss', null, 'read'],    // null = missing
  ['read', 'read', 'write'],             // shorter sequence is fine
];
```

### Direct Weight Matrix

A square 2D number array where `matrix[i][j]` is the weight from state `i` to state `j`.

```typescript
const matrix = [
  [0.0, 0.3, 0.7],
  [0.5, 0.0, 0.5],
  [0.6, 0.4, 0.0],
];

const model = tna(matrix, { labels: ['A', 'B', 'C'] });
```

### Grouped Data

A flat sequence array with a parallel array of group labels.

```typescript
const sequences = [
  ['A', 'B', 'C'],  // experimental
  ['A', 'C', 'B'],  // experimental
  ['C', 'B', 'A'],  // control
  ['C', 'A', 'B'],  // control
];
const groups = ['experimental', 'experimental', 'control', 'control'];

const gModel = groupTna(sequences, groups);
```

Or create from pre-built TNA models:

```typescript
import { tna, createGroupTNA } from 'ladyna';

const models = {
  experimental: tna([['A', 'B', 'C'], ['A', 'C', 'B']]),
  control: tna([['C', 'B', 'A'], ['C', 'A', 'B']]),
};
const gModel = createGroupTNA(models);
```

---

## Types Reference

```typescript
/** A sequence: array of string states (null = missing). */
type Sequence = (string | null)[];

/** Sequence dataset: array of sequences. */
type SequenceData = Sequence[];

/** TNA model object. */
interface TNA {
  weights: Matrix;          // n_states x n_states adjacency matrix
  inits: Float64Array;      // Initial state probabilities
  labels: string[];         // State labels
  data: SequenceData | null;
  type: ModelType;
  scaling: string[];
  params?: TransitionParams; // e.g. beta for the attention model
  counts?: Matrix;          // Raw transition counts (R $frequency_matrix);
                            // present when built from sequence data
}

/** Group of TNA models. */
interface GroupTNA {
  models: Record<string, TNA>;
}

/** Centrality result. */
interface CentralityResult {
  labels: string[];
  measures: Record<CentralityMeasure, Float64Array>;
  groups?: string[];       // Present for GroupTNA input
}

/** Centrality measures. */
type CentralityMeasure =
  | 'OutStrength' | 'InStrength'
  | 'ClosenessIn' | 'ClosenessOut' | 'Closeness'
  | 'Betweenness' | 'BetweennessRSP'
  | 'Diffusion' | 'Clustering' | 'PageRank';

/** Community detection result. */
interface CommunityResult {
  counts: Record<string, number>;       // method → number of communities
  assignments: Record<string, number[]>; // method → community per node
  labels: string[];
}

/** Community detection methods. */
type CommunityMethod =
  | 'fast_greedy' | 'louvain' | 'label_prop'
  | 'leading_eigen' | 'edge_betweenness' | 'walktrap';

/** Clique detection result. */
interface CliqueResult {
  weights: Matrix[];    // Weight sub-matrices per clique
  indices: number[][];  // Node indices per clique
  labels: string[][];   // Node labels per clique
  size: number;
  threshold: number;
}

/** Cluster result. */
interface ClusterResult {
  data: SequenceData;
  k: number;
  assignments: number[];    // 1-indexed cluster labels
  silhouette: number;       // Silhouette score (-1 to 1)
  sizes: number[];
  method: string;
  distance: Matrix;
  dissimilarity: string;
}

/** Sequence comparison result row. */
interface CompareRow {
  pattern: string;
  frequencies: Record<string, number>;
  proportions: Record<string, number>;
  effectSize?: number;
  pValue?: number;
}

/** plotNetwork() options — see Network Plots & Drawing. */
interface NetworkPlotOptions {
  width?: number; height?: number;
  title?: string; subtitle?: string; background?: string;
  colors?: string[];                  // node palette (default DEFAULT_COLORS)
  colorMap?: Record<string, string>;  // colour per state label; wins over colors
  cutoff?: number;                    // hide edges with |weight| <= cutoff
  edgeLabels?: boolean; decimals?: number;
  initRing?: boolean; nodeRadius?: number;
  edgeColor?: string; edgeWidthMin?: number; edgeWidthMax?: number;
}

/** Shared edge/self-loop geometry returned by the networkDrawing helpers. */
interface NetworkEdgeGeometry {
  path: string;                    // SVG path ('' when nodes overlap)
  tipX: number; tipY: number;      // arrow tip position
  tipDx: number; tipDy: number;    // arrow direction (unit vector)
  labelX: number; labelY: number;  // suggested label anchor
}
```

---

## Full Example: Analyzing Student Learning Behavior

```typescript
import {
  tna, ftna, centralities, prune, communities, clusterSequences,
  summary, AVAILABLE_MEASURES,
} from 'ladyna';

// Student learning activity sequences
const sequences = [
  ['read', 'annotate', 'discuss', 'quiz', 'read'],
  ['read', 'quiz', 'read', 'annotate', 'discuss'],
  ['discuss', 'read', 'annotate', 'read', 'quiz'],
  ['quiz', 'read', 'discuss', 'annotate', 'quiz'],
  ['read', 'read', 'annotate', 'discuss', 'quiz'],
];

// 1. Build model
const model = tna(sequences);
const s = summary(model);
console.log(`States: ${s.nStates}, Edges: ${s.nEdges}, Density: ${s.density}`);

// 2. Centralities — find most important states
const cent = centralities(model);
model.labels.forEach((label, i) => {
  console.log(`${label}: OutStrength=${cent.measures.OutStrength[i]!.toFixed(3)}, ` +
    `Betweenness=${cent.measures.Betweenness[i]!.toFixed(3)}`);
});

// 3. Prune weak connections
const pruned = prune(model, 0.15);
const ps = summary(pruned);
console.log(`After pruning: ${ps.nEdges} edges remain`);

// 4. Communities — find clusters of related activities
const comm = communities(model, { methods: 'louvain' });
model.labels.forEach((label, i) => {
  console.log(`${label} → Community ${comm.assignments.louvain![i]}`);
});

// 5. Cluster students by behavior similarity
const clusters = clusterSequences(sequences, 2, {
  dissimilarity: 'lv',
  method: 'pam',
});
console.log(`Silhouette: ${clusters.silhouette.toFixed(3)}`);
console.log(`Assignments: ${clusters.assignments}`);
```

---

## Citation

If you use TNA in your research, please cite:

> Saqr, M., Lopez-Pernas, S., Tormanen, T., Kaliisa, R., Misiejuk, K., & Tikka, S. (2025). Transition Network Analysis: A Novel Framework for Modeling, Visualizing, and Identifying the Temporal Patterns of Learners and Learning Processes. In *Proceedings of the 15th International Learning Analytics and Knowledge Conference (LAK '25)*, 351-361. https://doi.org/10.1145/3706468.3706513

```bibtex
@inproceedings{saqr2025tna,
  title     = {Transition Network Analysis: A Novel Framework for Modeling,
               Visualizing, and Identifying the Temporal Patterns of Learners
               and Learning Processes},
  author    = {Saqr, Mohammed and L{\'o}pez-Pernas, Sonsoles and
               T{\"o}rm{\"a}nen, Tiina and Kaliisa, Rogers and
               Misiejuk, Kamila and Tikka, Santtu},
  booktitle = {Proceedings of the 15th International Learning Analytics
               and Knowledge Conference (LAK '25)},
  pages     = {351--361},
  year      = {2025},
  publisher = {Association for Computing Machinery},
  doi       = {10.1145/3706468.3706513},
}
```

**Key references:**

- Saqr, M., Lopez-Pernas, S., Tormanen, T., Kaliisa, R., Misiejuk, K., & Tikka, S. (2025). Transition Network Analysis: A Novel Framework for Modeling, Visualizing, and Identifying the Temporal Patterns of Learners and Learning Processes. In *Proceedings of LAK '25*, 351-361. https://doi.org/10.1145/3706468.3706513

- Tikka, S., Lopez-Pernas, S., & Saqr, M. (2025). tna: An R Package for Transition Network Analysis. *Applied Psychological Measurement*. https://doi.org/10.1177/01466216251348840

- Saqr, M., Lopez-Pernas, S., & Tikka, S. (2025). Mapping relational dynamics with transition network analysis: A primer and tutorial. In *Advanced Learning Analytics Methods: AI, Precision and Complexity*. Springer.

- Saqr, M., Lopez-Pernas, S., & Tikka, S. (2025). Capturing the breadth and dynamics of the temporal process with frequency transition network analysis. In *Advanced Learning Analytics Methods: AI, Precision and Complexity*. Springer.

- Lopez-Pernas, S., Tikka, S., & Saqr, M. (2025). Mining patterns and clusters with transition network analysis: A heterogeneity approach. In *Advanced Learning Analytics Methods: AI, Precision and Complexity*. Springer.

---

## Related Projects

| Project | Language | Links |
|---------|----------|-------|
| **tna** | R | [CRAN](https://cran.r-project.org/package=TNA) · [GitHub](https://github.com/sonsoleslp/tna) |
| **tna** | Python | [PyPI](https://pypi.org/project/tna/) · [GitHub](https://github.com/mohsaqr/tnapy) |
| **ladyna** | TypeScript/JS | [npm](https://www.npmjs.com/package/ladyna) · [GitHub](https://github.com/mohsaqr/tna-js) |
| **TNA Desktop** | Web app | [Launch](https://saqr.me/tnadesktop/) · [GitHub](https://github.com/mohsaqr/tna-desktop) |

---

## License

MIT
